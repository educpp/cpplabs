"""Regression analysis helpers.

Provides a randomized best-fit regression routine that samples between
the endpoints (nval +/- nunc) of x/y measured or derived quantities and
returns `ConstantQuantity` results for slope, y-intercept, and
x-intercept. Each returned `ConstantQuantity` holds a scalar center
value and a half-width uncertainty derived from the sampled min/max
(midpoint and half-range).

The primary function is :func:`randomized_best_fit` which accepts either
`MeasuredQuantity`/`DerivedQuantity` objects or plain NumPy arrays for
`x` and `y` and an optional ``seed`` (default 0) to produce
deterministic sampling when a ``rng`` is not supplied. It also returns
a `LinearModel` helper for plotting and display.
"""
from __future__ import annotations

from typing import Any, Tuple, Dict, Optional, Iterable
import inspect
import re
import warnings
import sympy as sp
import numpy as np

from .DerivedQuantity import DerivedQuantity
from .ConstantQuantity import ConstantQuantity
from .UnitAlgebra import ureg
from . import expr_registry
from .formatting import _format_number, _safe_get_unit, DEFAULT_DECIMALS, MIN_SIGFIGS

__all__ = ["Analyze"]


try:
    from scipy.optimize import curve_fit as _scipy_curve_fit
except Exception:
    _scipy_curve_fit = None

try:
    from scipy.optimize import OptimizeWarning as _OptimizeWarning
except Exception:
    _OptimizeWarning = Warning


def _get_numeric_arrays(obj: Any) -> Tuple[np.ndarray, np.ndarray]:
    """Return (nval, nunc) arrays for a measured/derived object.

    If `nunc` is missing or None, it is treated as zero-width.
    The returned arrays are 1-D numpy arrays of equal shape.
    """
    if hasattr(obj, "nval"):
        vals = np.atleast_1d(np.asarray(obj.nval, dtype=float))
    else:
        vals = np.atleast_1d(np.asarray(obj, dtype=float))

    if hasattr(obj, "nunc") and obj.nunc is not None:
        uncs = np.atleast_1d(np.asarray(obj.nunc, dtype=float))
    else:
        uncs = np.zeros_like(vals, dtype=float)

    if vals.shape != uncs.shape:
        try:
            uncs = np.broadcast_to(uncs, vals.shape)
        except Exception:
            raise ValueError("Value and uncertainty shapes are not broadcastable")

    return vals.ravel(), uncs.ravel()


def _get_unit(obj: Any):
    """Return a pint Unit or None from an object that may store units.

    Accepts strings, pint Units, or objects with a `unit` attribute.
    """
    unit = None
    u = getattr(obj, "unit", None)
    if u is None:
        return None
    # If already a pint Unit/Quantity, attempt to extract unit
    try:
        return ureg.Unit(u)
    except Exception:
        return None


def _scalar_model_input(value: Any, expected_unit: Any) -> tuple[float, float]:
    """Return a scalar model input as (center, half-width) in model units."""
    if hasattr(value, "nval"):
        vals, uncs = _get_numeric_arrays(value)
        if vals.size != 1:
            raise ValueError("model.at(x) requires a scalar quantity with one value")
        source_unit = _get_unit(value)
        if expected_unit is not None:
            if source_unit is None:
                raise ValueError("Quantity input to model.at(x) must have a compatible unit")
            try:
                center = (vals[0] * source_unit).to(expected_unit).magnitude
                width = (uncs[0] * source_unit).to(expected_unit).magnitude
            except Exception as exc:
                raise ValueError("Quantity input to model.at(x) has incompatible units") from exc
            return float(center), abs(float(width))
        return float(vals[0]), abs(float(uncs[0]))

    arr = np.asarray(value)
    if arr.ndim != 0:
        raise ValueError("model.at(x) requires a scalar numeric input")
    try:
        return float(arr), 0.0
    except (TypeError, ValueError) as exc:
        raise TypeError("model.at(x) requires a scalar numeric or quantity input") from exc


def _interval_result(values: Iterable[float]) -> tuple[float, float]:
    finite = np.asarray(list(values), dtype=float)
    finite = finite[np.isfinite(finite)]
    if finite.size == 0:
        raise ValueError("model.at(x) could not evaluate a finite result")
    return float((finite.min() + finite.max()) / 2), float((finite.max() - finite.min()) / 2)


def _infer_var_name(obj: Any, default: str) -> str:
    frame = inspect.currentframe()
    try:
        current_file = inspect.getsourcefile(frame) if frame is not None else None
        caller = frame.f_back if frame is not None else None
        for _ in range(5):
            if caller is None:
                return default
            caller_file = inspect.getsourcefile(caller)
            if caller_file != current_file:
                scope = dict(caller.f_globals)
                scope.update(caller.f_locals)
                for name, value in scope.items():
                    if value is obj:
                        return name
                return default
            caller = caller.f_back
        return default
    finally:
        del frame


def _resolve_symbol_name(name: str) -> Any:
    frame = inspect.currentframe()
    try:
        current_file = inspect.getsourcefile(frame) if frame is not None else None
        caller = frame.f_back if frame is not None else None
        for _ in range(5):
            if caller is None:
                break
            caller_file = inspect.getsourcefile(caller)
            if caller_file != current_file:
                scope = dict(caller.f_globals)
                scope.update(caller.f_locals)
                return scope.get(name, None)
            caller = caller.f_back
        return None
    finally:
        del frame


def _clean_sympy_text(expr_text: str) -> str:
    """Normalize expression text for `sympy.sympify`.

    This mirrors the notebook transformer behavior by stripping optional
    `sp.`/`sympy.` prefixes in user-entered model strings.
    """
    return re.sub(r"\b(?:sympy|sp)\.", "", expr_text)


def _mk_cq_from_samples(samples: np.ndarray, name: str, unit: Any = None) -> ConstantQuantity:
    """Create a ConstantQuantity from sample min/max midpoint and half-range."""
    arr = np.asarray(samples, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        mn = np.nan
        mx = np.nan
    else:
        mn = float(np.min(arr))
        mx = float(np.max(arr))
    center = (mn + mx) / 2.0
    half = (mx - mn) / 2.0
    return ConstantQuantity(center, half, str(unit or ""), name)


def _cq_center(q: ConstantQuantity) -> float:
    vals = np.atleast_1d(np.asarray(q.nval, dtype=float))
    if vals.size == 0:
        return float("nan")
    return float(vals[0])


def _resolve_xy_and_names(
    x: Any,
    y: Any,
    x_name: Optional[str] = None,
    y_name: Optional[str] = None,
) -> tuple[Any, Any, Optional[str], Optional[str]]:
    if isinstance(x, str):
        x_name = x_name or x
        resolved = _resolve_symbol_name(x)
        if resolved is None:
            raise ValueError(f"No object found for x symbol '{x}'")
        x = resolved

    if isinstance(y, str):
        y_name = y_name or y
        resolved = _resolve_symbol_name(y)
        if resolved is None:
            raise ValueError(f"No object found for y symbol '{y}'")
        y = resolved

    return x, y, x_name, y_name


def _as_symbol(sym: str | sp.Symbol) -> sp.Symbol:
    if isinstance(sym, sp.Symbol):
        return sym
    return sp.Symbol(str(sym))


def _safe_scale(vals: np.ndarray, fallback: float = 1.0) -> float:
    arr = np.asarray(vals, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return float(fallback)
    span = float(np.max(arr) - np.min(arr))
    med = float(np.median(np.abs(arr)))
    scale = max(span, med, abs(float(np.mean(arr))), 1e-12)
    if not np.isfinite(scale) or scale <= 0:
        return float(fallback)
    return float(scale)


def _is_positive_param_name(name: str) -> bool:
    n = str(name).lower()
    tokens = ("tau", "sigma", "std", "rate", "lambda", "decay")
    return any(tok in n for tok in tokens) or n in {"k"}


def _infer_initial_guess(
    xv: np.ndarray,
    yv: np.ndarray,
    param_keys: list[str],
) -> np.ndarray:
    x = np.asarray(xv, dtype=float)
    y = np.asarray(yv, dtype=float)
    x_scale = _safe_scale(x, fallback=1.0)
    y_scale = _safe_scale(y, fallback=1.0)
    y_med = float(np.nanmedian(y)) if np.any(np.isfinite(y)) else 0.0
    y_min = float(np.nanmin(y)) if np.any(np.isfinite(y)) else 0.0
    y_max = float(np.nanmax(y)) if np.any(np.isfinite(y)) else y_min + 1.0
    y_span = max(y_max - y_min, 1e-9)

    p0 = np.ones(len(param_keys), dtype=float)
    for i, key in enumerate(param_keys):
        k = str(key).lower()
        if any(tok in k for tok in ("offset", "off", "intercept")) or k in {"b", "c", "ioff", "voff"}:
            guess = y_min
        elif any(tok in k for tok in ("amp", "gain")) or k in {"a", "v0", "i0", "amplitude"}:
            guess = y_span
        elif _is_positive_param_name(k):
            guess = max(0.25 * x_scale, 1e-6)
        else:
            guess = y_med if i == 0 else 1.0

        if not np.isfinite(guess) or abs(float(guess)) < 1e-12:
            guess = y_scale if i == 0 else 1.0
        p0[i] = float(guess)
    return p0


def _coerce_bounds(bounds: tuple[Any, Any], n_params: int) -> tuple[np.ndarray, np.ndarray]:
    low_raw, high_raw = bounds
    low = np.asarray(low_raw, dtype=float)
    high = np.asarray(high_raw, dtype=float)

    if low.ndim == 0:
        low = np.full(n_params, float(low), dtype=float)
    if high.ndim == 0:
        high = np.full(n_params, float(high), dtype=float)

    if low.size != n_params or high.size != n_params:
        raise ValueError("bounds must be scalars or arrays matching number of parameters")

    return low.astype(float), high.astype(float)


def _infer_bounds(
    xv: np.ndarray,
    yv: np.ndarray,
    param_keys: list[str],
) -> tuple[np.ndarray, np.ndarray]:
    x = np.asarray(xv, dtype=float)
    y = np.asarray(yv, dtype=float)
    x_scale = _safe_scale(x, fallback=1.0)
    y_scale = _safe_scale(y, fallback=1.0)
    y_max_abs = max(abs(float(np.nanmax(y))) if np.any(np.isfinite(y)) else 1.0, y_scale)

    low = np.full(len(param_keys), -10.0 * y_max_abs, dtype=float)
    high = np.full(len(param_keys), 10.0 * y_max_abs, dtype=float)

    for i, key in enumerate(param_keys):
        k = str(key).lower()
        if _is_positive_param_name(k):
            low[i] = 1e-9
            high[i] = max(100.0 * x_scale, 1e-6)
        elif any(tok in k for tok in ("amp", "gain")) or k in {"a", "v0", "i0", "amplitude"}:
            amp = max(10.0 * y_scale, 1.0)
            low[i] = -amp
            high[i] = amp
        elif any(tok in k for tok in ("offset", "off", "intercept")) or k in {"b", "c", "ioff", "voff"}:
            off = max(10.0 * y_scale, 1.0)
            low[i] = -off
            high[i] = off

        if not np.isfinite(low[i]):
            low[i] = -1e12
        if not np.isfinite(high[i]):
            high[i] = 1e12
        if not (low[i] < high[i]):
            mid = float(low[i]) if np.isfinite(low[i]) else 0.0
            low[i] = mid - 1.0
            high[i] = mid + 1.0

    return low, high


def _r_squared(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    if not np.any(mask):
        return float("nan")
    yt = y_true[mask]
    yp = y_pred[mask]
    ss_res = float(np.sum((yt - yp) ** 2))
    y_bar = float(np.mean(yt))
    ss_tot = float(np.sum((yt - y_bar) ** 2))
    if ss_tot <= 0:
        return float("nan")
    return float(1.0 - ss_res / ss_tot)


def _corr_from_cov(cov: np.ndarray) -> tuple[np.ndarray, float]:
    cov = np.asarray(cov, dtype=float)
    if cov.ndim != 2 or cov.shape[0] != cov.shape[1]:
        return np.full_like(cov, np.nan, dtype=float), float("nan")
    n = cov.shape[0]
    if n == 0 or not np.all(np.isfinite(cov)):
        return np.full((n, n), np.nan, dtype=float), float("nan")
    d = np.diag(cov)
    if np.any(d <= 0) or not np.all(np.isfinite(d)):
        return np.full((n, n), np.nan, dtype=float), float("nan")
    std = np.sqrt(d)
    denom = np.outer(std, std)
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = cov / denom
    corr = np.asarray(corr, dtype=float)
    corr[~np.isfinite(corr)] = np.nan
    cond = float("nan")
    if np.all(np.isfinite(corr)):
        try:
            cond = float(np.linalg.cond(corr))
        except Exception:
            cond = float("nan")
    return corr, cond


def _apply_parameter_data_controls(
    param_keys: list[str],
    p0_arr: np.ndarray,
    low_arr: np.ndarray,
    high_arr: np.ndarray,
    data: Optional[dict[str, Any]],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Apply per-parameter [guess, low, high] controls from a dictionary.

    Expected input format:
    data = {
        "ioff": [0.0, -1.0, 1.0],
        "i0": [18.0, 10.0, 25.0],
        "tau": [90.0, 1e-6, 1e6],
    }

    Also accepts dict entries with explicit keys:
    data = {"tau": {"guess": 90.0, "low": 1e-6, "high": 1e6}}
    """
    if data is None:
        return p0_arr, low_arr, high_arr
    if not isinstance(data, dict):
        raise TypeError("data must be a dict keyed by parameter name")

    key_set = set(param_keys)
    unknown = [k for k in data.keys() if str(k) not in key_set]
    if unknown:
        raise ValueError(f"Unknown parameter keys in data: {unknown}. Expected one of {param_keys}")

    p0_new = np.asarray(p0_arr, dtype=float).copy()
    low_new = np.asarray(low_arr, dtype=float).copy()
    high_new = np.asarray(high_arr, dtype=float).copy()

    index = {k: i for i, k in enumerate(param_keys)}
    for raw_key, spec in data.items():
        key = str(raw_key)
        i = index[key]

        if isinstance(spec, dict):
            if not {"guess", "low", "high"}.issubset(set(spec.keys())):
                raise ValueError(
                    f"data['{key}'] dict must contain keys 'guess', 'low', and 'high'"
                )
            guess = float(spec["guess"])
            low = float(spec["low"])
            high = float(spec["high"])
        else:
            vals = list(spec) if isinstance(spec, (list, tuple, np.ndarray)) else None
            if vals is None or len(vals) != 3:
                raise ValueError(
                    f"data['{key}'] must be [guess, low, high]"
                )
            guess = float(vals[0])
            low = float(vals[1])
            high = float(vals[2])

        if not (np.isfinite(guess) and np.isfinite(low) and np.isfinite(high)):
            raise ValueError(f"data['{key}'] values must be finite numbers")
        if not (low < high):
            raise ValueError(f"data['{key}'] must satisfy low < high")
        if not (low < guess < high):
            raise ValueError(f"data['{key}'] must satisfy low < guess < high")

        p0_new[i] = guess
        low_new[i] = low
        high_new[i] = high

    return p0_new, low_new, high_new


class CurveFitModel:
    """Callable fitted model for generalized randomized curve fitting."""

    def __init__(
        self,
        fitted_expr: sp.Expr,
        params: Dict[str, ConstantQuantity],
        x_symbol: str,
        x_name: str,
        y_name: str,
        x_unit: Any,
        y_unit: Any,
        original_expr: sp.Expr | None = None,
        parameter_symbols: Iterable[sp.Symbol] | None = None,
        parameter_names: Iterable[str] | None = None,
        x_quantity_name: str | None = None,
        y_quantity_name: str | None = None,
    ):
        self.expr = fitted_expr
        self.original_expr = original_expr if original_expr is not None else fitted_expr
        self.parameter_symbols = tuple(parameter_symbols or ())
        self.parameter_names = tuple(parameter_names or (symbol.name for symbol in self.parameter_symbols))
        if len(self.parameter_names) != len(self.parameter_symbols):
            raise ValueError("parameter_names must match parameter_symbols")
        self.params = params
        self.x_symbol = x_symbol
        self.x_name = x_name or "x"
        self.y_name = y_name or "y"
        self.x_quantity_name = x_quantity_name or self.x_name
        self.y_quantity_name = y_quantity_name or self.y_name
        self.x_unit = x_unit
        self.y_unit = y_unit
        try:
            x_sym = sp.Symbol(self.x_symbol)
            self._fn = sp.lambdify(x_sym, fitted_expr, "numpy")
        except Exception:
            self._fn = None

    def __call__(self, x):
        if self._fn is None:
            raise ValueError("Model is not callable")
        return self._fn(x)

    def at(self, x) -> ConstantQuantity:
        """Evaluate the fitted curve at scalar ``x`` as a quantity."""
        x_value, x_unc = _scalar_model_input(x, self.x_unit)
        symbols = (sp.Symbol(self.x_symbol), *self.parameter_symbols)
        fn = sp.lambdify(symbols, self.original_expr, modules=["numpy", "sympy"])
        parameter_ranges = []
        for symbol, parameter_name in zip(self.parameter_symbols, self.parameter_names):
            parameter = self.params[parameter_name]
            center = float(np.asarray(parameter.nval).reshape(-1)[0])
            uncertainty = abs(float(np.asarray(parameter.nunc).reshape(-1)[0]))
            parameter_ranges.append((center - uncertainty, center + uncertainty))

        endpoint_ranges = [(x_value - x_unc, x_value + x_unc), *parameter_ranges]
        results = []
        for choices in np.array(np.meshgrid(*endpoint_ranges)).T.reshape(-1, len(endpoint_ranges)):
            results.append(fn(float(choices[0]), *[float(v) for v in choices[1:]]))
        center, uncertainty = _interval_result(results)
        result = ConstantQuantity(center, uncertainty, str(self.y_unit or ""), self.y_quantity_name)
        result.symbol = self.y_name
        return result

    def __str__(self) -> str:
        return f"{self.y_name} = {sp.sstr(self.expr)}"

    def __repr__(self) -> str:
        return self.__str__()


class LinearModel:
    """Callable regression model with a human-friendly string form.

    Example
    >>> params, model = Analyze.randomized_best_fit(x, y)
    >>> print(model)  # displays a labeled equation with units
    """

    def __init__(
        self,
        expr: sp.Expr,
        params: Dict[str, ConstantQuantity],
        x_name: str,
        y_name: str,
        x_unit: Any,
        y_unit: Any,
        x_quantity_name: str | None = None,
        y_quantity_name: str | None = None,
    ):
        self.expr = expr
        self.params = params
        self.x_name = x_name or "x"
        self.y_name = y_name or "y"
        self.x_quantity_name = x_quantity_name or self.x_name
        self.y_quantity_name = y_quantity_name or self.y_name
        self.x_unit = x_unit
        self.y_unit = y_unit
        try:
            x_sym = sp.symbols("x")
            self._fn = sp.lambdify(x_sym, expr, "numpy")
        except Exception:
            self._fn = None

    def __call__(self, x):
        if self._fn is None:
            raise ValueError("Model is not callable")
        return self._fn(x)

    def at(self, x) -> ConstantQuantity:
        """Evaluate the fitted line at scalar ``x`` as a quantity."""
        x_value, x_unc = _scalar_model_input(x, self.x_unit)
        slope = self.params.get("slope")
        intercept = self.params.get("y-intercept")
        if slope is None or intercept is None:
            raise ValueError("LinearModel is missing slope or y-intercept")

        slope_center = float(np.asarray(slope.nval).reshape(-1)[0])
        slope_unc = abs(float(np.asarray(slope.nunc).reshape(-1)[0]))
        intercept_center = float(np.asarray(intercept.nval).reshape(-1)[0])
        intercept_unc = abs(float(np.asarray(intercept.nunc).reshape(-1)[0]))
        results = []
        for slope_value in (slope_center - slope_unc, slope_center + slope_unc):
            for intercept_value in (intercept_center - intercept_unc, intercept_center + intercept_unc):
                for x_endpoint in (x_value - x_unc, x_value + x_unc):
                    results.append(slope_value * x_endpoint + intercept_value)
        center, uncertainty = _interval_result(results)
        result = ConstantQuantity(center, uncertainty, str(self.y_unit or ""), self.y_quantity_name)
        result.symbol = self.y_name
        return result

    def __str__(self) -> str:
        slope = self.params.get("slope")
        yint = self.params.get("y-intercept")
        if slope is None or yint is None:
            return str(self.expr)

        m_val = np.atleast_1d(np.asarray(slope.nval, dtype=float))[0]
        b_val = np.atleast_1d(np.asarray(yint.nval, dtype=float))[0]
        m_str = _format_number(m_val, DEFAULT_DECIMALS, MIN_SIGFIGS)
        b_str = _format_number(b_val, DEFAULT_DECIMALS, MIN_SIGFIGS)

        m_unit = _safe_get_unit(type("_UnitHolder", (), {"unit": getattr(slope, "unit", None)})())
        b_unit = _safe_get_unit(type("_UnitHolder", (), {"unit": getattr(yint, "unit", None)})())
        x_unit = _safe_get_unit(type("_UnitHolder", (), {"unit": self.x_unit})())

        m_term = f"{m_str} [{m_unit}]" if m_unit else f"{m_str}"
        b_term = f"{b_str} [{b_unit}]" if b_unit else f"{b_str}"
        x_term = f"{self.x_name} [{x_unit}]" if x_unit else f"{self.x_name}"

        eq = f"{self.y_name} = ({m_term}) * {x_term} + ({b_term})"
        return eq

    def __repr__(self) -> str:
        return self.__str__()


def _build_regression_expr(params: Dict[str, "ConstantQuantity"], x_symbol: str = "x"):
    """Build a SymPy linear expression m*x + b using center values.

    Returns a SymPy expression or None if required parameters are missing
    or NaN.
    """
    try:
        slope = params.get("slope")
        yint = params.get("y-intercept")
        if slope is None or yint is None:
            return None
        m = float(slope.nval)
        b = float(yint.nval)
        if not (np.isfinite(m) and np.isfinite(b)):
            return None
        x = sp.symbols(x_symbol)
        return sp.Float(m) * x + sp.Float(b)
    except Exception:
        return None


def _randomized_best_fit(
    x: Any,
    y: Any,
    niter: int = 2000,
    seed: int | None = 0,
    rng: np.random.Generator | None = None,
    x_name: Optional[str] = None,
    y_name: Optional[str] = None,
) -> Tuple[Dict[str, ConstantQuantity], LinearModel]:
    """Perform randomized best-fit linear regression sampling between endpoints.

    Parameters
    - x, y: MeasuredQuantity/DerivedQuantity-like objects or numeric arrays.
    - niter: number of Monte Carlo samples (default 2000).
    - rng: optional NumPy Generator for reproducible sampling.

        Returns
        - params: dict with keys: `'slope'`, `'y-intercept'`, `'x-intercept'`.
            Each value is a `ConstantQuantity` whose ``nval`` is the midpoint of
            the observed min/max over the samples and whose ``nunc`` is half the
            observed range (i.e., half-width uncertainty).
        - model: `LinearModel` describing the fitted relation and callable as `f(x)`.
    """
    # Create RNG: if a Generator is provided use it, otherwise create
    # one from `seed`. Default `seed=0` produces deterministic results.
    if rng is None:
        rng = np.random.default_rng(seed)

    x, y, x_name, y_name = _resolve_xy_and_names(x, y, x_name=x_name, y_name=y_name)
    x_quantity_name = str(getattr(x, "name", "") or x_name or "x")
    y_quantity_name = str(getattr(y, "name", "") or y_name or "y")

    xv, xunc = _get_numeric_arrays(x)
    yv, yunc = _get_numeric_arrays(y)

    if xv.size != yv.size:
        raise ValueError("x and y must have the same number of points")

    n = xv.size

    x_lo = xv - xunc
    x_hi = xv + xunc
    y_lo = yv - yunc
    y_hi = yv + yunc

    slopes = np.empty(niter, dtype=float)
    intercepts = np.empty(niter, dtype=float)
    xints = np.empty(niter, dtype=float)

    for i in range(niter):
        xs = rng.uniform(x_lo, x_hi)
        ys = rng.uniform(y_lo, y_hi)
        # Fit a line y = m x + b
        try:
            m, b = np.polyfit(xs, ys, 1)
        except Exception:
            m = np.nan
            b = np.nan
        slopes[i] = m
        intercepts[i] = b
        # compute x-intercept; guard divide-by-zero
        if np.isfinite(m) and m != 0:
            xints[i] = -b / m
        else:
            xints[i] = np.nan

    # determine units
    x_unit = _get_unit(x)
    y_unit = _get_unit(y)
    slope_unit = None
    yint_unit = None
    xint_unit = None
    try:
        if x_unit is not None and y_unit is not None:
            slope_unit = y_unit / x_unit
        if y_unit is not None:
            yint_unit = y_unit
        if x_unit is not None:
            xint_unit = x_unit
    except Exception:
        slope_unit = None
        yint_unit = None
        xint_unit = None

    slope_dq = _mk_cq_from_samples(slopes, "slope", slope_unit)
    yint_dq = _mk_cq_from_samples(intercepts, "y-intercept", yint_unit)
    xint_dq = _mk_cq_from_samples(xints, "x-intercept", xint_unit)

    result = {"slope": slope_dq, "y-intercept": yint_dq, "x-intercept": xint_dq}
    expr = _build_regression_expr(result, x_symbol="x")

    if x_name is None:
        x_name = _infer_var_name(x, getattr(x, "name", None) or "x")
    if y_name is None:
        y_name = _infer_var_name(y, getattr(y, "name", None) or "y")

    model = LinearModel(
        expr,
        result,
        x_name,
        y_name,
        x_unit,
        y_unit,
        x_quantity_name=x_quantity_name,
        y_quantity_name=y_quantity_name,
    )
    return result, model


def _prepare_model_expression(model_expr: str | sp.Expr) -> sp.Expr:
    if isinstance(model_expr, sp.Expr):
        return model_expr
    if isinstance(model_expr, str):
        cleaned = _clean_sympy_text(model_expr)
        locals_map = expr_registry.get_sympify_locals()
        return sp.sympify(cleaned, locals=locals_map)
    raise TypeError("model_expr must be a string or sympy expression")


def _unit_dimensionality_vector(unit: Any) -> dict[str, sp.Expr]:
    try:
        dim = ureg.Unit(unit).dimensionality
    except Exception:
        raise ValueError(f"Could not read dimensionality from unit: {unit}")
    out: dict[str, sp.Expr] = {}
    try:
        items = dim.items()
    except Exception:
        items = []
    for k, v in items:
        key = str(k)
        try:
            out[key] = sp.Rational(v)
        except Exception:
            out[key] = sp.nsimplify(float(v))
    return out


def _combine_dim_vectors_add(a: dict[str, sp.Expr], b: dict[str, sp.Expr]) -> dict[str, sp.Expr]:
    keys = set(a.keys()) | set(b.keys())
    out: dict[str, sp.Expr] = {}
    for k in keys:
        out[k] = sp.simplify(a.get(k, sp.Integer(0)) + b.get(k, sp.Integer(0)))
    return out


def _scale_dim_vector(vec: dict[str, sp.Expr], scale: sp.Expr) -> dict[str, sp.Expr]:
    out: dict[str, sp.Expr] = {}
    for k, v in vec.items():
        out[k] = sp.simplify(v * scale)
    return out


def _vector_basis_keys(*vecs: dict[str, sp.Expr]) -> list[str]:
    keys: set[str] = set()
    for vec in vecs:
        keys.update(vec.keys())
    return sorted(keys)


def _build_unit_from_dimensionality(
    target: dict[str, sp.Expr],
    x_unit: Any,
    y_unit: Any,
) -> Any:
    # Prefer concise units expressed in y/x terms when possible.
    x_vec = _unit_dimensionality_vector(x_unit)
    y_vec = _unit_dimensionality_vector(y_unit)
    basis = _vector_basis_keys(target, x_vec, y_vec)

    ay, ax = sp.symbols("_ay _ax")
    eqs: list[sp.Expr] = []
    for k in basis:
        eqs.append(
            sp.simplify(
                ay * y_vec.get(k, sp.Integer(0))
                + ax * x_vec.get(k, sp.Integer(0))
                - target.get(k, sp.Integer(0))
            )
        )

    try:
        sol_set = sp.linsolve(eqs, (ay, ax))
    except Exception:
        sol_set = sp.EmptySet

    if sol_set != sp.EmptySet:
        sol = next(iter(sol_set), None)
        if sol is not None and len(sol) == 2:
            y_pow, x_pow = sol
            if not y_pow.free_symbols and not x_pow.free_symbols:
                # Verify reconstructed vector matches exactly.
                recon: dict[str, sp.Expr] = {}
                for k in basis:
                    recon[k] = sp.simplify(
                        y_pow * y_vec.get(k, sp.Integer(0))
                        + x_pow * x_vec.get(k, sp.Integer(0))
                    )
                if all(sp.simplify(recon[k] - target.get(k, sp.Integer(0))) == 0 for k in basis):
                    try:
                        unit_out = ureg.dimensionless
                        if sp.simplify(y_pow) != 0:
                            unit_out = unit_out * (ureg.Unit(y_unit) ** float(y_pow))
                        if sp.simplify(x_pow) != 0:
                            unit_out = unit_out * (ureg.Unit(x_unit) ** float(x_pow))
                        return unit_out
                    except Exception:
                        pass

    base_unit_map = {
        "[length]": ureg.meter,
        "[mass]": ureg.kilogram,
        "[time]": ureg.second,
        "[current]": ureg.ampere,
        "[temperature]": ureg.kelvin,
        "[substance]": ureg.mole,
        "[luminosity]": ureg.candela,
    }

    unit_out = ureg.dimensionless
    for dim_key, exponent in target.items():
        if sp.simplify(exponent) == 0:
            continue
        base_u = base_unit_map.get(dim_key)
        if base_u is None:
            raise ValueError(
                f"Unsupported base dimension '{dim_key}' while building parameter unit"
            )
        try:
            unit_out = unit_out * (base_u ** float(exponent))
        except Exception as e:
            raise ValueError(
                f"Could not build unit power for base dimension '{dim_key}' exponent {exponent}"
            ) from e
    return unit_out


def _infer_curve_fit_parameter_units(
    expr: sp.Expr,
    x_sym: sp.Symbol,
    fit_syms: list[sp.Symbol],
    param_keys: list[str],
    x_unit: Any,
    y_unit: Any,
) -> dict[str, Any]:
    if x_unit is None or y_unit is None:
        raise ValueError("randomized_curve_fit requires non-None units on both x and y")

    x_unit_obj = ureg.Unit(x_unit)
    y_unit_obj = ureg.Unit(y_unit)

    x_vec = _unit_dimensionality_vector(x_unit_obj)
    y_vec = _unit_dimensionality_vector(y_unit_obj)

    unknown_dim: dict[tuple[str, str], sp.Symbol] = {}
    all_basis: set[str] = set(x_vec.keys()) | set(y_vec.keys())
    for p in fit_syms:
        for dim_key in all_basis:
            unknown_dim[(p.name, dim_key)] = sp.Symbol(f"_u_{p.name}_{dim_key}", real=True)

    constraints: list[tuple[str, sp.Expr]] = []

    def _zero_vec() -> dict[str, sp.Expr]:
        return {k: sp.Integer(0) for k in all_basis}

    def _vec_for_symbol(sym: sp.Symbol) -> dict[str, sp.Expr]:
        if sym == x_sym:
            return {k: x_vec.get(k, sp.Integer(0)) for k in all_basis}
        if sym in fit_syms:
            return {k: unknown_dim[(sym.name, k)] for k in all_basis}
        # Any other free symbol is treated as dimensionless constant.
        return _zero_vec()

    def _visit(e: sp.Expr) -> dict[str, sp.Expr]:
        if e.is_Number or e is sp.pi or e is sp.E:
            return _zero_vec()

        if e.is_Symbol:
            return _vec_for_symbol(e)

        if e.is_Add:
            args = list(e.args)
            if not args:
                return _zero_vec()
            ref = _visit(args[0])
            for arg in args[1:]:
                cur = _visit(arg)
                for k in all_basis:
                    constraints.append((k, sp.simplify(cur.get(k, 0) - ref.get(k, 0))))
            return ref

        if e.is_Mul:
            out = _zero_vec()
            for arg in e.args:
                out = _combine_dim_vectors_add(out, _visit(arg))
            return out

        if e.is_Pow:
            base, exponent = e.args
            base_vec = _visit(base)
            if not exponent.is_Number:
                raise ValueError(
                    "Could not infer units: non-numeric exponent in model expression"
                )
            exp_val = sp.nsimplify(exponent)
            return _scale_dim_vector(base_vec, exp_val)

        if e.is_Function or isinstance(e, sp.Function):
            fname = e.func.__name__
            arg_vecs = [_visit(a) for a in e.args]

            if fname == "sqrt":
                if len(arg_vecs) != 1:
                    raise ValueError("Could not infer units: sqrt expects one argument")
                return _scale_dim_vector(arg_vecs[0], sp.Rational(1, 2))

            if fname == "Abs":
                if len(arg_vecs) != 1:
                    raise ValueError("Could not infer units: Abs expects one argument")
                return arg_vecs[0]

            if fname in ("sin", "cos", "tan", "log", "exp", "asin", "acos", "atan"):
                for av in arg_vecs:
                    for k in all_basis:
                        constraints.append((k, sp.simplify(av.get(k, 0))))
                return _zero_vec()

            raise ValueError(f"Could not infer units: unsupported function '{fname}' in model")

        raise ValueError(f"Could not infer units for model term: {sp.sstr(e)}")

    expr_vec = _visit(expr)
    for k in all_basis:
        constraints.append((k, sp.simplify(expr_vec.get(k, 0) - y_vec.get(k, 0))))

    solved_vectors: dict[str, dict[str, sp.Expr]] = {
        p.name: {k: sp.Integer(0) for k in all_basis} for p in fit_syms
    }

    for k in sorted(all_basis):
        unknowns = [unknown_dim[(p.name, k)] for p in fit_syms]
        eqs = [sp.simplify(eq) for dim_key, eq in constraints if dim_key == k]
        eqs = [eq for eq in eqs if eq != 0]

        if not eqs:
            raise ValueError(
                f"Could not infer units uniquely for curve-fit parameters (no constraints in {k})"
            )

        for eq in eqs:
            if not (set(eq.free_symbols) & set(unknowns)) and sp.simplify(eq) != 0:
                raise ValueError(
                    f"Inconsistent unit constraints in model for base dimension {k}"
                )

        try:
            sol_set = sp.linsolve(eqs, unknowns)
        except Exception as e:
            raise ValueError(
                f"Could not solve unit constraints for base dimension {k}: {e}"
            ) from e

        if sol_set == sp.EmptySet:
            raise ValueError(
                f"Inconsistent unit constraints for base dimension {k}"
            )

        sol = next(iter(sol_set), None)
        if sol is None:
            raise ValueError(
                f"Could not infer units for base dimension {k}"
            )

        for idx, p in enumerate(fit_syms):
            v = sp.simplify(sol[idx])
            if v.free_symbols:
                raise ValueError(
                    f"Could not infer a unique unit for parameter '{p.name}'"
                )
            solved_vectors[p.name][k] = v

    unit_map_by_symbol: dict[str, Any] = {}
    for p in fit_syms:
        unit_map_by_symbol[p.name] = _build_unit_from_dimensionality(
            solved_vectors[p.name],
            x_unit_obj,
            y_unit_obj,
        )

    result: dict[str, Any] = {}
    by_symbol_name = {s.name: i for i, s in enumerate(fit_syms)}
    for i, key in enumerate(param_keys):
        sym_name = fit_syms[i].name
        if sym_name not in by_symbol_name:
            raise ValueError(f"Missing unit solution for parameter symbol '{sym_name}'")
        result[key] = unit_map_by_symbol[sym_name]
    return result


def _randomized_curve_fit(
    x: Any,
    y: Any,
    model_expr: str | sp.Expr,
    *,
    x_symbol: str | sp.Symbol | None = None,
    niter: int = 2000,
    seed: int | None = 0,
    rng: np.random.Generator | None = None,
    x_name: Optional[str] = None,
    y_name: Optional[str] = None,
    param_names: Optional[Iterable[str]] = None,
    data: Optional[dict[str, Any]] = None,
    p0: Optional[Iterable[float]] = None,
    bounds: tuple[Any, Any] = (-np.inf, np.inf),
    auto_init: bool = True,
    auto_bounds: bool = True,
    debug_fit: bool = False,
    return_diagnostics: bool = False,
    maxfev: int = 20000,
) -> Any:
    """Randomized nonlinear fit using a SymPy model expression.

    This samples x/y endpoints (`nval +/- nunc`) each iteration and fits the
    user model with SciPy. Parameters are returned in a named dictionary, e.g.
    `params["Voff"]`, `params["V0"]`, `params["tau"]`.

    Friendly per-parameter controls can be passed via `data`, e.g.
    data={"i0": [18.0, 10.0, 25.0], "tau": [90.0, 1e-6, 1e6]} where each
    entry is [guess, lower_bound, upper_bound].
    """
    if _scipy_curve_fit is None:
        raise ImportError("randomized_curve_fit requires scipy. Install scipy to use this method.")

    if rng is None:
        rng = np.random.default_rng(seed)

    x, y, x_name, y_name = _resolve_xy_and_names(x, y, x_name=x_name, y_name=y_name)
    x_quantity_name = str(getattr(x, "name", "") or x_name or "x")
    y_quantity_name = str(getattr(y, "name", "") or y_name or "y")
    x_unit = _get_unit(x)
    y_unit = _get_unit(y)
    if x_unit is None or y_unit is None:
        raise ValueError(
            "randomized_curve_fit requires x and y to have explicit units (dimensionless allowed)."
        )

    if x_name is None:
        x_name = _infer_var_name(x, getattr(x, "name", None) or "x")
    if y_name is None:
        y_name = _infer_var_name(y, getattr(y, "name", None) or "y")

    expr = _prepare_model_expression(model_expr)
    x_sym = _as_symbol(x_symbol if x_symbol is not None else x_name)

    free_syms = set(expr.free_symbols)
    if x_sym not in free_syms:
        fallback_x = sp.Symbol("x")
        if fallback_x in free_syms:
            x_sym = fallback_x
        else:
            syms = sorted([s.name for s in free_syms])
            raise ValueError(
                f"Model expression must include x symbol '{x_sym}'. Found symbols: {syms}"
            )

    fit_syms = sorted([s for s in free_syms if s != x_sym], key=lambda s: s.name)
    if not fit_syms:
        raise ValueError("Model expression must include at least one fit parameter besides x.")

    default_names = [s.name for s in fit_syms]
    if param_names is None:
        param_keys = default_names
    else:
        param_keys = [str(n) for n in param_names]
        if len(param_keys) != len(fit_syms):
            raise ValueError("param_names length must match the number of fit parameters")
        if len(set(param_keys)) != len(param_keys):
            raise ValueError("param_names must be unique")

    param_units = _infer_curve_fit_parameter_units(
        expr,
        x_sym,
        fit_syms,
        param_keys,
        x_unit,
        y_unit,
    )

    xv, xunc = _get_numeric_arrays(x)
    yv, yunc = _get_numeric_arrays(y)
    if xv.size != yv.size:
        raise ValueError("x and y must have the same number of points")
    if xv.size < len(fit_syms):
        raise ValueError(
            f"Need at least {len(fit_syms)} points to fit {len(fit_syms)} parameters; got {xv.size}"
        )

    x_lo = xv - xunc
    x_hi = xv + xunc
    y_lo = yv - yunc
    y_hi = yv + yunc

    modules = [
        {"Abs": np.abs},
        "numpy",
        "sympy",
    ]
    fn = sp.lambdify((x_sym, *fit_syms), expr, modules=modules)

    if p0 is None:
        if auto_init:
            p0_arr = _infer_initial_guess(xv, yv, param_keys)
        else:
            median_y = float(np.nanmedian(yv)) if np.isfinite(np.nanmedian(yv)) else 1.0
            p0_arr = np.ones(len(fit_syms), dtype=float)
            p0_arr[0] = median_y
    else:
        p0_arr = np.asarray(list(p0), dtype=float)
        if p0_arr.size != len(fit_syms):
            raise ValueError("p0 length must match the number of fit parameters")

    using_default_bounds = bool(np.isscalar(bounds[0]) and np.isscalar(bounds[1]) and np.isneginf(bounds[0]) and np.isposinf(bounds[1]))
    if auto_bounds and using_default_bounds:
        low_arr, high_arr = _infer_bounds(xv, yv, param_keys)
    else:
        low_arr, high_arr = _coerce_bounds(bounds, len(fit_syms))

    p0_arr, low_arr, high_arr = _apply_parameter_data_controls(
        param_keys,
        p0_arr,
        low_arr,
        high_arr,
        data,
    )

    # Ensure initial guesses stay strictly within finite bound intervals.
    for i in range(len(p0_arr)):
        lo = low_arr[i]
        hi = high_arr[i]
        if np.isfinite(lo) and p0_arr[i] <= lo:
            p0_arr[i] = lo + max(1e-9, 1e-6 * (abs(lo) + 1.0))
        if np.isfinite(hi) and p0_arr[i] >= hi:
            p0_arr[i] = hi - max(1e-9, 1e-6 * (abs(hi) + 1.0))
        if not np.isfinite(p0_arr[i]):
            p0_arr[i] = 1.0

    samples: dict[str, np.ndarray] = {
        key: np.full(niter, np.nan, dtype=float) for key in param_keys
    }
    n_params = len(fit_syms)
    # Store SciPy ier status per iteration; 1..4 indicate success.
    converged = np.full(niter, np.nan, dtype=float)
    rmse = np.full(niter, np.nan, dtype=float)
    r_squared = np.full(niter, np.nan, dtype=float)
    covariance = np.full((niter, n_params, n_params), np.nan, dtype=float)
    correlation = np.full((niter, n_params, n_params), np.nan, dtype=float)
    correlation_condition = np.full(niter, np.nan, dtype=float)

    current_p0 = np.asarray(p0_arr, dtype=float)
    fit_failures = 0
    warning_count = 0

    for i in range(niter):
        xs = rng.uniform(x_lo, x_hi)
        ys = rng.uniform(y_lo, y_hi)
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always", _OptimizeWarning)
                try:
                    fit_out = _scipy_curve_fit(
                        fn,
                        xs,
                        ys,
                        p0=current_p0,
                        bounds=(low_arr, high_arr),
                        maxfev=maxfev,
                        full_output=True,
                    )
                    popt, pcov, _, _, ier = fit_out
                except TypeError:
                    popt, pcov = _scipy_curve_fit(
                        fn,
                        xs,
                        ys,
                        p0=current_p0,
                        bounds=(low_arr, high_arr),
                        maxfev=maxfev,
                    )
                    ier = 1
            warning_count += sum(1 for w in caught if isinstance(w.message, _OptimizeWarning))
            popt = np.asarray(popt, dtype=float)
            if popt.size != len(fit_syms):
                raise ValueError("Unexpected fit parameter shape")
            ier_int = int(ier)
            converged[i] = float(ier_int)
            pcov_arr = np.asarray(pcov, dtype=float)
            if pcov_arr.shape == (n_params, n_params):
                covariance[i, :, :] = pcov_arr
                corr_i, cond_i = _corr_from_cov(pcov_arr)
                correlation[i, :, :] = corr_i
                correlation_condition[i] = cond_i

            yhat = np.asarray(fn(xs, *popt), dtype=float)
            if yhat.shape != ys.shape:
                yhat = np.atleast_1d(yhat).reshape(np.atleast_1d(ys).shape)
            resid = np.asarray(ys, dtype=float) - yhat
            rmse[i] = float(np.sqrt(np.nanmean(resid ** 2))) if np.any(np.isfinite(resid)) else float("nan")
            r_squared[i] = _r_squared(np.asarray(ys, dtype=float), yhat)

            for j, key in enumerate(param_keys):
                samples[key][i] = popt[j]
            current_p0 = popt
        except Exception:
            fit_failures += 1
            continue

    params = {key: _mk_cq_from_samples(samples[key], key, unit=param_units[key]) for key in param_keys}

    subs_map = {
        fit_syms[j]: sp.Float(_cq_center(params[param_keys[j]]))
        for j in range(len(fit_syms))
        if np.isfinite(_cq_center(params[param_keys[j]]))
    }
    fitted_expr = expr.subs(subs_map)

    model = CurveFitModel(
        fitted_expr=fitted_expr,
        params=params,
        x_symbol=str(x_sym),
        x_name=x_name,
        y_name=y_name,
        x_unit=x_unit,
        y_unit=y_unit,
        original_expr=expr,
        parameter_symbols=fit_syms,
        parameter_names=param_keys,
        x_quantity_name=x_quantity_name,
        y_quantity_name=y_quantity_name,
    )
    if debug_fit:
        successes = int(np.sum(np.isin(converged, [1.0, 2.0, 3.0, 4.0])))
        model.fit_diagnostics = {
            "iterations": int(niter),
            "successes": successes,
            "failures": int(fit_failures),
            "optimize_warnings": int(warning_count),
            "initial_guess": [float(v) for v in p0_arr],
            "bounds_low": [float(v) for v in low_arr],
            "bounds_high": [float(v) for v in high_arr],
            "auto_init": bool(auto_init and p0 is None),
            "auto_bounds": bool(auto_bounds and using_default_bounds),
        }

    if not return_diagnostics:
        return params, model

    success_fraction = (
        float(np.sum(np.isin(converged, [1.0, 2.0, 3.0, 4.0])) / float(niter))
        if niter > 0
        else float("nan")
    )
    diagnostics = {
        "converged": converged,
        "rmse": rmse,
        "r_squared": r_squared,
        "covariance": covariance,
        "correlation": correlation,
        "correlation_condition": correlation_condition,
        "randomized_success_fraction": success_fraction,
    }
    return params, model, diagnostics


class Analyze:
    """Class wrapper providing analysis routines.

    `Analyze` exposes the same functionality as the module-level
    helpers as instance or static methods so notebooks can use
    `Analyze.randomized_best_fit(...)` if preferred.
    """

    @staticmethod
    def randomized_best_fit(
        x: Any,
        y: Any,
        niter: int = 2000,
        seed: int | None = 0,
        rng: np.random.Generator | None = None,
        x_name: Optional[str] = None,
        y_name: Optional[str] = None,
    ) -> Tuple[Dict[str, ConstantQuantity], LinearModel]:
        """Randomized best-fit linear regression.

        Returns `(params, model)` where `params` contains `ConstantQuantity`
        entries for `'slope'`, `'y-intercept'`, and `'x-intercept'`, and
        `model` is a `LinearModel` helper suitable for plotting.

        Example
        >>> params, model = Analyze.randomized_best_fit(x, y)
        >>> print(params["slope"])
        >>> print(model)
        """
        return _randomized_best_fit(x, y, niter=niter, seed=seed, rng=rng, x_name=x_name, y_name=y_name)

    @staticmethod
    def randomized_curve_fit(
        x: Any,
        y: Any,
        model_expr: str | sp.Expr,
        *,
        x_symbol: str | sp.Symbol | None = None,
        niter: int = 2000,
        seed: int | None = 0,
        rng: np.random.Generator | None = None,
        x_name: Optional[str] = None,
        y_name: Optional[str] = None,
        param_names: Optional[Iterable[str]] = None,
        data: Optional[dict[str, Any]] = None,
        p0: Optional[Iterable[float]] = None,
        bounds: tuple[Any, Any] = (-np.inf, np.inf),
        auto_init: bool = True,
        auto_bounds: bool = True,
        debug_fit: bool = False,
        return_diagnostics: bool = False,
        maxfev: int = 20000,
    ) -> Any:
        """Randomized nonlinear curve fit using a SymPy model.

        Parameters are returned in a named dictionary mirroring the linear API,
        e.g. `params["Voff"]`, `params["V0"]`, `params["tau"]`.

        `data` optionally accepts per-parameter controls using:
        `{name: [guess, low, high]}`.
        """
        return _randomized_curve_fit(
            x,
            y,
            model_expr,
            x_symbol=x_symbol,
            niter=niter,
            seed=seed,
            rng=rng,
            x_name=x_name,
            y_name=y_name,
            param_names=param_names,
            data=data,
            p0=p0,
            bounds=bounds,
            auto_init=auto_init,
            auto_bounds=auto_bounds,
            debug_fit=debug_fit,
            return_diagnostics=return_diagnostics,
            maxfev=maxfev,
        )
