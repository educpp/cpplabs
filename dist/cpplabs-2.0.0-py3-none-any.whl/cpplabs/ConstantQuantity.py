import numpy as np
from typing import Any

from .UnitAlgebra import ureg
from ._uncertainty import absolute_uncertainty_from_percent


class ConstantQuantity:
    """Container for scalar statistical /Monte-Carlo results.

    Stores numeric center and half-width uncertainty, presentation
    strings, and a pint unit. Designed to be small and independent of
    SymPy. This replaces the former `StatisticsQuantity` name.

    Operator overloads:
        - Arithmetic operators (`+`, `-`, `*`, `/`, `**`) when applied to
          `ConstantQuantity` with scalars, `MeasuredQuantity`, `DerivedQuantity`,
          or other `ConstantQuantity` instances produce lazy `DerivedQuantity`
          objects. This keeps behavior consistent with `MeasuredQuantity` and
          preserves symbolic expressions until numeric evaluation is required.
    """

    def __init__(self, nval: Any, nunc: Any, unit: str, name: str, *, symbol: str = ""):
        """Create a constant from value, uncertainty, unit, and name.

        The first two arguments may both be numeric or both be strings. When
        strings are supplied, they are retained as presentation text and
        parsed into the numeric values used for computation. Numeric values
        do not create presentation strings automatically.
        """
        if not isinstance(unit, str) or not isinstance(name, str) or not isinstance(symbol, str):
            raise TypeError("unit, name, and symbol must be strings")
        if isinstance(nval, str) != isinstance(nunc, str):
            raise TypeError("value and uncertainty must both be numeric or both be strings")

        if isinstance(nval, str):
            converted_uncertainty = absolute_uncertainty_from_percent(nval, nunc)
            if converted_uncertainty is not None:
                nunc = converted_uncertainty

            self.tval = np.atleast_1d(np.asarray(nval, dtype=str))
            self.tunc = np.atleast_1d(np.asarray(nunc, dtype=str))
            try:
                self._nval = np.asarray(float(nval), dtype=float)
                self.nunc = np.asarray(float(nunc), dtype=float)
            except (TypeError, ValueError) as exc:
                raise ValueError("value and uncertainty strings must be numeric") from exc

            # When strings are supplied, their decimal places represent the
            # intended display resolution. Keep this input path consistent
            # with MeasuredQuantity: a nonzero uncertainty must have the same
            # decimal-place count as the value. Percentage uncertainties have
            # already been converted above to the value's resolution.
            def _decimal_places(text: str) -> int:
                s = str(text).strip()
                if "e" in s or "E" in s:
                    s = s.split("e", 1)[0].split("E", 1)[0]
                s = s.lstrip("+-")
                if "." in s:
                    return len(s.split(".", 1)[1])
                return 0

            if float(self.nunc) != 0.0 and _decimal_places(nval) != _decimal_places(nunc):
                raise ValueError(
                    f"Value/uncertainty decimal places must match (got {nval} and {nunc})"
                )
        else:
            self._nval = np.asarray(nval, dtype=float)
            if nunc is None:
                self.nunc = np.zeros_like(self._nval, dtype=float)
            else:
                self.nunc = np.asarray(nunc, dtype=float)
            self.tval = None
            self.tunc = None

        if self._nval.shape != np.asarray(self.nunc).shape:
            try:
                self.nunc = np.broadcast_to(self.nunc, self._nval.shape).copy()
            except ValueError as exc:
                raise ValueError("value and uncertainty shapes are not broadcastable") from exc

        self.name = name
        self.symbol = symbol

        # Validate and normalize the unit at construction time. Empty and
        # explicit dimensionless units are both valid Pint spellings.
        try:
            self.unit = ureg.Unit(unit)
        except Exception as exc:
            raise ValueError(f"Invalid unit {unit!r}") from exc

    @property
    def nval(self) -> np.ndarray:
        return self._nval

    def to(self, target_unit: Any) -> "ConstantQuantity":
        """In-place convert numeric values and uncertainties to `target_unit`.

        Uses the package `ureg` for unit conversions. Preserves scalar
        0-d shapes where possible and updates `tval`/`tunc` strings.
        """
        if self.unit is None:
            raise ValueError("No unit set on ConstantQuantity")

        # perform conversion with pint
        vals = np.atleast_1d(self._nval).astype(float)
        uncs = np.atleast_1d(self.nunc).astype(float)

        q = (vals * self.unit).to(target_unit)
        uq = (uncs * self.unit).to(target_unit)

        # update numeric storage, keep scalar as 0-d if original was 0-d
        if self._nval.shape == ():
            self._nval = np.asarray(q.magnitude.item(), dtype=float)
        else:
            self._nval = np.asarray(q.magnitude, dtype=float)

        if np.asarray(self.nunc).shape == ():
            self.nunc = np.asarray(uq.magnitude.item(), dtype=float)
        else:
            self.nunc = np.asarray(uq.magnitude, dtype=float)

        # update presentation strings
        try:
            if self._nval.shape == ():
                self.tval = np.asarray([str(float(self._nval))], dtype=str)
            else:
                self.tval = np.asarray([str(x) for x in np.atleast_1d(self._nval)], dtype=str)
            if np.asarray(self.nunc).shape == ():
                self.tunc = np.asarray([str(float(self.nunc))], dtype=str)
            else:
                self.tunc = np.asarray([str(x) for x in np.atleast_1d(self.nunc)], dtype=str)
        except Exception:
            pass

        self.unit = ureg.Unit(target_unit)
        return self

    def format(self, **kwargs) -> str:
        """Return a formatted string or simple ASCII table for display.

        For scalar values this uses ``format_quantity``; for array values
        it renders a table via ``render_table_text``.
        """
        from .formatting import format_quantity, render_table_text

        try:
            arr = np.atleast_1d(np.asarray(self._nval))
            if arr.size == 0:
                return super().__repr__()
            if arr.size > 1:
                return render_table_text([self], header=False)
        except Exception:
            # On any unexpected error, fall back to scalar formatting
            # which itself will fall back to the object's repr if needed.
            pass

        return format_quantity(self, show_name=True, **kwargs)

    # Operator overloads: build symbolic DerivedQuantity expressions when
    # combined with scalars, `MeasuredQuantity`, `DerivedQuantity`, or
    # other `ConstantQuantity` instances. This keeps behavior consistent
    # with `MeasuredQuantity` which returns lazy `DerivedQuantity`
    # objects for arithmetic.
    def _sym_name_of_obj(self) -> str:
        if getattr(self, "name", None) and isinstance(self.name, str) and self.name.isidentifier():
            return self.name
        return f"_q{abs(id(self))}"

    def _combine_with(self, other, op: str, reverse: bool = False):
        from .DerivedQuantity import DerivedQuantity

        # other is DerivedQuantity
        if isinstance(other, DerivedQuantity):
            sources = {str(k): v for k, v in other._sources.items()}
            # include this constant as a source
            sources[self._sym_name_of_obj()] = self
            if reverse:
                expr = f"({other.expr}) {op} ({self._sym_name_of_obj()})"
            else:
                expr = f"({self._sym_name_of_obj()}) {op} ({other.expr})"
            return DerivedQuantity(expr, sources)

        # other is quantity-like (MeasuredQuantity / ConstantQuantity)
        if hasattr(other, "nval"):
            name = other._sym_name() if hasattr(other, "_sym_name") else (other.name if getattr(other, "name", "").isidentifier() else f"_q{abs(id(other))}")
            sources = {self._sym_name_of_obj(): self}
            sources[name] = other
            if reverse:
                expr = f"({name}) {op} ({self._sym_name_of_obj()})"
            else:
                expr = f"({self._sym_name_of_obj()}) {op} ({name})"
            return DerivedQuantity(expr, sources)

        # scalar fallback
        try:
            float(other)
        except Exception:
            return NotImplemented

        if reverse:
            expr = f"({other}) {op} ({self._sym_name_of_obj()})"
        else:
            expr = f"({self._sym_name_of_obj()}) {op} ({other})"
        sources = {self._sym_name_of_obj(): self}
        return DerivedQuantity(expr, sources)

    def __add__(self, other):
        return self._combine_with(other, "+")

    def __radd__(self, other):
        return self._combine_with(other, "+", reverse=True)

    def __sub__(self, other):
        return self._combine_with(other, "-")

    def __rsub__(self, other):
        return self._combine_with(other, "-", reverse=True)

    def __mul__(self, other):
        return self._combine_with(other, "*")

    def __rmul__(self, other):
        return self._combine_with(other, "*", reverse=True)

    def __truediv__(self, other):
        return self._combine_with(other, "/")

    def __rtruediv__(self, other):
        return self._combine_with(other, "/", reverse=True)

    def __neg__(self):
        from .DerivedQuantity import DerivedQuantity
        return DerivedQuantity(f"-({self._sym_name_of_obj()})", {self._sym_name_of_obj(): self})

    def __pow__(self, exponent):
        return self._combine_with(exponent, "**")

    def __str__(self) -> str:
        try:
            return self.format()
        except Exception:
            return super().__repr__()
