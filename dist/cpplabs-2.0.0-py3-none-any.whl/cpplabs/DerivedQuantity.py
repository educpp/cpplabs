"""Small helper class for creating derived physical quantities.

This provides a minimal wrapper usable from notebooks for expressions
like ``x = DerivedQuantity(y.nval[0] - y.nval[1], "Elongation")``.

The class stores numeric results in ``nval`` and uses interval arithmetic
to compute half-width uncertainties in ``nunc`` when evaluation succeeds.
Presentation strings (``tval``/``tunc``) are populated opportunistically
when values are available.
"""
from __future__ import annotations

from typing import Dict, TYPE_CHECKING
import inspect
import numpy as np

try:
    import sympy as sp
except Exception as e:
    raise ImportError(
        "SymPy is required for expression-backed DerivedQuantity. "
        "Install it with `pip install sympy`"
    ) from e

from .IntervalArithmetic import IntervalArithmetic
from .UnitAlgebra import UnitAlgebra, ureg
from . import expr_registry
import warnings

if TYPE_CHECKING:
    from .MeasuredQuantity import MeasuredQuantity


class DerivedQuantity:
    """SymPy-backed derived physical quantity (basic, lazy evaluation).

    This minimal implementation stores a SymPy expression and a mapping of
    symbol names to source `MeasuredQuantity` instances. Numeric evaluation
    is lazy: the expression is compiled with `sympy.lambdify` and evaluated
    against source `.nval` arrays when `nval` is accessed or `evaluate()` is
    called.

    Notes:
        - Uncertainties are computed via ``IntervalArithmetic`` when the
          expression is evaluated; if interval evaluation fails an error
          is raised.
        - `sympy` is required for this class.

    Operator overloads:
        - `DerivedQuantity` supports arithmetic combination with scalars,
          `MeasuredQuantity`, `ConstantQuantity`, and other
          `DerivedQuantity` objects via ``+ - * / **`` (including reflected
          variants). These return new `DerivedQuantity` instances whose
          expressions and source mappings are merged conservatively. Numeric
          evaluation remains lazy and uses the package's interval arithmetic
          semantics.
    """

    def __init__(self, expr, sources: Dict[str, "MeasuredQuantity"] | Dict[sp.Symbol, "MeasuredQuantity"] | None = None, name: str = "", *, symbol: str = "") -> None:
        # Allow the second positional argument to be the name for convenience.
        if isinstance(sources, str) and not name:
            name = sources
            sources = None

        # Accept string or SymPy expression
        if isinstance(expr, str):
            expr = sp.sympify(expr)
        if not isinstance(expr, sp.Expr):
            raise TypeError("expr must be a sympy.Expr or string parseable to one")

        # Normalize sources: accept keys as symbol names (str) or sp.Symbol
        mapping: Dict[sp.Symbol, "MeasuredQuantity"] = {}
        if sources is not None:
            for k, v in dict(sources).items():
                if isinstance(k, str):
                    mapping[sp.Symbol(k)] = v
                elif isinstance(k, sp.Symbol):
                    mapping[k] = v
                else:
                    raise TypeError("sources keys must be symbol names (str) or sympy.Symbol")

        # If sources were not provided, try to recover them from SymPy
        # symbols that carry a `_dq_source` attribute (set by MeasuredQuantity).
        if sources is None:
            for sym in expr.free_symbols:
                if sym in mapping:
                    continue
                src = getattr(sym, "_dq_source", None)
                if src is not None:
                    mapping[sym] = src

            frame = inspect.currentframe()
            try:
                caller = frame.f_back if frame is not None else None
                if caller is not None:
                    scope = dict(caller.f_globals)
                    scope.update(caller.f_locals)
                    for sym in expr.free_symbols:
                        if sym in mapping:
                            continue
                        obj = scope.get(sym.name, None)
                        if obj is not None and hasattr(obj, "nval"):
                            mapping[sym] = obj
            finally:
                del frame

            missing = sorted([s.name for s in expr.free_symbols if s not in mapping])
            if missing:
                raise ValueError(
                    "No sources or definitions provided for symbols: "
                    + ", ".join(missing)
                )

        self.expr: sp.Expr = expr
        self._sources: Dict[sp.Symbol, "MeasuredQuantity"] = mapping
        self.name = str(name or expr)
        if not isinstance(symbol, str):
            raise TypeError("symbol must be a string")
        self.symbol = symbol

        # Compute unit using UnitAlgebra; unit errors are treated as fatal.
        try:
            u = UnitAlgebra(self.expr, self._sources).evaluate()
            # store the pint Unit object (not a Quantity). Conversions
            # like `.to("N")` should be performed by callers using a
            # pint Quantity constructed from this unit when needed.
            self.unit = u
        except ImportError:
            warnings.warn("pint is not installed; DerivedQuantity.unit set to None", UserWarning)
            self.unit = None
        except Exception as e:
            raise ValueError(f"Unit computation failed for DerivedQuantity: {e}") from e

        # Lazy numeric storage
        self._nval: np.ndarray | None = None

        # For this basic prototype, uncertainties/presentation are None
        self.nunc = None
        self.tunc = None
        self.tval = None

        # cached lambdified function (invalidated if sources change)
        self._fn = None

    def __repr__(self) -> str:  # pragma: no cover - small helper
        state = "evaluated" if self._nval is not None else "unevaluated"
        return f"DerivedQuantity(name={self.name!r}, expr={sp.srepr(self.expr)!s}, {state})"

    def evaluate(self) -> np.ndarray:
        """Evaluate the stored expression against source `.nval` arrays and
        cache the numeric result in `self._nval`.

        Returns the numeric array (1-D numpy array).
        """
        # collect symbols in deterministic order
        syms = sorted(self.expr.free_symbols, key=lambda s: s.name)

        # build argument list from sources
        args = []
        for s in syms:
            if s not in self._sources:
                raise ValueError(f"No source MeasuredQuantity provided for symbol '{s}'")
            src = self._sources[s]
            # expect source to provide numeric `.nval`
            if not hasattr(src, "nval"):
                raise TypeError(f"Source for symbol '{s}' has no 'nval' attribute")
            arr = np.atleast_1d(np.asarray(src.nval))
            args.append(arr)

        # Determine expected broadcast length. If cached numeric values
        # exist but their length no longer matches the current source
        # arrays, the cache is stale and we must recompute.
        expected_len = max((a.size for a in args), default=1)
        if self._nval is not None and np.atleast_1d(self._nval).size == expected_len:
            return self._nval

        # Compute interval-based result and uncertainty using IntervalArithmetic
        try:
            ia = IntervalArithmetic(self.expr, self._sources)
            mids, halfws = ia.evaluate()
            # Store numeric result and uncertainty (half-width)
            self._nval = np.atleast_1d(np.asarray(mids, dtype=float))
            self.nunc = np.atleast_1d(np.asarray(halfws, dtype=float))
        except Exception:
            warnings.warn(
                "Interval arithmetic failed; cannot compute DerivedQuantity.",
                UserWarning,
            )
            raise

        return self._nval

    @property
    def nval(self) -> np.ndarray:
        return self.evaluate()

    def to(self, unit: str):
        """Convert this DerivedQuantity in-place to `unit`.

        This updates `self._nval`/`self.nval` and `self.nunc` (if present)
        by converting the numeric arrays from `self.unit` to `unit` using
        `pint`. The stored `self.unit` is updated to the new unit (a
        pint `Unit`). Returns `self`.
        """
        if self.unit is None:
            raise ValueError("DerivedQuantity has no unit to convert from")

        # Ensure numeric values are available
        self.evaluate()

        try:
            target = ureg.Unit(unit)
        except Exception as e:
            raise ValueError(f"Could not parse target unit '{unit}': {e}") from e

        # Convert central values
        vals = np.atleast_1d(np.asarray(self._nval, dtype=float))
        qty_vals = ureg.Quantity(vals, self.unit)
        try:
            conv_vals = qty_vals.to(target).magnitude
        except Exception as e:
            raise ValueError(f"Unit conversion failed: {e}") from e

        # Convert uncertainties if present
        if self.nunc is None:
            conv_unc = None
        else:
            unc = np.atleast_1d(np.asarray(self.nunc, dtype=float))
            qty_unc = ureg.Quantity(unc, self.unit)
            conv_unc = qty_unc.to(target).magnitude

        # Update internal numeric storage
        self._nval = np.atleast_1d(np.asarray(conv_vals, dtype=float))
        self.nunc = np.atleast_1d(np.asarray(conv_unc, dtype=float)) if conv_unc is not None else None

        # Update presentation strings if present
        try:
            self.tval = np.asarray([str(x) for x in self._nval], dtype=str)
        except Exception:
            pass
        if self.nunc is not None:
            try:
                self.tunc = np.asarray([str(x) for x in self.nunc], dtype=str)
            except Exception:
                pass

        # Update stored unit (store the pint Unit)
        self.unit = target

        return self

    def format(self, **kwargs) -> str:
        from .formatting import format_quantity, render_table_text

        # Ensure numeric evaluation so format obtains numeric values.
        # If evaluation raises because sources are uninitialized, fall
        # back to the object's repr rather than surfacing errors.
        try:
            self.evaluate()
        except Exception:
            try:
                return super().__repr__()
            except Exception:
                # If repr itself fails for some reason, continue to
                # scalar formatting fallback below.
                pass

        # If this DerivedQuantity holds multiple numeric rows, render a
        # compact ASCII table showing each row rather than a single scalar
        # summary. This ensures `print(x)` prints the whole rows for x.
        try:
            arr = np.atleast_1d(np.asarray(self._nval if self._nval is not None else self.nval))
            if arr.size > 1:
                return render_table_text([self], header=False)
        except Exception:
            # Fall through to scalar formatting on any error
            pass

        return format_quantity(self, show_name=True, **kwargs)

    def __str__(self) -> str:
        try:
            return self.format()
        except Exception:
            return super().__repr__()

    # --- Arithmetic operator overloads (produce DerivedQuantity) ---
    def _sym_name_of_obj(self, obj) -> str:
        # Prefer an identifier-like `name` if available, otherwise
        # fall back to a stable generated id.
        nm = getattr(obj, "name", None)
        if isinstance(nm, str) and nm.isidentifier():
            return nm
        # Allow MeasuredQuantity helper if present
        try:
            if hasattr(obj, "_sym_name"):
                return obj._sym_name()
        except Exception:
            pass
        return f"_q{abs(id(obj))}"

    def _combine_with(self, other, op: str, reverse: bool = False):
        # Combine self (DerivedQuantity) with other (scalar/MeasuredQuantity/DerivedQuantity)
        # into a new DerivedQuantity representing (self expr) op (other expr).
        # Build expression text and merge source mappings conservatively.
        if isinstance(other, DerivedQuantity):
            # merge sources
            sources = {str(k): v for k, v in self._sources.items()}
            sources.update({str(k): v for k, v in other._sources.items()})
            if reverse:
                expr_text = f"({other.expr}) {op} ({self.expr})"
            else:
                expr_text = f"({self.expr}) {op} ({other.expr})"
            return DerivedQuantity(expr_text, sources)

        # If other is quantity-like (MeasuredQuantity/ConstantQuantity)
        if hasattr(other, "nval"):
            name = self._sym_name_of_obj(other)
            sources = {str(k): v for k, v in self._sources.items()}
            sources[name] = other
            if reverse:
                expr_text = f"({name}) {op} ({self.expr})"
            else:
                expr_text = f"({self.expr}) {op} ({name})"
            return DerivedQuantity(expr_text, sources)

        # Fallback: assume scalar convertible to float
        try:
            float(other)
        except Exception:
            return NotImplemented

        if reverse:
            expr_text = f"({other}) {op} ({self.expr})"
        else:
            expr_text = f"({self.expr}) {op} ({other})"
        sources = {str(k): v for k, v in self._sources.items()}
        return DerivedQuantity(expr_text, sources)

    def __add__(self, other):
        return self._combine_with(other, "+")

    def __radd__(self, other):
        return self._combine_with(other, "+", reverse=True)

    def __sub__(self, other):
        return self._combine_with(other, "-")

    def __rsub__(self, other):
        return self._combine_with(other, "-", reverse=True)

    def __mul__(self, other):
        return self._combine_with(other, "*")

    def __rmul__(self, other):
        return self._combine_with(other, "*", reverse=True)

    def __truediv__(self, other):
        return self._combine_with(other, "/")

    def __rtruediv__(self, other):
        return self._combine_with(other, "/", reverse=True)

    def __neg__(self):
        return DerivedQuantity(f"-({self.expr})", dict(self._sources))

    def __pow__(self, exponent):
        return self._combine_with(exponent, "**")
