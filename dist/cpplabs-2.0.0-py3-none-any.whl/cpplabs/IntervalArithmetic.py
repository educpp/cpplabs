"""Interval arithmetic helper using mpmath.iv for DerivedQuantity uncertainties.

This provides a minimal elementwise interval evaluator for a SymPy
expression given source `MeasuredQuantity` objects. For each element of
the source numeric arrays we build mpmath.iv intervals from the
`nval`/`nunc` pair, evaluate the expression using the interval
arithmetic, and return numeric midpoint and half-width (used as
`nval` and `nunc` respectively).

Note: for this prototype we conservatively combine uncertainties by
adding the `nunc` values across operations as requested (i.e. we
don't implement full interval propagation optimizations here).
"""
from __future__ import annotations

from typing import Dict
import numpy as np

try:
    import mpmath as mp
    from mpmath import iv
except Exception as e:
    raise ImportError("mpmath (with iv) is required for IntervalArithmetic; install with `pip install mpmath`") from e

import sympy as sp
import warnings

from . import expr_registry
from .UnitAlgebra import ureg, AUTO_CONVERT_UNITS, UnitAlgebra

_conversion_warnings: set = set()


class IntervalArithmetic:
    """Evaluate a SymPy expression with interval inputs (elementwise).

    Usage:
      ia = IntervalArithmetic(expr, sources)
      nval_arr, nunc_arr = ia.evaluate()

    `sources` should be a mapping from SymPy Symbol or symbol-name (str)
    to objects exposing `.nval` and `.nunc` (numeric arrays/scalars).
    """

    def __init__(self, expr: sp.Expr, sources: Dict[sp.Symbol, object]):
        if not isinstance(expr, sp.Expr):
            raise TypeError("expr must be a sympy.Expr")
        self.expr = expr
        # Normalize symbol keys to sympy.Symbol
        self.sources: Dict[sp.Symbol, object] = {}
        for k, v in dict(sources).items():
            if isinstance(k, str):
                self.sources[sp.Symbol(k)] = v
            elif isinstance(k, sp.Symbol):
                self.sources[k] = v
            else:
                raise TypeError("sources keys must be symbol names (str) or sympy.Symbol")

        # Use the original expression for lambdify; we'll supply interval
        # constants for common scalar symbols (pi, e) via the modules map
        expr_for_lambdify = self.expr

        # Replace numeric and common symbolic constants in the expression
        # with uniquely-named placeholder symbols so we can supply
        # interval-valued constants at call time. This ensures the
        # lambdified function accepts all placeholders as arguments and
        # we can pass iv.mpf values for them alongside source symbols.
        atoms = set(expr_for_lambdify.atoms())
        const_atoms = [a for a in atoms if isinstance(a, sp.Number) or a is sp.pi or a is sp.E]

        self._const_map = {}
        replace_map = {}
        idx = 0
        for atom in const_atoms:
            name = f"__const_{idx}"
            idx += 1
            sym = sp.Symbol(name)
            replace_map[atom] = sym
            # record numeric float value for later (mpmath float)
            if atom is sp.pi:
                val = float(mp.pi)
            elif atom is sp.E:
                val = float(mp.e)
            else:
                try:
                    val = float(atom)
                except Exception:
                    val = float(sp.N(atom))
            self._const_map[sym] = val

        if replace_map:
            expr_for_lambdify = expr_for_lambdify.xreplace(replace_map)

        # Prepare lambdified function using mpmath (interval-aware).
        syms = sorted(expr_for_lambdify.free_symbols, key=lambda s: s.name)
        interval_map = expr_registry.get_interval_map(iv)
        self._fn = sp.lambdify(
            tuple(syms),
            expr_for_lambdify,
            modules=[interval_map],
        )
        self._syms = syms

    def evaluate(self):
        """Evaluate expression elementwise returning (nval, nunc).

        Returns two 1-D numpy arrays: midpoint (`nval`) and half-width
        (`nunc`).
        """
        # Collect numeric arrays for each *source* symbol (exclude
        # constant placeholders which are in self._const_map).
        needs_base_units = False
        if AUTO_CONVERT_UNITS:
            try:
                ua = UnitAlgebra(self.expr, self.sources)
                ua.evaluate()
                needs_base_units = ua.requires_base_units()
            except Exception:
                needs_base_units = False
        source_syms = [s for s in self._syms if s not in getattr(self, "_const_map", {})]
        arrays = []
        widths = []
        for s in source_syms:
            if s not in self.sources:
                raise ValueError(f"No source provided for symbol '{s}'")
            src = self.sources[s]
            if not hasattr(src, "nval"):
                raise TypeError(f"Source for {s} has no .nval")
            nval = np.asarray(src.nval)
            nunc = getattr(src, "nunc", None)
            if nunc is None:
                nunc = np.zeros_like(nval, dtype=float)
            else:
                nunc = np.asarray(nunc)

            if AUTO_CONVERT_UNITS and needs_base_units:
                unit = getattr(src, "unit", None)
                if unit not in (None, ""):
                    try:
                        src_unit = ureg.Unit(unit)
                        base_unit = ureg.Quantity(1, src_unit).to_base_units().units
                        if src_unit != base_unit:
                            key = (s.name, str(src_unit), str(base_unit))
                            if key not in _conversion_warnings:
                                warnings.warn(
                                    f"Auto-converting {s.name} from {src_unit} to {base_unit} for evaluation",
                                    UserWarning,
                                )
                                _conversion_warnings.add(key)
                            nval = (np.atleast_1d(nval).astype(float) * src_unit).to(base_unit).magnitude
                            nunc = (np.atleast_1d(nunc).astype(float) * src_unit).to(base_unit).magnitude
                    except Exception:
                        pass
            arrays.append(nval)
            widths.append(nunc)

        # Ensure consistent length/shape along first axis
        lengths = [int(np.atleast_1d(a).size) for a in arrays]
        if not lengths:
            # No source arrays: expression depends only on constants.
            # Evaluate once using only constant placeholders.
            full_args = []
            for sym in self._syms:
                if sym in getattr(self, "_const_map", {}):
                    v = float(self._const_map[sym])
                    full_args.append(iv.mpf([v, v]))
                else:
                    # shouldn't happen
                    full_args.append(iv.mpf([0.0, 0.0]))
            try:
                res = self._fn(*full_args)
            except Exception as e:
                raise NotImplementedError(
                    "Interval evaluation failed; a required function may not be implemented in mpmath.iv."
                ) from e
            try:
                lo = float(res.a)
                hi = float(res.b)
            except Exception:
                val = float(res)
                lo = val
                hi = val
            return np.atleast_1d(np.array([0.5 * (lo + hi)], dtype=float)), np.atleast_1d(np.array([0.5 * (hi - lo)], dtype=float))
        # If arrays have mixed lengths, allow broadcasting of length-1
        # source arrays to the common maximum length. Scalar sources are
        # intentionally broadcast without emitting a warning: this is the
        # normal way constants participate in calculations over measurements.
        if len(set(lengths)) != 1:
            max_len = max(lengths)
            # If all lengths are either 1 or max_len we can broadcast
            if all((l == 1 or l == max_len) for l in lengths):
                # perform broadcasting
                new_arrays = []
                new_widths = []
                for s, a, w in zip(source_syms, arrays, widths):
                    la = int(np.atleast_1d(a).size)
                    if la == 1 and max_len > 1:
                        new_arrays.append(np.broadcast_to(np.atleast_1d(a).reshape(-1)[0], (max_len,)))
                        # broadcast width similarly
                        wi = np.atleast_1d(w).reshape(-1)[0] if np.atleast_1d(w).size else 0.0
                        new_widths.append(np.broadcast_to(wi, (max_len,)))
                    else:
                        new_arrays.append(np.atleast_1d(a).astype(float).reshape(-1))
                        new_widths.append(np.atleast_1d(w).astype(float).reshape(-1) if np.atleast_1d(w).size else np.zeros(np.atleast_1d(a).size, dtype=float))

                arrays = new_arrays
                widths = new_widths
                n = max_len
            else:
                raise ValueError("Source numeric arrays must have the same length")
        else:
            n = lengths[0]

        mids = np.empty(n, dtype=float)
        halfws = np.empty(n, dtype=float)

        # Evaluate elementwise
        for i in range(n):
            # build interval args
            iv_args = []
            for a, w in zip(arrays, widths):
                ai = float(np.atleast_1d(a).reshape(-1)[i])
                wi = float(np.atleast_1d(w).reshape(-1)[i]) if np.atleast_1d(w).size else 0.0
                lo = ai - wi
                hi = ai + wi
                iv_args.append(iv.mpf([lo, hi]))

            # Insert any constant placeholders into the argument list in
            # the correct positions expected by the lambdified function.
            full_args = []
            for sym in self._syms:
                if sym in self._const_map:
                    # constant zero-width interval for this placeholder
                    v = float(self._const_map[sym])
                    full_args.append(iv.mpf([v, v]))
                else:
                    # consume next iv arg from the sources list
                    full_args.append(iv_args.pop(0))

            # call the lambdified function with interval arguments
            try:
                res = self._fn(*full_args)
            except Exception as e:
                raise NotImplementedError(
                    "Interval evaluation failed; a required function may not be implemented in mpmath.iv."
                ) from e

            # res is expected to be an iv interval type with .a/.b
            try:
                lo = float(res.a)
                hi = float(res.b)
            except Exception:
                # If result is scalar (mpf) treat as point interval
                val = float(res)
                lo = val
                hi = val

            mids[i] = 0.5 * (lo + hi)
            halfws[i] = 0.5 * (hi - lo)

        return mids, halfws
