"""NumPy-backed MeasuredQuantity.

Lightweight, array-oriented container for measured values and their
half-width uncertainties. The implementation separates presentation
format (string) from numeric data to support significant-figure
preservation while keeping efficient numeric arrays for computation.

Design notes
 - Public ``tval`` and ``tunc`` attributes are NumPy string arrays that
     preserve the textual representation supplied by callers (useful for
     keeping trailing zeros / sig-fig formatting).
 - Private numeric arrays ``nval`` and ``nunc`` hold the floating-point
     magnitudes used for arithmetic and analysis.
 - The canonical append API is ``add_data_point(...)``; previously present helpers
     such as ``extend`` and ``from_rows`` were removed to keep a single
     well-defined mutation path.

Key attributes on an instance
 - ``tval``: NumPy array of strings representing the stored central values
 - ``tunc``: NumPy array of strings representing the half-width uncertainties
 - ``nval``: numeric ``np.ndarray`` of central values for computation
 - ``nunc``: numeric ``np.ndarray`` of uncertainties for computation
 - ``unit``: unit string (empty when unitless)
 - ``name``: optional short label for the quantity (e.g. ``'time'``)
 - ``dim``: integer count of conceptual rows (0 for empty, N for 1-D arrays)

Convenience method
 - ``to_arrays()``: returns a dictionary of numeric arrays (``val``, ``unc``,
     ``lo``, ``hi``) plus metadata and the original string arrays (``val_str``,
     ``unc_str``). See ``to_arrays`` documentation below for exact contents.

Arithmetic operators create lazy ``DerivedQuantity`` expressions rather
than immediately computing numeric results.
"""
from __future__ import annotations

from typing import Any, Iterator, Union, Tuple, Optional

import sympy as sp

from .DerivedQuantity import DerivedQuantity
from .UnitAlgebra import ureg
from ._uncertainty import absolute_uncertainty_from_percent
import numpy as np


class MeasuredQuantity:
    """Simple NumPy-backed measured quantity.

    This class is notebook-first: quantities are created empty via
    ``MeasuredQuantity("Time", "s")`` and rows are populated by
    calls to ``add_data_point`` or via the ``%%record`` notebook magic.

    Public attributes:
    - ``tval`` / ``tunc``: NumPy string arrays preserving input formatting
    - ``nval`` / ``nunc``: numeric arrays used for computation
    - ``unit``: unit string
    - ``name``: optional short label
    - ``dim``: number of rows (0 for empty)

    Operator overloads:
    - Arithmetic operators ``+``, ``-``, ``*``, ``/``, ``**`` and their
        reflected forms construct symbolic ``DerivedQuantity`` objects.
        These expressions defer numeric evaluation until ``evaluate()``
        or ``nval`` is accessed.

    Example
    >>> t = MeasuredQuantity("Time", "s")
    >>> t.add_data_point("4.12", "0.01")
    >>> t.add_data_point("4.28", "0.01")
    >>> print(t)
    """

    def __init__(self, name: str = "", unit: str = "", *, symbol: str = "") -> None:
        """Create an empty `MeasuredQuantity` with the given `name` and `unit`.

        Rows are added via ``add_data_point(val, unc)`` where ``val`` and ``unc``
        may be numeric types or numeric strings (strings are preserved for
        presentation). The constructor accepts ``name`` and ``unit`` as
        primary parameters (positional or keyword).

        Example
        >>> d = MeasuredQuantity("Distance", "cm")
        >>> d.add_data_point("20.0", "0.1")
        """

        self.tval = np.asarray([], dtype=str)
        self.tunc = np.asarray([], dtype=str)
        self.nval = np.asarray([], dtype=float)
        self.nunc = np.asarray([], dtype=float)
        try:
            ureg.Unit(unit)
        except Exception as exc:
            raise ValueError(f"Invalid unit {unit!r}") from exc
        self.unit = str(unit or "")
        if not isinstance(symbol, str):
            raise TypeError("symbol must be a string")
        self.name = str(name or "")
        self.symbol = symbol
        self.dim = 0

    def __repr__(self) -> str:
        return f"MeasuredQuantity(name={self.name!r}, tval={self.tval!r}, tunc={self.tunc!r}, unit={self.unit!r})"

    def _sympy_(self):
        """Return a SymPy Symbol linked to this quantity.

        This enables expressions like `sp.Max(t)` where `t` is a
        MeasuredQuantity. The returned symbol carries a `_dq_source`
        attribute so DerivedQuantity can recover the source mapping.
        """
        try:
            sym = sp.Symbol(self._sym_name())
        except Exception:
            sym = sp.Symbol(f"_q{abs(id(self))}")
        try:
            setattr(sym, "_dq_source", self)
        except Exception:
            pass
        return sym

    # Keep __sympy__ for compatibility, but defer to the standard _sympy_ hook.
    def __sympy__(self):
        return self._sympy_()

    # Numeric operations (placeholders for now)
    def __add__(self, other: Any):
        pass

    def __radd__(self, other: Any):
        pass

    def __sub__(self, other: Any):
        pass

    def __rsub__(self, other: Any):
        pass

    def __mul__(self, other: Any):
        pass

    def __rmul__(self, other: Any):
        pass

    def __truediv__(self, other: Any):
        pass

    def __rtruediv__(self, other: Any):
        pass

    def __pow__(self, exponent: Any):
        pass

    # --- Symbolic operator helpers (return DerivedQuantity) ---
    def _sym_name(self) -> str:
        # Prefer a valid identifier from `name`, otherwise fall back to
        # a stable internal identifier based on object id.
        if getattr(self, "name", None) and isinstance(self.name, str) and self.name.isidentifier():
            return self.name
        return f"_q{abs(id(self))}"

    def _to_derived_with(self, op: str, other: Any, reverse: bool = False):
        # Combine MeasuredQuantity/DerivedQuantity/scalar into a DerivedQuantity
        left_sym = self._sym_name()

        # other is a MeasuredQuantity-like
        if hasattr(other, "nval"):
            right_sym = other._sym_name() if hasattr(other, "_sym_name") else (other.name if getattr(other, "name", "").isidentifier() else f"_q{abs(id(other))}")
            expr = f"({right_sym}) {op} ({left_sym})" if reverse else f"({left_sym}) {op} ({right_sym})"
            sources = {left_sym: self, right_sym: other}
            return DerivedQuantity(expr, sources)

        # other is a DerivedQuantity: merge its expression and sources
        from .DerivedQuantity import DerivedQuantity as _DQ
        if isinstance(other, _DQ):
            # build expression combining this symbol and other's expression
            other_expr = other.expr
            # convert other sources mapping keys to strings
            other_src = {str(k): v for k, v in getattr(other, "_sources", {}).items()}
            expr = f"({left_sym}) {op} ({other_expr})" if not reverse else f"({other_expr}) {op} ({left_sym})"
            sources = {left_sym: self}
            sources.update(other_src)
            return DerivedQuantity(expr, sources)

        # other is a scalar
        try:
            float(other)
        except Exception:
            return NotImplemented

        expr = f"({left_sym}) {op} ({other})" if not reverse else f"({other}) {op} ({left_sym})"
        sources = {left_sym: self}
        return DerivedQuantity(expr, sources)

    def __add__(self, other: Any):
        return self._to_derived_with("+", other)

    def __radd__(self, other: Any):
        return self._to_derived_with("+", other, reverse=True)

    def __sub__(self, other: Any):
        return self._to_derived_with("-", other)

    def __rsub__(self, other: Any):
        return self._to_derived_with("-", other, reverse=True)

    def __mul__(self, other: Any):
        return self._to_derived_with("*", other)

    def __rmul__(self, other: Any):
        return self._to_derived_with("*", other, reverse=True)

    def __truediv__(self, other: Any):
        return self._to_derived_with("/", other)

    def __rtruediv__(self, other: Any):
        return self._to_derived_with("/", other, reverse=True)

    def __neg__(self):
        return self._to_derived_with("-", 0, reverse=True)

    def __pow__(self, exponent: Any):
        return self._to_derived_with("**", exponent)


    # Convenience access
    @property
    def lo(self) -> np.ndarray:
        return self.nval - self.nunc

    @property
    def hi(self) -> np.ndarray:
        return self.nval + self.nunc

    def to_arrays(self) -> dict:
        """Return a dictionary useful for analysis routines.

        The returned dictionary contains numeric arrays suitable for
        computation as well as presentation strings and metadata. Keys:
        - ``val``: numeric ``np.ndarray`` of central values (alias of ``nval``)
        - ``unc``: numeric ``np.ndarray`` of half-width uncertainties (alias of ``nunc``)
        - ``lo``: numeric ``np.ndarray`` of lower bounds (``val - unc``)
        - ``hi``: numeric ``np.ndarray`` of upper bounds (``val + unc``)
        - ``unit``: unit string
        - ``dim``: integer count of conceptual rows
        - ``val_str``: public string array for central-value presentation
        - ``unc_str``: public string array for uncertainty presentation
        - ``name``: optional short label for the quantity

        Consumers that need numeric arrays should use the ``val``/``unc``
        entries from this dict. Presentation code can use ``val_str``/
        ``unc_str`` or the public ``tval``/``tunc`` arrays to preserve the
        originally supplied formatting.
        """
        return {"val": self.nval, "unc": self.nunc, "lo": self.lo, "hi": self.hi, "unit": self.unit, "dim": self.dim, "val_str": self.tval, "unc_str": self.tunc, "name": self.name}

    @staticmethod
    def _point_ordinal(index: int) -> str:
        number = index + 1
        if 10 <= number % 100 <= 20:
            suffix = "th"
        else:
            suffix = {1: "st", 2: "nd", 3: "rd"}.get(number % 10, "th")
        return f"{number}{suffix} data point"

    def iter_quantities(self) -> Iterator["ConstantQuantity"]:
        """Yield each data point as an independent ``ConstantQuantity``.

        Presentation strings are passed through unchanged. Each result is
        named with its one-based ordinal and receives a suffixed source symbol
        when this quantity exposes ``symbol`` or ``sym`` metadata.
        """
        from .ConstantQuantity import ConstantQuantity

        source_symbol = getattr(self, "symbol", None) or getattr(self, "sym", None) or ""
        for index in range(int(self.dim)):
            value_text = str(self.tval.ravel()[index])
            uncertainty_text = str(self.tunc.ravel()[index])
            symbol = f"{source_symbol}_{index + 1}" if source_symbol else ""
            yield ConstantQuantity(
                value_text,
                uncertainty_text,
                self.unit,
                self._point_ordinal(index),
                symbol=symbol,
            )

    def _ensure_1d(self) -> None:
        """Ensure internal arrays are 1-D sequences.

        Scalars are promoted to length-1 arrays; higher-dimensional inputs
        are flattened. This keeps the internal representation consistent
        for row-oriented operations such as ``add_data_point`` and ``extend``.
        """
        # Ensure numeric and string copies are 1-D and consistent.
        if getattr(self.nval, "ndim", 0) == 0:
            self.nval = np.atleast_1d(self.nval)
            self.nunc = np.atleast_1d(self.nunc)
            self.tval = np.atleast_1d(self.tval)
            self.tunc = np.atleast_1d(self.tunc)
        else:
            self.nval = self.nval.ravel()
            self.nunc = self.nunc.ravel()
            self.tval = self.tval.ravel()
            self.tunc = self.tunc.ravel()

    @staticmethod
    def _absolute_uncertainty_from_percent(value_text: str, uncertainty_text: str) -> str | None:
        """Convert ``percentage%counts`` input to absolute uncertainty text.

        ``counts`` is optional and represents least-significant display
        counts from ``value_text``. The result is conservatively rounded up
        to the displayed resolution of the value. ``None`` means the input is
        an ordinary absolute uncertainty rather than a percentage format.
        """
        return absolute_uncertainty_from_percent(value_text, uncertainty_text)

    def add_data_point(self, val: Union[float, int, str], unc: Optional[Union[float, int, str]] = None) -> None:
        """Append a single measurement row in-place.

        The method accepts numeric inputs or simple numeric strings (which
        are converted via ``float()``). Uncertainty strings may alternatively
        use ``"<percentage>%"`` or ``"<percentage>%<counts>"``. Counts are
        least-significant display counts from the value string. The converted
        absolute uncertainty is rounded upward to the value's displayed
        resolution. The new row is concatenated to the existing internal
        arrays; ``dim`` is updated accordingly.

        Notes
        - `add_data_point` does not accept a `unit` parameter; units are managed
            at construction time via ``MeasuredQuantity(name, unit)`` or by
            directly setting the ``unit`` attribute.
        - If ``unc`` is omitted or empty for a new row, the method inherits
            the first uncertainty already present on the quantity. If the
            quantity has no prior rows, a ``ValueError`` is raised.
        - Value and uncertainty strings must have matching decimal places
            (except when the uncertainty is exactly zero).
        - Parsing of advanced formats (significant-figure-preserving
            strings or uncertainty parentheses like ``"1.23(4)"``) is left
            for future work.

        Example
        >>> t = MeasuredQuantity("Time", "s")
        >>> t.add_data_point("4.12", "0.01")
        >>> t.add_data_point("4.28", "0.01")
        >>> reading = MeasuredQuantity("Reading", "V")
        >>> reading.add_data_point("100.0", "5%2")
        """
        # Track whether the caller omitted the uncertainty so we can create
        # an appropriately shaped empty-unc array after we know the shape
        # of the incoming `val` (especially important when `val` is array-like).
        missing_unc = unc is None

        # Prepare string and numeric representations for the incoming row(s)
        # Accept strings to preserve formatting; numeric inputs are converted
        # to strings using ``str()``.
        # Handle val input types:
        # - single string -> preserve as single-element string array
        # - iterable of strings -> preserve each string exactly
        # - numeric or iterable of numerics -> convert to numeric then string
        if isinstance(val, str):
            v_strs = np.atleast_1d(val).astype(str)
            v_text_inputs = np.ones(v_strs.shape, dtype=bool)
            try:
                v_nums = np.atleast_1d(np.asarray([float(x) for x in v_strs], dtype=float))
            except Exception:
                raise ValueError("Could not parse `val` string(s) to float")
        elif isinstance(val, (list, tuple, np.ndarray)) and all(isinstance(x, str) for x in val):
            # preserve each supplied string exactly
            v_strs = np.asarray(val, dtype=str)
            v_text_inputs = np.ones(v_strs.shape, dtype=bool)
            try:
                v_nums = np.atleast_1d(np.asarray([float(x) for x in v_strs], dtype=float))
            except Exception:
                raise ValueError("Could not parse `val` string(s) to float")
        else:
            v_nums = np.atleast_1d(np.asarray(val, dtype=float))
            # create string representation from numeric input
            v_strs = v_nums.astype(str)
            v_text_inputs = np.zeros(v_strs.shape, dtype=bool)

        if missing_unc:
            # When the caller omitted `unc` entirely, inherit the first
            # uncertainty already present on this quantity (if any); otherwise
            # default to "0". Create the u_strs/u_nums arrays filled with
            # that inherited value so subsequent logic is simpler.
            if self.tunc.size > 0:
                first_unc = str(self.tunc.ravel()[0])
            else:
                raise ValueError("Cannot add row(s) without `unc` to an empty MeasuredQuantity; first row(s) must provide uncertainties")
            u_strs = np.asarray(
                [first_unc] * int(np.asarray(v_strs).size), dtype=str
            ).reshape(np.asarray(v_strs).shape)
        elif isinstance(unc, str):
            u_strs = np.atleast_1d(unc).astype(str)
        elif isinstance(unc, (list, tuple, np.ndarray)) and all(isinstance(x, str) for x in unc):
            u_strs = np.asarray(unc, dtype=str)
        else:
            u_nums = np.atleast_1d(np.asarray(unc, dtype=float))
            u_strs = u_nums.astype(str)

        # If any supplied uncertainty string entries are empty, replace them
        # with the first uncertainty present on this quantity (if any);
        # otherwise fall back to "0". This mirrors the notebook magic's
        # behavior and makes empty-unc inheritance available everywhere.
        try:
            u_strs = np.asarray(u_strs, dtype=str)
            mask_empty = np.char.strip(u_strs) == ""
            if np.any(mask_empty):
                if self.tunc.size > 0:
                    first_unc = str(self.tunc.ravel()[0])
                else:
                    raise ValueError("Cannot add row(s) with empty uncertainty to an empty MeasuredQuantity; first row(s) must provide uncertainties")
                uncertainty_values = list(u_strs.ravel())
                for index in np.flatnonzero(mask_empty.ravel()):
                    uncertainty_values[int(index)] = first_unc
                u_strs = np.asarray(uncertainty_values, dtype=str).reshape(
                    u_strs.shape
                )
        except Exception:
            # Defensive: if something unexpected about u_strs, fall back to
            # original behavior (will raise earlier if parsing failed).
            pass

        contains_percent = any("%" in str(x) for x in np.asarray(u_strs).ravel())
        if contains_percent and np.asarray(u_strs).size != np.asarray(v_strs).size:
            raise ValueError(
                "Percent uncertainty must be provided separately for every data point."
            )

        # Preserve ordinary uncertainty broadcasting, but never broadcast a
        # percentage specification across multiple measured values.
        if np.asarray(u_strs).shape != np.asarray(v_strs).shape:
            try:
                u_strs = np.broadcast_to(u_strs, v_strs.shape)
            except Exception:
                raise ValueError("`unc` is not broadcastable to `val` for the new row(s)")

        v_flat = np.asarray(v_strs, dtype=str).ravel()
        v_text_flat = np.asarray(v_text_inputs, dtype=bool).ravel()
        original_u_flat = np.asarray(u_strs, dtype=str).ravel()
        converted_uncertainties = []
        for i, uncertainty_text in enumerate(original_u_flat):
            if "%" in str(uncertainty_text) and not v_text_flat[i]:
                raise ValueError(
                    "Percent uncertainty requires each measured value to be "
                    "provided as a string so its display resolution is known."
                )
            converted = self._absolute_uncertainty_from_percent(
                v_flat[i], uncertainty_text
            )
            converted_uncertainties.append(
                str(uncertainty_text) if converted is None else converted
            )

        # Build a fresh string array so longer computed values are not clipped
        # to the fixed-width dtype of the original specification strings.
        u_flat = np.asarray(converted_uncertainties, dtype=str)
        u_strs = u_flat.reshape(np.asarray(v_strs).shape)
        try:
            u_nums = np.atleast_1d(
                np.asarray([float(x) for x in u_flat], dtype=float)
            ).reshape(np.asarray(v_strs).shape)
        except Exception as exc:
            raise ValueError("Could not parse `unc` string(s) to float") from exc

        def _decimal_places(text: str) -> int:
            s = str(text).strip()
            if "e" in s or "E" in s:
                s = s.split("e", 1)[0].split("E", 1)[0]
            s = s.lstrip("+-")
            if "." in s:
                return len(s.split(".", 1)[1])
            return 0

        # Enforce matching decimal places between value and uncertainty.
        # Exception: uncertainty is zero.
        v_flat = np.asarray(v_strs, dtype=str).ravel()
        u_flat = np.asarray(u_strs, dtype=str).ravel()
        v_num_flat = np.atleast_1d(np.asarray(v_nums, dtype=float)).ravel()
        u_num_flat = np.atleast_1d(np.asarray(u_nums, dtype=float)).ravel()
        if v_flat.size != u_flat.size:
            raise ValueError("Value and uncertainty counts do not match")
        for i in range(v_flat.size):
            # An inherited uncertainty keeps its original presentation and
            # is not reformatted to match each later value's decimal places.
            if missing_unc:
                continue
            if float(u_num_flat[i]) == 0.0:
                continue
            v_dec = _decimal_places(v_flat[i])
            u_dec = _decimal_places(u_flat[i])
            if v_dec != u_dec:
                raise ValueError(
                    f"Value/uncertainty decimal places must match (got {v_flat[i]} and {u_flat[i]})"
                )

        # Ensure existing internal arrays are 1-D sequences
        self._ensure_1d()

        # Concatenate numeric arrays using NumPy but build string arrays
        # via Python lists to avoid NumPy fixed-width Unicode truncation
        # issues that can make string representations inconsistent with
        # the numeric copies (e.g. '0.1' -> '0'). Use list concatenation
        # then create fresh NumPy string arrays.
        self.nval = np.concatenate([self.nval.ravel(), v_nums])
        self.nunc = np.concatenate([self.nunc.ravel(), u_nums])

        val_list = list(self.tval.ravel()) + list(np.asarray(v_strs, dtype=str).ravel())
        unc_list = list(self.tunc.ravel()) + list(np.asarray(u_strs, dtype=str).ravel())

        self.tval = np.asarray(val_list, dtype=str)
        self.tunc = np.asarray(unc_list, dtype=str)

        # If the caller omitted `unc` entirely, ensure the appended rows
        # inherit the first existing uncertainty numerically and as strings.
        # For an empty MeasuredQuantity this should have been rejected
        # earlier; defensively raise if no prior uncertainty exists.
        if missing_unc:
            if self.nunc.size > 0:
                first_unc_float = float(self.nunc.ravel()[0])
                first_unc_str = str(self.tunc.ravel()[0])
            else:
                raise ValueError("Cannot add row(s) without `unc` to an empty MeasuredQuantity; first row(s) must provide uncertainties")
            n_new = int(v_nums.size)
            if n_new > 0:
                self.nunc[-n_new:] = first_unc_float
                # Replace via a Python list to avoid any NumPy string-casting
                # surprises when assigning into fixed-width arrays.
                unc_list = list(self.tunc.ravel())
                unc_list[-n_new:] = [first_unc_str] * n_new
                self.tunc = np.asarray(unc_list, dtype=str)

        # Normalize `unc` string array to avoid potential NumPy fixed-width
        # truncation issues: rebuild as a fresh array of Python strings so
        # each element contains the full textual representation.
        try:
            self.tunc = np.asarray([str(x) for x in self.tunc.ravel()], dtype=str)
        except Exception:
            # If something unexpected happens, leave as-is.
            pass

        self.dim = int(self.nval.size)

    def format(self, index: int | None = 0, **kwargs) -> str:
        """Format a specific row (default first) as plain text.

        Delegates to `formatting.format_quantity`. When `dim == 1`,
        `str(measured_quantity)` will return the formatted first row.
        """
        from .formatting import format_quantity, render_table_text

        if self.dim == 0:
            # No rows yet: prefer the regular object repr so printing an
            # uninitialized quantity doesn't produce empty output or
            # surprising errors in notebooks.
            return super().__repr__()

        # If the caller requested a full-table (index is None) or this
        # quantity has multiple rows and no explicit index was provided,
        # render an aligned ASCII table with one row per measurement.
        if index is None or int(self.dim) > 1 and index is None:
            return render_table_text([self], header=False)

        if index is None:
            # defensive: if index is still None for some reason, fall back
            # to first-row formatting
            idx = 0
        else:
            idx = index

        if idx < 0 or idx >= int(self.dim):
            raise IndexError("row index out of range")

        # Prefer presentation strings when available so user-supplied
        # formatting (e.g., '12.00') is preserved.
        if getattr(self, "tval", None) is not None and getattr(self, "tval").size:
            return format_quantity(self, show_name=True, index=idx, **kwargs)

        # Fallback to numeric tuple
        return format_quantity(self, show_name=True, index=idx, **kwargs)

    def __str__(self) -> str:
        if int(self.dim) == 1:
            try:
                return self.format(0)
            except Exception:
                pass
        if int(self.dim) > 1:
            try:
                return self.format(index=None)
            except Exception:
                pass
        return super().__repr__()
