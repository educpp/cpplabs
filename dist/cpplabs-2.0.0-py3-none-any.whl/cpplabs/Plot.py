import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
import re
from typing import Any, Iterable, Optional

from .ConstantQuantity import ConstantQuantity
try:
    from .UnitAlgebra import ureg
except Exception:
    ureg = None


class Plot:
    """Student-friendly plotting helpers around Matplotlib.

        Overview
        - `Plot.data(x, y, ...)` and `Plot.data_and_model(x, y, expr, ...)`
            are static convenience functions that return `(fig, ax)`.
        - Figures are returned to the caller; display them with
            `Plot.show()` or `fig.show()` when you're ready.

        Inputs
        - `x`, `y`: may be `ConstantQuantity` (recommended) or any object
            exposing `nval`/`nunc` (numeric and uncertainty) or a plain array.
        - `expr`: SymPy expression or a callable `f(x)` used by
            `data_and_model` to plot the model curve.

        Labeling rules
        - Axis labels are set only when the plotted object exposes an
            explicit `name` or `label` attribute. If present, the axis label
            becomes: ``<name>, <xvar> [<unit>]`` when `xvar`/`yvar` is
            provided (the unit is formatted using pint when available).
            If no `name` is present, no automatic label is applied; callers
            may pass `xlabel` / `ylabel` explicitly.

        Notebook AST injection
        - When running inside IPython/Jupyter, the package's AST transformer
            may automatically inject `xvar`/`yvar` (for simple literal
            symbol arguments) into calls like ``Plot.data(x, F)`` so labels
            are rendered as: ``Distance, $x$ [cm]``. To opt out, provide
            explicit `xlabel`/`ylabel` or pass `xvar`/`yvar` yourself.

        Show semantics
        - The helpers return `(fig, ax)` and do not display automatically.
        - Use `Plot.show()` or `fig.show()` to display figures when desired.

        Examples
        - Plot data without showing immediately::

                fig, ax = Plot.data(x, F)
                # modify ax (labels, styles) then
                Plot.show()

        - Plot data and a SymPy model expression::

                fig, ax = Plot.data_and_model(x, F, expr)
                Plot.show()
        """

    # Private helper function (module-local) to convert simple variable
    # names into LaTeX math. Kept as a plain function rather than a class
    # for simplicity and easier testing/monkeypatching.
    @staticmethod
    def _latexize(var: Any) -> Any:
        try:
            if isinstance(var, str):
                inner = var
                if inner.startswith('$') and inner.endswith('$'):
                    inner = inner[1:-1]
                var_latex = re.sub(r'_(\w+)', r'_{\1}', inner)
                return f"${var_latex}$"
            return var
        except Exception:
            return var

    @staticmethod
    def _ensure_sq(obj: Any) -> ConstantQuantity:
        if isinstance(obj, ConstantQuantity):
            return obj

        nval = None
        nunc = None
        unit = None
        name = ""
        try:
            nval = getattr(obj, "nval", None)
            nunc = getattr(obj, "nunc", None)
            unit = getattr(obj, "unit", None)
            name = getattr(obj, "name", "")
        except Exception:
            pass

        if nval is None:
            nval = np.asarray(obj, dtype=float)
            nunc = np.zeros_like(nval, dtype=float)

        if nunc is None:
            nunc = np.zeros_like(np.atleast_1d(nval), dtype=float)

        return ConstantQuantity(nval, nunc, str(unit or ""), name)

    @staticmethod
    def _fmt_unit_for_label(unit: Any) -> str:
        # If there is no unit, nothing to format
        if unit is None:
            return ""
        # Only use pint formatting when available; otherwise return empty
        if ureg is None:
            return ""
        # Prefer pint's compact formatting when available
        try:
            u = ureg.Unit(unit) if not hasattr(unit, "units") else unit
            try:
                if u.dimensionality == ureg.dimensionless.dimensionality:
                    return ""
            except Exception:
                pass
            try:
                return '$' + format(u, "~") + '$'
            except Exception:
                return ""
        except Exception:
            return ""

    @staticmethod
    def _axis_label(obj: Any, axis_name: str, var: Optional[str] = None) -> Optional[str]:
        """Return a label string only when the object exposes an explicit name/label.

        Do not attempt to infer variable symbols or fall back to axis names.
        If no name is present, return None.
        """
        name = getattr(obj, "name", None) or getattr(obj, "label", None)
        if not name:
            return None
        unit = getattr(obj, "unit", None)
        unit_str = Plot._fmt_unit_for_label(unit)
        if var:
            var_fmt = Plot._latexize(var)
            if unit_str:
                return f"{name}, {var_fmt} [{unit_str}]"
            return f"{name}, {var_fmt}"
        if unit_str:
            return f"{name} [{unit_str}]"
        return f"{name}"

    @staticmethod
    def data(x: Any, y: Any, ax: Optional[plt.Axes] = None, fmt: str = ".", label: str = "data", show: bool = True, xlabel: Optional[str] = None, ylabel: Optional[str] = None, xvar: Optional[str] = None, yvar: Optional[str] = None, **kwargs):
        """Plot data points with error bars. Returns `(fig, ax)`.
        
        The `show` parameter is accepted for compatibility but is not
        currently used; call `Plot.show()` explicitly to display.
        """
        x_sq = Plot._ensure_sq(x)
        y_sq = Plot._ensure_sq(y)

        if ax is None:
            fig, ax = plt.subplots()
        else:
            fig = ax.figure

        xvals = np.atleast_1d(x_sq.nval)
        yvals = np.atleast_1d(y_sq.nval)
        xerr = None
        yerr = None
        if np.asarray(x_sq.nunc).size != 0:
            xerr = np.atleast_1d(x_sq.nunc)
        if np.asarray(y_sq.nunc).size != 0:
            yerr = np.atleast_1d(y_sq.nunc)

        ax.errorbar(x=xvals, y=yvals, xerr=xerr, yerr=yerr, fmt=fmt, label=label, **kwargs)

        # set automatic axis labels if not provided
        if xlabel is None:
            ax.set_xlabel(Plot._axis_label(x_sq, "x", var=xvar))
        else:
            ax.set_xlabel(xlabel)
        if ylabel is None:
            ax.set_ylabel(Plot._axis_label(y_sq, "y", var=yvar))
        else:
            ax.set_ylabel(ylabel)
        # Do not close the figure here so callers can modify and
        # display it later via `Plot.show(fig)` or `fig.show()`.
        return fig, ax

    @staticmethod
    def data_and_model(x: Any, y: Any, expr: Any, ax: Optional[plt.Axes] = None, model_label: str = "model", samples: int = 200, show: bool = True, xlabel: Optional[str] = None, ylabel: Optional[str] = None, xvar: Optional[str] = None, yvar: Optional[str] = None, **plot_kwargs):
        """Plot data and a model specified by a SymPy expression or callable.

        - `expr` may be a SymPy expression, a callable f(x), or None.
            - The x points used to plot the model are computed from the data
              range and sampled using the `samples` parameter.
        The `show` parameter is accepted for compatibility but is not
        currently used; call `Plot.show()` explicitly to display.
        Returns `(fig, ax)`.
        """
        x_sq = Plot._ensure_sq(x)
        y_sq = Plot._ensure_sq(y)

        if ax is None:
            fig, ax = plt.subplots()
        else:
            fig = ax.figure

        # plot data
        xvals = np.atleast_1d(x_sq.nval)
        yvals = np.atleast_1d(y_sq.nval)
        xerr = None
        yerr = None
        if np.asarray(x_sq.nunc).size != 0:
            xerr = np.atleast_1d(x_sq.nunc)
        if np.asarray(y_sq.nunc).size != 0:
            yerr = np.atleast_1d(y_sq.nunc)
        ax.errorbar(x=xvals, y=yvals, xerr=xerr, yerr=yerr, fmt='.', label='data')

        # set automatic labels if not provided
        if xlabel is None:
            ax.set_xlabel(Plot._axis_label(x_sq, "x", var=xvar))
        else:
            ax.set_xlabel(xlabel)
        if ylabel is None:
            ax.set_ylabel(Plot._axis_label(y_sq, "y", var=yvar))
        else:
            ax.set_ylabel(ylabel)

        if expr is None:
            return fig, ax

        # prepare xs
        xvals_f = np.atleast_1d(x_sq.nval).astype(float)
        xmin = float(np.min(xvals_f))
        xmax = float(np.max(xvals_f))
        margin = 0.05 * (xmax - xmin) if xmax != xmin else 1.0
        xs = np.linspace(xmin - margin, xmax + margin, samples)

        # build callable
        if isinstance(expr, sp.Basic):
            x_sym = sp.symbols("x")
            f = sp.lambdify(x_sym, expr, "numpy")
        elif callable(expr):
            f = expr
        else:
            try:
                x_sym = sp.symbols("x")
                fexpr = sp.sympify(expr)
                f = sp.lambdify(x_sym, fexpr, "numpy")
            except Exception:
                raise ValueError("expr must be a sympy expression or a callable")

        ys = f(xs)
        ax.plot(xs, ys, label=model_label)
        ax.legend()
        # Do not close the figure here so callers can modify and
        # display it later via `Plot.show(fig)` or `fig.show()`.
        return fig, ax

    @staticmethod
    def show():
        """Display Matplotlib figures in the current environment."""
        plt.show()

    @staticmethod
    def compare(*quantities: Any, unit: Optional[str] = None, gap: Optional[float] = None, ax: Optional[plt.Axes] = None, show: bool = True, annotate: bool = True, colors: Optional[Iterable[str]] = None, marker: str = 'o', linewidth: float = 3.0, center_vars: Optional[Iterable[str]] = None, **kwargs):
        """Compare any number of quantities by drawing their intervals on a horizontal number line.

        See Plot.compare doc in repository for details. This helper plots each
        quantity's midpoint and horizontal interval [lo, hi], sorts entries
        by ascending lo, and highlights the common intersection if present.
        """
        entries = []
        # Accept an optional sequence of center labels (one per argument).
        # This is injected by the IPython AST transformer as `center_vars`.
        center_vars_seq = None
        try:
            if center_vars is not None:
                center_vars_seq = list(center_vars)
        except Exception:
            center_vars_seq = None

        for arg_index, q in enumerate(quantities):
            # attempt to evaluate DerivedQuantity-like objects
            if hasattr(q, "evaluate") and callable(getattr(q, "evaluate")):
                try:
                    q.evaluate()
                except Exception:
                    pass

            # ConstantQuantity
            if isinstance(q, ConstantQuantity):
                nvals = np.atleast_1d(q.nval)
                uncs = np.atleast_1d(q.nunc) if getattr(q, "nunc", None) is not None else np.zeros_like(nvals)
                unit_q = getattr(q, "unit", None)
                base_name = getattr(q, "name", "") or getattr(q, "label", "") or "const"
                symbol = getattr(q, "symbol", "") or getattr(q, "sym", "")
                base_label = f"{base_name}, {symbol}" if symbol else base_name
                for i, v in enumerate(nvals):
                    mid = float(v)
                    unc = float(uncs[i]) if i < np.asarray(uncs).size else 0.0
                    entries.append({"lo": mid - unc, "mid": mid, "hi": mid + unc, "label": base_label, "symbol": symbol, "unit": unit_q, "arg_index": arg_index})
                continue

            # MeasuredQuantity or other with nval
            if hasattr(q, "nval"):
                nvals = np.atleast_1d(getattr(q, "nval"))
                try:
                    uncs = np.atleast_1d(getattr(q, "nunc"))
                except Exception:
                    uncs = np.zeros_like(nvals)
                unit_q = getattr(q, "unit", None)
                symbol = getattr(q, "symbol", "") or getattr(q, "sym", "")
                try:
                    tvals = np.atleast_1d(getattr(q, "tval"))
                except Exception:
                    tvals = None
                base_name = getattr(q, "name", "") or getattr(q, "label", "")
                for i, v in enumerate(nvals):
                    mid = float(v)
                    unc = float(uncs[i]) if i < np.asarray(uncs).size else 0.0
                    if tvals is not None and i < np.asarray(tvals).size:
                        label = f"{base_name} {tvals[i]}" if base_name else f"{tvals[i]}"
                    else:
                        label = f"{base_name}[{i}]" if base_name else f"q{len(entries)}"
                    entries.append({"lo": mid - unc, "mid": mid, "hi": mid + unc, "label": label, "symbol": symbol, "unit": unit_q, "arg_index": arg_index})
                continue

            # fallback numeric
            try:
                arr = np.atleast_1d(np.asarray(q, dtype=float))
                for v in arr:
                    mid = float(v)
                    entries.append({"lo": mid, "mid": mid, "hi": mid, "label": str(q), "unit": None, "arg_index": arg_index})
                continue
            except Exception:
                continue

        if not entries:
            raise ValueError("No valid quantities provided to Plot.compare")

        entries.sort(key=lambda e: (e["lo"], e["mid"], e["label"]))
        N = len(entries)
        spacing = float(gap) if gap is not None else 1.0
        y_positions = np.arange(N)[::-1] * spacing


        if colors is None:
            prop_cycle = plt.rcParams.get('axes.prop_cycle')
            palette = prop_cycle.by_key().get('color', ['C0', 'C1', 'C2', 'C3'])
        else:
            palette = list(colors)

        # assign a stable color per argument index (so multiple rows from
        # the same input share the same color) preserving argument order
        unique_args = []
        for e in entries:
            ai = e.get("arg_index")
            if ai not in unique_args:
                unique_args.append(ai)
        arg_to_color = {ai: palette[i % len(palette)] for i, ai in enumerate(unique_args)}

        if ax is None:
            # Figure height: 1 inch per unique variable + 1" top + 1" bottom
            try:
                n_vars = len(unique_args) if unique_args is not None else 1
            except Exception:
                n_vars = 1
            height_in = max(float(n_vars) + 2.0, 2.0)
            fig, ax = plt.subplots(figsize=(8, height_in))
        else:
            fig = ax.figure

        all_los = [e["lo"] for e in entries]
        all_his = [e["hi"] for e in entries]
        xmin = min(all_los)
        xmax = max(all_his)
        xspan = xmax - xmin if xmax != xmin else max(abs(xmin), 1.0)
        xmargin = 0.05 * xspan



        def _fmt_unit_plain(u: Any) -> Optional[str]:
            if u is None:
                return None
            if ureg is not None:
                try:
                    uu = ureg.Unit(u) if not hasattr(u, "units") else u
                    try:
                        if uu.dimensionality == ureg.dimensionless.dimensionality:
                            return None
                    except Exception:
                        pass
                    return format(uu, "~")
                except Exception:
                    return str(u)
            return str(u)

        # collect units per argument
        units_per_arg = {ai: _fmt_unit_plain(next((ee.get("unit") for ee in entries if ee.get("arg_index")==ai), None)) for ai in unique_args}

        # decide whether units differ (needed when annotating center labels)
        unique_unit_values = list({u for u in units_per_arg.values() if u is not None})
        units_differ = False
        if len(unique_unit_values) == 1:
            common_unit_for_axis = unique_unit_values[0]
        else:
            common_unit_for_axis = None
            units_differ = True

        for i, e in enumerate(entries):
            y = y_positions[i]
            lo = e["lo"]
            hi = e["hi"]
            mid = e["mid"]
            # Use caller-provided center labels when available; otherwise
            # retain the quantity name/symbol label prepared above.
            label = e.get("symbol", "") or e.get("label", "")
            if center_vars_seq is not None:
                try:
                    arg_idx = e.get("arg_index", None)
                    if arg_idx is not None and arg_idx < len(center_vars_seq):
                        var_label = center_vars_seq[arg_idx]
                        if var_label:
                            label = Plot._latexize(var_label)
                except Exception:
                    label = ""
            arg_idx = e.get("arg_index", None)
            color = arg_to_color.get(arg_idx, palette[i % len(palette)])
            # Draw a thin horizontal interval line and short vertical caps
            # (notches) at each end. Horizontal linewidth is thin (1.0)
            # regardless of the main `linewidth` parameter used elsewhere.
            try:
                hline_lw = 1.0
                cap_h = 0.12 * spacing
            except Exception:
                hline_lw = 1.0
                cap_h = 0.12
            # horizontal segment
            ax.plot([lo, hi], [y, y], linewidth=hline_lw, color=color, zorder=2)
            # vertical end caps (notches)
            try:
                ax.plot([lo, lo], [y - cap_h / 2.0, y + cap_h / 2.0], linewidth=hline_lw, color=color, zorder=2)
                ax.plot([hi, hi], [y - cap_h / 2.0, y + cap_h / 2.0], linewidth=hline_lw, color=color, zorder=2)
            except Exception:
                pass
            # midpoint marker
            ax.plot(mid, y, marker=marker, color=color, zorder=3)
            if annotate:
                unit_str = ""
                try:
                    u = e.get("unit", None)
                    unit_fmt = Plot._fmt_unit_for_label(u)
                    if unit_fmt:
                        unit_str = f" {unit_fmt}"
                    elif u is not None:
                        unit_str = f" [{u}]"
                except Exception:
                    unit_str = ""
                # place the label centered above the midpoint marker
                # use a small vertical offset so the text sits just above the dot
                try:
                    vert_offset = 0.12 * spacing
                except Exception:
                    vert_offset = 0.12
                # Append a plain unit next to the center label only when
                # units differ. Use the plain-formatted unit from
                # `units_per_arg` to avoid math-mode rendering issues.
                try:
                    if isinstance(label, str) and label:
                        plain_unit = None
                        try:
                            plain_unit = units_per_arg.get(arg_idx)
                        except Exception:
                            plain_unit = None
                        if units_differ and plain_unit:
                            text_str = f"{label} [{plain_unit}]"
                        else:
                            text_str = label
                    else:
                        text_str = str(label)
                except Exception:
                    text_str = str(label)
                ax.text(mid, y + vert_offset, text_str, ha='center', va='bottom', fontsize=9)

        max_lo = max(all_los)
        min_hi = min(all_his)
        if max_lo <= min_hi:
            ax.axvspan(max_lo, min_hi, color='green', alpha=0.15, zorder=1)

        ax.set_ylim(y_positions[-1] - spacing, y_positions[0] + spacing)
        ax.set_yticks([])
        # Add horizontal padding around data in data-coordinate units.
        # Use a modest symmetric edge margin so the plotted data occupies
        # more of the available axis width while still leaving room for
        # annotations and the figure-level border.
        try:
            edge_margin = 0.075 * xspan
        except Exception:
            edge_margin = xmargin
        ax.set_xlim(xmin - edge_margin, xmax + edge_margin)
        # Ensure the bottom axis spine (the horizontal axis line) starts and
        # finishes inside the padded region by setting its visible bounds to
        # the raw data extents (xmin, xmax). This keeps the axis line away
        # from the left/right padding reserved for labels.
        try:
            if "bottom" in ax.spines:
                ax.spines["bottom"].set_bounds(xmin, xmax)
        except Exception:
            pass

        # Ensure tick marks lie strictly within the visible bottom spine
        # (so tickmarks start after the line on the left and finish before
        # the end of the line on the right). Use the axis locator to pick
        # reasonable major ticks and then filter them to the interior.
        try:
            eps = 1e-6 * xspan if xspan != 0 else 1e-6
            locator = ax.xaxis.get_major_locator()
            try:
                ticks = locator.tick_values(xmin, xmax)
            except Exception:
                ticks = list(ax.get_xticks())
            ticks_inner = [t for t in ticks if (t > (xmin + eps)) and (t < (xmax - eps))]
            # If filtering removed all ticks, create a small set inside the span
            if len(ticks_inner) == 0:
                try:
                    ticks_inner = list(np.linspace(xmin + 0.25 * xspan, xmax - 0.25 * xspan, min(2, max(2, len(ticks)))))
                except Exception:
                    ticks_inner = ticks
            ax.set_xticks(ticks_inner)
        except Exception:
            pass

        # Shift the axes inward so there is 1 inch of empty space on all
        # sides of the figure. This uses the figure size in inches to
        # compute fractional margins and then applies `subplots_adjust`.
        try:
            # Keep vertical (top/bottom) 1 inch margins as before, but
            # choose left/right so the plotting area occupies ~85% of
            # the figure width. This keeps heights unchanged.
            fig_w, fig_h = fig.get_size_inches()
            target_plot_frac = 0.85
            horiz_margin_frac = max(0.0, (1.0 - target_plot_frac) / 2.0)
            bottom_frac = 1.0 / fig_h
            top_frac = 1.0 / fig_h
            fig.subplots_adjust(left=horiz_margin_frac, right=1.0 - horiz_margin_frac, bottom=bottom_frac, top=1.0 - top_frac)
        except Exception:
            pass

        # Remove the axes border (spines and axes patch) so only the
        # figure-level border remains visible. Keep ticks/labels but hide
        # the rectangular box around the plotting area.
        try:
            # Hide the top/left/right spines but keep the bottom spine
            # visible so the x-axis line remains. Configure its appearance
            # and ensure it renders above plotted markers.
            for name, sp in ax.spines.items():
                if name == 'bottom':
                    sp.set_visible(True)
                    try:
                        sp.set_linewidth(1.0)
                    except Exception:
                        pass
                    try:
                        sp.set_zorder(4)
                    except Exception:
                        pass
                else:
                    sp.set_visible(False)
            ax.patch.set_visible(False)
        except Exception:
            pass

        # Draw a figure border on top of all artists so the border is visible
        # above axes/spines. Use a non-filled Rectangle in figure coordinates.
        try:
            import matplotlib.patches as mpatches

            border = mpatches.Rectangle((0.0, 0.0), 1.0, 1.0, transform=fig.transFigure,
                                        fill=False, linewidth=1.0, edgecolor='black', zorder=1000)
            fig.patches.append(border)
        except Exception:
            pass
        # If all arguments share the same unit, use it as the x-axis label.
        if common_unit_for_axis is not None:
            ax.set_xlabel(f"[{common_unit_for_axis}]")
        else:
            ax.set_xlabel('')

        # Do not close the figure here so callers can modify and
        # display it later via `Plot.show(fig)` or `fig.show()`.
        return fig, ax

