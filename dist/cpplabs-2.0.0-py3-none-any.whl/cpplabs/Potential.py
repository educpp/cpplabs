import math
import warnings
from dataclasses import dataclass
from typing import List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np

from ._field_streamplot import integrate_field_lines


@dataclass
class _Shape:
    kind: str
    potential: float = 0.0
    center: Optional[Tuple[float, float]] = None
    radius: Optional[float] = None
    vertices: Optional[List[Tuple[float, float]]] = None
    width: Optional[float] = None
    height: Optional[float] = None
    label: str = ""
    epsilon_r: Optional[float] = None

    @property
    def is_conductor(self):
        """A shape without a dielectric constant is a conductor."""
        return self.epsilon_r is None

    def as_patch(self):
        if self.kind == "circle":
            from matplotlib.patches import Circle
            return Circle(self.center, self.radius, fill=False, linewidth=2)
        if self.kind == "rectangle":
            from matplotlib.patches import Rectangle
            x0 = self.center[0] - self.width / 2.0
            y0 = self.center[1] - self.height / 2.0
            return Rectangle((x0, y0), self.width, self.height, fill=False, linewidth=2)
        if self.kind == "polygon":
            from matplotlib.patches import Polygon
            return Polygon(self.vertices, closed=True, fill=False, linewidth=2)
        raise ValueError(f"Unsupported shape kind: {self.kind}")


@dataclass
class FieldLine:
    """One ordered field-line path and its classified endpoints."""

    path: np.ndarray
    start_type: str
    end_type: str
    start_potential: Optional[float] = None
    end_potential: Optional[float] = None
    accepted: bool = True


class Potential:
    """Simple 2D electrostatic potential solver for student lab use.

    The class accepts basic conductor shapes, shows a geometry preview, and then
    solves Laplace's equation on a rectangular domain using a red–black SOR
    iteration.

    Boundary modes
    --------------
    ``"neumann"``
        Insulating physical edges: dV/dn = 0.
    ``"dirichlet0"``
        Grounded physical edges: V = 0.
    ``"open"``
        Adds a geometrically stretched grid outside the physical rectangle and
        fixes the distant computational edge to ``far_value``.  This is a
        finite-domain approximation to an open electrostatic boundary, not a
        perfectly matched layer.  It is appropriate only when the 2D potential
        actually approaches a finite far-field value.
    """

    def __init__(
        self,
        width=27.94,
        height=21.59,
        dx=0.10,
        boundary_mode="neumann",
        overlap_policy="reject",
        medium_epsilon_r=1.0,
        open_layers=30,
        open_growth=1.18,
        far_value=0.0,
    ):
        self.width = float(width)
        self.height = float(height)
        self.dx = float(dx)
        if not np.isfinite(self.width) or self.width <= 0.0:
            raise ValueError("width must be a positive, finite number.")
        if not np.isfinite(self.height) or self.height <= 0.0:
            raise ValueError("height must be a positive, finite number.")
        if not np.isfinite(self.dx) or self.dx <= 0.0:
            raise ValueError("dx must be a positive, finite number.")
        if self.width < self.dx or self.height < self.dx:
            raise ValueError("width and height must each be at least dx.")

        self.boundary_mode = boundary_mode
        if self.boundary_mode not in ("neumann", "dirichlet0", "open"):
            raise ValueError(
                "boundary_mode must be 'neumann', 'dirichlet0', or 'open'."
            )

        if isinstance(open_layers, bool) or int(open_layers) != open_layers:
            raise ValueError("open_layers must be a positive integer.")
        self.open_layers = int(open_layers)
        if self.open_layers < 1:
            raise ValueError("open_layers must be a positive integer.")

        self.open_growth = float(open_growth)
        if not np.isfinite(self.open_growth) or self.open_growth <= 1.0:
            raise ValueError("open_growth must be finite and greater than 1.")

        self.far_value = float(far_value)
        if not np.isfinite(self.far_value):
            raise ValueError("far_value must be finite.")

        self.overlap_policy = overlap_policy
        self.medium_epsilon_r = self._validate_epsilon(medium_epsilon_r, "medium_epsilon_r")
        self.shapes: List[_Shape] = []
        self._solution = None
        self._x = None
        self._y = None
        self._X = None
        self._Y = None
        self.iterations = None
        self.converged = None
        self.max_update = None

    @staticmethod
    def _validate_epsilon(value, name):
        value = float(value)
        if not np.isfinite(value) or value <= 0.0:
            raise ValueError(f"{name} must be a positive, finite number.")
        return value

    def _has_variable_dielectric(self):
        for shape in self.shapes:
            if shape.is_conductor:
                continue
            if not np.isclose(shape.epsilon_r, self.medium_epsilon_r):
                return True
        return False

    @staticmethod
    def _add_stretched_ends(axis, layers, growth):
        """Extend a uniform axis with geometrically growing exterior cells."""
        left_step = axis[1] - axis[0]
        right_step = axis[-1] - axis[-2]
        powers = growth ** np.arange(layers, dtype=np.float64)
        if not np.all(np.isfinite(powers)):
            raise ValueError(
                "open_layers and open_growth produce an excessively large grid."
            )

        left = axis[0] - np.cumsum(left_step * powers)
        right = axis[-1] + np.cumsum(right_step * powers)
        return np.concatenate((left[::-1], axis, right))

    def _make_grid(self):
        nx = int(self.width / self.dx) + 1
        ny = int(self.height / self.dx) + 1
        x = np.linspace(0.0, self.width, nx)
        y = np.linspace(0.0, self.height, ny)

        if self.boundary_mode == "open":
            x = self._add_stretched_ends(
                x, self.open_layers, self.open_growth
            )
            y = self._add_stretched_ends(
                y, self.open_layers, self.open_growth
            )

        X, Y = np.meshgrid(x, y)
        return x, y, X, Y

    def _point_in_polygon(self, x, y, polygon):
        inside = False
        n = len(polygon)
        for i in range(n):
            x1, y1 = polygon[i]
            x2, y2 = polygon[(i + 1) % n]
            if ((y1 > y) != (y2 > y)):
                xinters = (x2 - x1) * (y - y1) / (y2 - y1) + x1
                if x < xinters:
                    inside = not inside
        return inside

    def _shape_mask(self, shape, X, Y):
        if shape.kind == "circle":
            cx, cy = shape.center
            r2 = shape.radius ** 2
            return (X - cx) ** 2 + (Y - cy) ** 2 <= r2

        if shape.kind == "rectangle":
            x0 = shape.center[0] - shape.width / 2.0
            y0 = shape.center[1] - shape.height / 2.0
            x1 = x0 + shape.width
            y1 = y0 + shape.height
            return (X >= x0) & (X <= x1) & (Y >= y0) & (Y <= y1)

        if shape.kind == "polygon":
            mask = np.zeros_like(X, dtype=bool)
            for i in range(X.shape[0]):
                for j in range(X.shape[1]):
                    mask[i, j] = self._point_in_polygon(X[i, j], Y[i, j], shape.vertices)
            return mask

        raise ValueError(f"Unsupported shape kind: {shape.kind}")

    def _conductor_mask(self, X, Y):
        """Return the grid mask occupied by conductor shapes."""
        mask = np.zeros_like(X, dtype=bool)
        for shape in self.shapes:
            if shape.is_conductor:
                mask |= self._shape_mask(shape, X, Y)
        return mask

    @staticmethod
    def _strict_interior_mask(mask):
        """Return conductor cells with a conductor neighbor in all directions."""
        if mask.shape[0] < 3 or mask.shape[1] < 3:
            return np.zeros_like(mask, dtype=bool)
        interior = mask[1:-1, 1:-1].copy()
        for row_offset in (-1, 0, 1):
            for col_offset in (-1, 0, 1):
                if row_offset == 0 and col_offset == 0:
                    continue
                interior &= mask[
                    1 + row_offset:mask.shape[0] - 1 + row_offset,
                    1 + col_offset:mask.shape[1] - 1 + col_offset,
                ]
        result = np.zeros_like(mask, dtype=bool)
        result[1:-1, 1:-1] = interior
        return result

    def _conductor_boundary_points(
        self,
        step=None,
        seeding_density=None,
        shape_indices=None,
    ):
        """Return perimeter points used as field-line launch locations.

        ``seeding_density`` is indexed by shape insertion order.  Values are
        seeds/cm for polygons and rectangles, and seeds/radian for circles.
        When provided, ``shape_indices`` limits seeds to those shape indices.
        """
        if step is None:
            step = 0.5

        if seeding_density is not None:
            if not isinstance(seeding_density, (list, tuple)):
                raise TypeError(
                    "seeding_density must be a list or tuple indexed by shape."
                )
            if len(seeding_density) != len(self.shapes):
                raise ValueError(
                    "seeding_density must contain one value for each shape "
                    f"(expected {len(self.shapes)}, got {len(seeding_density)})."
                )

        if shape_indices is not None:
            shape_indices = set(shape_indices)

        points = []
        conductors = [
            (index, shape)
            for index, shape in enumerate(self.shapes)
            if shape.is_conductor
        ]
        conductor_potentials = [shape.potential for _, shape in conductors]
        if not conductor_potentials:
            return np.empty((0, 2), dtype=float)
        lowest_potential = min(conductor_potentials)

        for shape_index, shape in sorted(
            conductors, key=lambda item: item[1].potential, reverse=True
        ):
            if np.isclose(shape.potential, lowest_potential):
                continue
            if shape_indices is not None and shape_index not in shape_indices:
                continue

            shape_density = (
                None if seeding_density is None else seeding_density[shape_index]
            )
            if shape_density is not None:
                shape_density = float(shape_density)
                if not np.isfinite(shape_density) or shape_density < 0.0:
                    raise ValueError(
                        "Each seeding_density value must be a nonnegative, "
                        "finite number or None."
                    )
                if shape_density == 0.0:
                    continue

            if shape.kind == "circle":
                # Keep the previous 40-seed default when no density is given.
                density_per_radian = (
                    20.0 / np.pi if shape_density is None else shape_density
                )
                count = max(1, int(np.ceil(2.0 * np.pi * density_per_radian)))
                theta = 2.0 * np.pi * (np.arange(count, dtype=float) + 0.5) / count
                points.extend(
                    np.column_stack(
                        (
                            shape.center[0] + shape.radius * np.cos(theta),
                            shape.center[1] + shape.radius * np.sin(theta),
                        )
                    ).tolist()
                )
                continue

            if shape.kind == "rectangle":
                x0 = shape.center[0] - shape.width / 2.0
                y0 = shape.center[1] - shape.height / 2.0
                vertices = [
                    (x0, shape.center[1] - shape.height / 2.0),
                    (x0 + shape.width, shape.center[1] - shape.height / 2.0),
                    (x0 + shape.width, shape.center[1] + shape.height / 2.0),
                    (x0, shape.center[1] + shape.height / 2.0),
                ]
            elif shape.kind == "polygon":
                vertices = shape.vertices
            else:
                continue

            # Keep the previous two-seeds-per-cm default when no density is given.
            density_per_cm = 2.0 if shape_density is None else shape_density
            for start, end in zip(vertices, vertices[1:] + vertices[:1]):
                length = math.hypot(end[0] - start[0], end[1] - start[1])
                count = max(1, int(np.ceil(density_per_cm * length)))
                fractions = (np.arange(count, dtype=float) + 0.5) / count
                points.extend(
                    [
                        (
                            start[0] + fraction * (end[0] - start[0]),
                            start[1] + fraction * (end[1] - start[1]),
                        )
                        for fraction in fractions
                    ]
                )

        if not points:
            return np.empty((0, 2), dtype=float)
        return np.unique(np.asarray(points, dtype=float), axis=0)

    @staticmethod
    def _shape_perimeter_length(shape):
        """Return the total perimeter length of a shape, in cm."""
        if shape.kind == "circle":
            return 2.0 * math.pi * shape.radius
        if shape.kind == "rectangle":
            return 2.0 * (shape.width + shape.height)
        if shape.kind == "polygon":
            vertices = shape.vertices
            return sum(
                math.hypot(b[0] - a[0], b[1] - a[1])
                for a, b in zip(vertices, vertices[1:] + vertices[:1])
            )
        raise ValueError(f"Unsupported shape kind: {shape.kind}")

    @staticmethod
    def _shape_perimeter_vertices(shape):
        if shape.kind == "rectangle":
            x0 = shape.center[0] - shape.width / 2.0
            y0 = shape.center[1] - shape.height / 2.0
            return [
                (x0, y0),
                (x0 + shape.width, y0),
                (x0 + shape.width, y0 + shape.height),
                (x0, y0 + shape.height),
            ]
        if shape.kind == "polygon":
            return list(shape.vertices)
        raise ValueError(f"Shape kind {shape.kind} has no vertex list.")

    def _point_at_arc_length(self, shape, s):
        """Return the perimeter point at arc length ``s`` from a fixed origin."""
        perimeter = self._shape_perimeter_length(shape)
        s = s % perimeter
        if shape.kind == "circle":
            theta = s / shape.radius
            return (
                shape.center[0] + shape.radius * math.cos(theta),
                shape.center[1] + shape.radius * math.sin(theta),
            )
        vertices = self._shape_perimeter_vertices(shape)
        remaining = s
        for start, end in zip(vertices, vertices[1:] + vertices[:1]):
            length = math.hypot(end[0] - start[0], end[1] - start[1])
            if length == 0.0:
                continue
            if remaining <= length:
                fraction = remaining / length
                return (
                    start[0] + fraction * (end[0] - start[0]),
                    start[1] + fraction * (end[1] - start[1]),
                )
            remaining -= length
        return vertices[0]

    def _arc_length_of_point(self, shape, point, tolerance):
        """Return a point's arc-length position on shape's perimeter, or None if too far."""
        x, y = float(point[0]), float(point[1])
        if shape.kind == "circle":
            cx, cy = shape.center
            if abs(math.hypot(x - cx, y - cy) - shape.radius) > tolerance:
                return None
            theta = math.atan2(y - cy, x - cx) % (2.0 * math.pi)
            return theta * shape.radius

        vertices = self._shape_perimeter_vertices(shape)
        cumulative = 0.0
        best = None
        for start, end in zip(vertices, vertices[1:] + vertices[:1]):
            edge_dx, edge_dy = end[0] - start[0], end[1] - start[1]
            length = math.hypot(edge_dx, edge_dy)
            if length > 0.0:
                t = max(0.0, min(1.0, ((x - start[0]) * edge_dx + (y - start[1]) * edge_dy) / (length * length)))
                nearest = (start[0] + t * edge_dx, start[1] + t * edge_dy)
                distance = math.hypot(x - nearest[0], y - nearest[1])
                if distance <= tolerance and (best is None or distance < best[0]):
                    best = (distance, cumulative + t * length)
            cumulative += length
        return None if best is None else best[1]

    def _point_in_conductor(self, x, y):
        tolerance = max(self.dx * 1e-6, 1e-9)
        for shape in self.shapes:
            if not shape.is_conductor:
                continue
            if self._point_in_shape(x, y, shape):
                return True
            if shape.kind == "circle":
                cx, cy = shape.center
                if abs(math.hypot(x - cx, y - cy) - shape.radius) <= tolerance:
                    return True
                continue
            if shape.kind == "rectangle":
                x0 = shape.center[0] - shape.width / 2.0
                x1 = x0 + shape.width
                y0 = shape.center[1] - shape.height / 2.0
                y1 = y0 + shape.height
                if (
                    x0 - tolerance <= x <= x1 + tolerance
                    and y0 - tolerance <= y <= y1 + tolerance
                    and (
                        abs(x - x0) <= tolerance
                        or abs(x - x1) <= tolerance
                        or abs(y - y0) <= tolerance
                        or abs(y - y1) <= tolerance
                    )
                ):
                    return True
            elif shape.kind == "polygon":
                vertices = shape.vertices
                for start, end in zip(vertices, vertices[1:] + vertices[:1]):
                    dx = end[0] - start[0]
                    dy = end[1] - start[1]
                    length_sq = dx * dx + dy * dy
                    if length_sq == 0.0:
                        continue
                    t = max(0.0, min(1.0, ((x - start[0]) * dx + (y - start[1]) * dy) / length_sq))
                    if math.hypot(x - (start[0] + t * dx), y - (start[1] + t * dy)) <= tolerance:
                        return True
        return False

    def _refine_conductor_crossing(self, outside, inside):
        """Bisect an outside-to-inside segment onto a conductor boundary."""
        outside = np.asarray(outside, dtype=float)
        inside = np.asarray(inside, dtype=float)
        for _ in range(32):
            midpoint = 0.5 * (outside + inside)
            if self._point_in_conductor(midpoint[0], midpoint[1]):
                inside = midpoint
            else:
                outside = midpoint
        return 0.5 * (outside + inside)

    def _trace_field_direction(
        self,
        start,
        direction,
        step,
        x_limits,
        y_limits,
        max_steps,
    ):
        """Trace one field direction and report whether it hits a conductor."""
        path = [np.asarray(start, dtype=float)]
        point = path[0].copy()
        previous = point.copy()
        for _ in range(max_steps):
            if not (
                x_limits[0] <= point[0] <= x_limits[1]
                and y_limits[0] <= point[1] <= y_limits[1]
            ):
                return path, False

            Ex = self.get_Ex(point[0], point[1])
            Ey = self.get_Ey(point[0], point[1])
            field = direction * np.asarray((Ex, Ey), dtype=float)
            norm = float(np.hypot(field[0], field[1]))
            if not np.isfinite(norm) or norm <= 1e-12:
                return path, False

            previous = point.copy()
            point = point + step * field / norm
            if self._point_in_conductor(point[0], point[1]):
                path.append(self._refine_conductor_crossing(previous, point))
                return path, True
            path.append(point.copy())

        return path, False

    def _boundary_to_boundary_field_lines(self, x_limits, y_limits):
        """Return field-line paths whose endpoints are both conductors."""
        step = max(self.dx * 0.5, 0.05)
        seeds = self._conductor_boundary_points(step=step)
        max_steps = max(100, int(4.0 * max(self.width, self.height) / step))
        lines = []

        for seed in seeds:
            Ex = self.get_Ex(seed[0], seed[1])
            Ey = self.get_Ey(seed[0], seed[1])
            if not np.isfinite(Ex) or not np.isfinite(Ey):
                continue
            if np.hypot(Ex, Ey) <= 1e-12:
                continue

            forward, forward_hit = self._trace_field_direction(
                seed, 1.0, step, x_limits, y_limits, max_steps
            )
            backward, backward_hit = self._trace_field_direction(
                seed, -1.0, step, x_limits, y_limits, max_steps
            )
            if not (forward_hit and backward_hit):
                continue

            path = np.vstack((backward[::-1], forward[1:]))
            if len(path) >= 2:
                lines.append(path)

        return lines

    def _endpoint_type(self, point, domain):
        x, y = float(point[0]), float(point[1])
        if self._point_in_conductor(x, y):
            return "conductor"
        # The integrator can land exactly on the domain edge (e.g. a path
        # running along an axis of symmetry), so shrink the "inside" test by
        # a tiny margin instead of requiring a strictly-outside coordinate.
        margin = 1e-9 * max(domain[0][1] - domain[0][0], domain[1][1] - domain[1][0], 1.0)
        if not (
            domain[0][0] + margin <= x <= domain[0][1] - margin
            and domain[1][0] + margin <= y <= domain[1][1] - margin
        ):
            return "domain_boundary"
        return "invalid"

    def _field_line_step(self, point, direction, ds):
        """Take one RK2 midpoint step through the interpolated field."""
        point = np.asarray(point, dtype=float)

        def unit_field(at):
            field = np.asarray((self.get_Ex(at[0], at[1]), self.get_Ey(at[0], at[1])))
            norm = float(np.hypot(field[0], field[1]))
            if not np.isfinite(norm) or norm <= 1e-12:
                return None
            return direction * field / norm

        first = unit_field(point)
        if first is None:
            return None
        midpoint = point + 0.5 * ds * first
        second = unit_field(midpoint)
        if second is None:
            return None
        return point + ds * second

    def _trace_field_line(self, seed, direction, ds, domain, max_steps):
        path = [np.asarray(seed, dtype=float)]
        point = path[0]
        end_type = "invalid"
        for _ in range(max_steps):
            try:
                next_point = self._field_line_step(point, direction, ds)
            except ValueError:
                break
            if next_point is None:
                break

            endpoint = self._endpoint_type(next_point, domain)
            if endpoint == "conductor":
                boundary = self._refine_conductor_crossing(point, next_point)
                path.append(boundary)
                end_type = "conductor"
                break
            if endpoint == "domain_boundary":
                path.append(next_point)
                end_type = "domain_boundary"
                break

            path.append(next_point)
            point = next_point

        return np.asarray(path), end_type

    def field_lines(
        self,
        ds=None,
        seed_step=None,
        max_steps=None,
        density=3.0,
        integration_direction="both",
        seeding_density=None,
    ):
        """Return ordered field-line paths with classified endpoints.

        This is the inspectable field-line backend used by ``show(mode='field')``.
        Endpoint types are ``"conductor"`` or ``"domain_boundary"``; paths
        that stall inside the domain are omitted. ``seeding_density`` is a list
        indexed by shape insertion order; it is in seeds/cm for polygons and
        rectangles, and seeds/radian for circles.
        """
        if self._solution is None:
            raise RuntimeError("Call solve() before calculating field lines.")
        if integration_direction not in ("forward", "backward", "both"):
            raise ValueError("integration_direction must be 'forward', 'backward', or 'both'.")

        ds = max(self.dx * 0.5, 0.05) if ds is None else float(ds)
        seed_step = max(self.dx * 0.25, 0.025) if seed_step is None else float(seed_step)
        density = float(density)
        if not np.isfinite(ds) or ds <= 0.0 or not np.isfinite(seed_step) or seed_step <= 0.0:
            raise ValueError("ds and seed_step must be positive, finite numbers.")
        if not np.isfinite(density) or density <= 0.0:
            raise ValueError("density must be a positive, finite number.")
        max_steps = max(100, int(4.0 * max(self.width, self.height) / ds)) if max_steps is None else int(max_steps)
        if max_steps < 1:
            raise ValueError("max_steps must be positive.")

        x_mask = (self._x >= 0.0) & (self._x <= self.width)
        y_mask = (self._y >= 0.0) & (self._y <= self.height)
        field_x = self._x[x_mask]
        field_y = self._y[y_mask]
        ex_full, ey_full = self.electric_field()
        ex = ex_full[np.ix_(y_mask, x_mask)]
        ey = ey_full[np.ix_(y_mask, x_mask)]
        domain = ((field_x[0], field_x[-1]), (field_y[0], field_y[-1]))
        conductors = [
            (index, shape)
            for index, shape in enumerate(self.shapes)
            if shape.is_conductor
        ]
        conductor_potentials = [shape.potential for _, shape in conductors]
        if not conductor_potentials:
            return []

        lowest_potential = min(conductor_potentials)
        highest_potential = max(conductor_potentials)
        highest_indices = {
            index
            for index, shape in conductors
            if np.isclose(shape.potential, highest_potential)
        }
        intermediate_indices = {
            index
            for index, shape in conductors
            if (
                not np.isclose(shape.potential, lowest_potential)
                and not np.isclose(shape.potential, highest_potential)
            )
        }

        # Highest-potential conductors emit field lines along the electric field.
        seed_groups = [(highest_indices, "forward")]
        if intermediate_indices and integration_direction in ("forward", "both"):
            seed_groups.append((intermediate_indices, "forward"))

        paths = []
        for shape_indices, direction in seed_groups:
            seeds = self._conductor_boundary_points(
                step=seed_step,
                seeding_density=seeding_density,
                shape_indices=shape_indices,
            )
            seeds = seeds[
                (seeds[:, 0] >= domain[0][0])
                & (seeds[:, 0] <= domain[0][1])
                & (seeds[:, 1] >= domain[1][0])
                & (seeds[:, 1] <= domain[1][1])
            ]
            if len(seeds) == 0:
                continue
            paths.extend(integrate_field_lines(
                field_x,
                field_y,
                ex,
                ey,
                seeds,
                terminate=None,
                density=density,
                minlength=max(ds, 0.1),
                maxlength=max_steps * ds,
                integration_direction=direction,
                broken_streamlines=False,
                reject_short=False,
            ))

        # The lowest-potential conductor(s) are never seeded above. If the
        # endpoints that land on one leave a gap much bigger than the typical
        # spacing between them, seed one line at that gap's midpoint and
        # trace it backward, wherever it ends up.
        lowest_indices = {
            index
            for index, shape in conductors
            if np.isclose(shape.potential, lowest_potential)
        }
        if (
            lowest_indices
            and not np.isclose(lowest_potential, highest_potential)
            and integration_direction in ("backward", "both")
        ):
            tolerance = max(2.0 * self.dx, 1e-6)
            for lowest_index in lowest_indices:
                shape = self.shapes[lowest_index]
                covered_s = []
                for existing_path, _existing_seed in paths:
                    if len(existing_path) < 2:
                        continue
                    for point in (existing_path[0], existing_path[-1]):
                        s = self._arc_length_of_point(shape, point, tolerance)
                        if s is not None:
                            covered_s.append(s)
                if len(covered_s) < 2:
                    continue

                covered_s = sorted(set(covered_s))
                perimeter = self._shape_perimeter_length(shape)
                gaps = [
                    covered_s[i + 1] - covered_s[i]
                    if i + 1 < len(covered_s)
                    else covered_s[0] + perimeter - covered_s[i]
                    for i in range(len(covered_s))
                ]
                typical_gap = float(np.median(gaps))
                if typical_gap <= 0.0:
                    continue

                gap_seeds = []
                for i, gap_size in enumerate(gaps):
                    if gap_size <= 3.0 * typical_gap:
                        continue
                    # Fill the gap with seeds spaced at roughly the typical
                    # interval, symmetric about its midpoint (odd count keeps
                    # the midpoint itself as one of the seeds).
                    count = max(1, round(gap_size / typical_gap))
                    if count % 2 == 0:
                        count += 1
                    spacing = gap_size / (count + 1)
                    gap_seeds.extend(
                        self._point_at_arc_length(shape, covered_s[i] + spacing * (k + 1))
                        for k in range(count)
                    )
                if not gap_seeds:
                    continue

                gap_seeds = np.asarray(gap_seeds, dtype=float)
                gap_seeds = gap_seeds[
                    (gap_seeds[:, 0] >= domain[0][0])
                    & (gap_seeds[:, 0] <= domain[0][1])
                    & (gap_seeds[:, 1] >= domain[1][0])
                    & (gap_seeds[:, 1] <= domain[1][1])
                ]
                if len(gap_seeds) == 0:
                    continue

                for path, seed in integrate_field_lines(
                    field_x,
                    field_y,
                    ex,
                    ey,
                    gap_seeds,
                    terminate=None,
                    density=density,
                    minlength=max(ds, 0.1),
                    maxlength=max_steps * ds,
                    integration_direction="backward",
                    broken_streamlines=False,
                    reject_short=False,
                ):
                    if len(path) < 2:
                        continue
                    paths.append((path, seed))

        records = []
        for path, seed in paths:
            if len(path) < 2:
                continue
            start_type = self._endpoint_type(path[0], domain)
            end_type = self._endpoint_type(path[-1], domain)
            if start_type == "invalid" or end_type == "invalid":
                continue
            records.append(FieldLine(path, start_type, end_type))
        return records

    def _check_overlaps(self):
        if self.overlap_policy == "allow":
            return

        conductor_shapes = [s for s in self.shapes if s.is_conductor]
        for i in range(len(conductor_shapes)):
            for j in range(i + 1, len(conductor_shapes)):
                a = conductor_shapes[i]
                b = conductor_shapes[j]
                if self._shapes_overlap(a, b):
                    if abs(a.potential - b.potential) > 1e-12:
                        raise ValueError(
                            "Conductor overlap with different potentials is not supported. "
                            "Either merge the shapes or set overlap_policy='allow'."
                        )

    def _shapes_overlap(self, a, b):
        if a.kind == "circle" and b.kind == "circle":
            cx1, cy1 = a.center
            cx2, cy2 = b.center
            dist = math.hypot(cx1 - cx2, cy1 - cy2)
            return dist <= (a.radius + b.radius)

        if a.kind == "rectangle" and b.kind == "rectangle":
            ax0 = a.center[0] - a.width / 2.0
            ay0 = a.center[1] - a.height / 2.0
            ax1 = ax0 + a.width
            ay1 = ay0 + a.height
            bx0 = b.center[0] - b.width / 2.0
            by0 = b.center[1] - b.height / 2.0
            bx1 = bx0 + b.width
            by1 = by0 + b.height
            return not (ax1 < bx0 or bx1 < ax0 or ay1 < by0 or by1 < ay0)

        if a.kind == "polygon" and b.kind == "polygon":
            # Simple conservative overlap check using a bounding box + vertex test
            xs = [v[0] for v in a.vertices] + [v[0] for v in b.vertices]
            ys = [v[1] for v in a.vertices] + [v[1] for v in b.vertices]
            min_x, max_x = min(xs), max(xs)
            min_y, max_y = min(ys), max(ys)
            for x in np.linspace(min_x, max_x, 25):
                for y in np.linspace(min_y, max_y, 25):
                    if self._point_in_polygon(x, y, a.vertices) and self._point_in_polygon(x, y, b.vertices):
                        return True
            return False

        # Mixed-shape cases: approximate via sampled points on each shape boundary
        a_points = self._sample_shape_points(a)
        b_points = self._sample_shape_points(b)
        for p in a_points:
            if self._point_in_shape(p[0], p[1], b):
                return True
        for p in b_points:
            if self._point_in_shape(p[0], p[1], a):
                return True
        return False

    def _sample_shape_points(self, shape):
        if shape.kind == "circle":
            n = 48
            th = np.linspace(0.0, 2.0 * np.pi, n, endpoint=False)
            pts = []
            for t in th:
                pts.append((shape.center[0] + shape.radius * np.cos(t), shape.center[1] + shape.radius * np.sin(t)))
            return pts

        if shape.kind == "rectangle":
            x0 = shape.center[0] - shape.width / 2.0
            y0 = shape.center[1] - shape.height / 2.0
            return [
                (x0, y0), (x0 + shape.width, y0),
                (x0, y0 + shape.height), (x0 + shape.width, y0 + shape.height)
            ]

        if shape.kind == "polygon":
            return list(shape.vertices)

        return []

    def _point_in_shape(self, x, y, shape):
        if shape.kind == "circle":
            cx, cy = shape.center
            return (x - cx) ** 2 + (y - cy) ** 2 <= shape.radius ** 2
        if shape.kind == "rectangle":
            x0 = shape.center[0] - shape.width / 2.0
            y0 = shape.center[1] - shape.height / 2.0
            return (x >= x0) and (x <= x0 + shape.width) and (y >= y0) and (y <= y0 + shape.height)
        if shape.kind == "polygon":
            return self._point_in_polygon(x, y, shape.vertices)
        return False

    @staticmethod
    def _validate_shape_role(potential, epsilon_r, material):
        """Validate and infer whether a shape is a conductor or dielectric."""
        if material not in (None, "conductor"):
            raise ValueError(
                "material is no longer used to declare dielectric shapes. "
                "Omit material and provide epsilon_r instead."
            )
        potential = float(potential)
        if not np.isfinite(potential):
            raise ValueError("potential must be finite.")
        if epsilon_r is not None and (
            material == "conductor" or not np.isclose(potential, 0.0)
        ):
            raise ValueError(
                "A shape cannot be both a conductor and a dielectric. "
                "For a dielectric shape, omit material and potential and "
                "provide only epsilon_r."
            )
        return potential

    def add_circle(
        self,
        center,
        radius,
        potential=0.0,
        material=None,
        label="",
        epsilon_r=None,
    ):
        if epsilon_r is not None:
            epsilon_r = self._validate_epsilon(epsilon_r, "epsilon_r")
        potential = self._validate_shape_role(potential, epsilon_r, material)
        self.shapes.append(_Shape(
            "circle",
            potential=potential,
            center=tuple(center),
            radius=float(radius),
            label=label,
            epsilon_r=epsilon_r,
        ))
        return self

    def add_polygon(
        self,
        vertices,
        potential=0.0,
        material=None,
        label="",
        epsilon_r=None,
    ):
        verts = [tuple(v) for v in vertices]
        if len(verts) < 3:
            raise ValueError("A polygon must have at least three vertices.")
        if epsilon_r is not None:
            epsilon_r = self._validate_epsilon(epsilon_r, "epsilon_r")
        potential = self._validate_shape_role(potential, epsilon_r, material)
        self.shapes.append(_Shape(
            "polygon",
            potential=potential,
            vertices=verts,
            label=label,
            epsilon_r=epsilon_r,
        ))
        return self

    def _get_field_components(self):
        if self._solution is None:
            raise RuntimeError("Call solve() before calculating the electric field.")

        dV_dy, dV_dx = np.gradient(self._solution, self._y, self._x)
        Ex = -dV_dx
        Ey = -dV_dy
        return Ex, Ey

    def get_potential(self, x, y):
        """Return the solved potential at a point (x, y) in the domain."""
        if self._solution is None:
            raise RuntimeError("Call solve() before asking for the potential.")
        if self._x is None or self._y is None:
            raise RuntimeError("The solution grid is not available.")

        x = float(x)
        y = float(y)
        if x < self._x[0] or x > self._x[-1] or y < self._y[0] or y > self._y[-1]:
            raise ValueError("Query point is outside the solved domain.")

        ix = np.searchsorted(self._x, x)
        iy = np.searchsorted(self._y, y)
        ix = min(max(ix, 1), len(self._x) - 1)
        iy = min(max(iy, 1), len(self._y) - 1)

        x0, x1 = self._x[ix - 1], self._x[ix]
        y0, y1 = self._y[iy - 1], self._y[iy]
        tx = (x - x0) / (x1 - x0) if x1 != x0 else 0.0
        ty = (y - y0) / (y1 - y0) if y1 != y0 else 0.0

        V00 = self._solution[iy - 1, ix - 1]
        V10 = self._solution[iy - 1, ix]
        V01 = self._solution[iy, ix - 1]
        V11 = self._solution[iy, ix]
        return (
            (1.0 - tx) * (1.0 - ty) * V00
            + tx * (1.0 - ty) * V10
            + (1.0 - tx) * ty * V01
            + tx * ty * V11
        )

    def get_Ex(self, x, y):
        """Return the x-component of the electric field at (x, y)."""
        if self._solution is None:
            raise RuntimeError("Call solve() before asking for the field.")
        Ex, _ = self._get_field_components()
        return self._interp_scalar_field(Ex, x, y)

    def get_Ey(self, x, y):
        """Return the y-component of the electric field at (x, y)."""
        if self._solution is None:
            raise RuntimeError("Call solve() before asking for the field.")
        _, Ey = self._get_field_components()
        return self._interp_scalar_field(Ey, x, y)

    def _interp_scalar_field(self, field, x, y):
        if self._x is None or self._y is None:
            raise RuntimeError("The solution grid is not available.")

        x = float(x)
        y = float(y)
        if x < self._x[0] or x > self._x[-1] or y < self._y[0] or y > self._y[-1]:
            raise ValueError("Query point is outside the solved domain.")

        ix = np.searchsorted(self._x, x)
        iy = np.searchsorted(self._y, y)
        ix = min(max(ix, 1), len(self._x) - 1)
        iy = min(max(iy, 1), len(self._y) - 1)

        x0, x1 = self._x[ix - 1], self._x[ix]
        y0, y1 = self._y[iy - 1], self._y[iy]
        tx = (x - x0) / (x1 - x0) if x1 != x0 else 0.0
        ty = (y - y0) / (y1 - y0) if y1 != y0 else 0.0

        f00 = field[iy - 1, ix - 1]
        f10 = field[iy - 1, ix]
        f01 = field[iy, ix - 1]
        f11 = field[iy, ix]
        return (
            (1.0 - tx) * (1.0 - ty) * f00
            + tx * (1.0 - ty) * f10
            + (1.0 - tx) * ty * f01
            + tx * ty * f11
        )

    def electric_field(self, return_magnitude=False):
        """Return the electric field calculated from the solved potential.

        The returned arrays satisfy ``E = -grad(V)`` and have the same shape
        as the potential grid.  Because the geometry coordinates are in cm,
        the field components are expressed in V/cm.
        """
        Ex, Ey = self._get_field_components()
        if return_magnitude:
            return Ex, Ey, np.hypot(Ex, Ey)
        return Ex, Ey

    def _resolve_shape(self, shape_spec):
        if not self.shapes:
            raise ValueError("No shapes have been added to the Potential domain.")
        if isinstance(shape_spec, int):
            if shape_spec < 0 or shape_spec >= len(self.shapes):
                raise IndexError(
                    f"shape_index {shape_spec} is out of range (0 to {len(self.shapes) - 1})."
                )
            return self.shapes[shape_spec]
        if isinstance(shape_spec, str):
            for s in self.shapes:
                if s.label == shape_spec:
                    return s
            raise ValueError(f"No shape found with label {shape_spec!r}.")
        raise TypeError("shape_index must be an integer index or label string.")

    def sample_shape_field(
        self,
        shape_index=0,
        ds=0.1,
        component="magnitude",
        offset=0.0,
    ):
        """Sample electric field along the perimeter of a specified shape.

        Parameters
        ----------
        shape_index : int or str, optional
            Index (or label string) of the shape to sample along (default 0).
        ds : float, optional
            Step size in cm along the arc length (default 0.1).
        component : str, optional
            Field component to evaluate: ``"magnitude"`` (default),
            ``"normal"``, ``"tangential"``, ``"Ex"``, or ``"Ey"``.
        offset : float, optional
            Outward normal displacement in cm from the shape boundary
            (default 0.0).

        Returns
        -------
        dict
            Dictionary containing keys ``"s"`` (arc length array),
            ``"E"`` (field component array), ``"x"``, ``"y"``,
            ``"Ex"``, ``"Ey"``, ``"vertex_s"`` (corner positions), and
            ``"component"``.
        """
        if self._solution is None:
            raise RuntimeError("Call solve() before sampling the electric field.")

        ds = float(ds)
        if not np.isfinite(ds) or ds <= 0.0:
            raise ValueError("ds must be a positive, finite number.")
        offset = float(offset)
        if not np.isfinite(offset):
            raise ValueError("offset must be a finite number.")

        shape = self._resolve_shape(shape_index)

        if shape.kind == "circle":
            cx, cy = shape.center
            r_eff = shape.radius + offset
            if r_eff <= 0.0:
                raise ValueError("radius + offset must be positive.")
            total_L = 2.0 * np.pi * r_eff
            s_vals = np.arange(0.0, total_L, ds)
            if total_L - s_vals[-1] > 1e-9:
                s_vals = np.append(s_vals, total_L)

            theta = s_vals / r_eff
            x_arr = cx + r_eff * np.cos(theta)
            y_arr = cy + r_eff * np.sin(theta)
            nx_arr = np.cos(theta)
            ny_arr = np.sin(theta)
            tx_arr = -np.sin(theta)
            ty_arr = np.cos(theta)

            # Cardinal angles: 0, pi/2, pi, 3pi/2, 2pi
            cardinal_thetas = [0.0, 0.5 * np.pi, np.pi, 1.5 * np.pi, 2.0 * np.pi]
            vertex_s = [th * r_eff for th in cardinal_thetas]
            vertex_coords = [
                (cx + shape.radius * np.cos(th), cy + shape.radius * np.sin(th))
                for th in cardinal_thetas
            ]

        elif shape.kind in ("polygon", "rectangle"):
            if shape.kind == "rectangle":
                x0 = shape.center[0] - shape.width / 2.0
                y0 = shape.center[1] - shape.height / 2.0
                x1 = x0 + shape.width
                y1 = y0 + shape.height
                verts = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
            else:
                verts = list(shape.vertices)

            n_verts = len(verts)
            # Ensure CCW vertex order for positive signed area
            area = 0.0
            for i in range(n_verts):
                x1, y1 = verts[i]
                x2, y2 = verts[(i + 1) % n_verts]
                area += (x1 * y2 - x2 * y1)
            if area < 0:
                verts = verts[::-1]

            vertex_coords = list(verts) + [verts[0]]

            side_lengths = []
            tangents = []
            normals = []
            for i in range(n_verts):
                p1 = verts[i]
                p2 = verts[(i + 1) % n_verts]
                dx = p2[0] - p1[0]
                dy = p2[1] - p1[1]
                L = math.hypot(dx, dy)
                if L <= 0.0:
                    raise ValueError("Polygon has zero-length side.")
                side_lengths.append(L)
                tx, ty = dx / L, dy / L
                tangents.append((tx, ty))
                # Outward normal for CCW polygon
                normals.append((ty, -tx))

            vertex_s = [0.0]
            cum_s = 0.0
            for L in side_lengths:
                cum_s += L
                vertex_s.append(cum_s)

            total_L = cum_s
            s_vals = np.arange(0.0, total_L, ds)
            if total_L - s_vals[-1] > 1e-9:
                s_vals = np.append(s_vals, total_L)

            x_arr = np.zeros_like(s_vals)
            y_arr = np.zeros_like(s_vals)
            nx_arr = np.zeros_like(s_vals)
            ny_arr = np.zeros_like(s_vals)
            tx_arr = np.zeros_like(s_vals)
            ty_arr = np.zeros_like(s_vals)

            for k, s in enumerate(s_vals):
                seg_idx = 0
                for i in range(len(side_lengths)):
                    if s <= vertex_s[i + 1] or i == len(side_lengths) - 1:
                        seg_idx = i
                        break
                u = s - vertex_s[seg_idx]
                tx, ty = tangents[seg_idx]
                nx, ny = normals[seg_idx]
                x_arr[k] = verts[seg_idx][0] + u * tx + offset * nx
                y_arr[k] = verts[seg_idx][1] + u * ty + offset * ny
                tx_arr[k] = tx
                ty_arr[k] = ty
                nx_arr[k] = nx
                ny_arr[k] = ny
        else:
            raise ValueError(f"Unsupported shape kind: {shape.kind}")

        Ex_vals = np.zeros_like(s_vals)
        Ey_vals = np.zeros_like(s_vals)
        for k in range(len(s_vals)):
            x_clamp = min(max(x_arr[k], self._x[0]), self._x[-1])
            y_clamp = min(max(y_arr[k], self._y[0]), self._y[-1])
            Ex_vals[k] = self.get_Ex(x_clamp, y_clamp)
            Ey_vals[k] = self.get_Ey(x_clamp, y_clamp)

        if component == "magnitude":
            E_vals = np.hypot(Ex_vals, Ey_vals)
        elif component == "normal":
            E_vals = Ex_vals * nx_arr + Ey_vals * ny_arr
        elif component == "tangential":
            E_vals = Ex_vals * tx_arr + Ey_vals * ty_arr
        elif component == "Ex":
            E_vals = Ex_vals
        elif component == "Ey":
            E_vals = Ey_vals
        else:
            raise ValueError(
                f"Unknown component {component!r}. Expected 'magnitude', "
                "'normal', 'tangential', 'Ex', or 'Ey'."
            )

        return {
            "s": s_vals,
            "E": E_vals,
            "x": x_arr,
            "y": y_arr,
            "Ex": Ex_vals,
            "Ey": Ey_vals,
            "vertex_s": vertex_s,
            "vertex_coords": vertex_coords,
            "component": component,
        }

    @staticmethod
    def _fmt_coord(x, y):
        def _f(v):
            v = float(v)
            if abs(v - round(v)) < 1e-7:
                return f"{int(round(v))}"
            return f"{v:.2f}".rstrip("0").rstrip(".")

        return f"({_f(x)}, {_f(y)})"

    def plot_field_along_shape(
        self,
        shape_index=0,
        ds=0.1,
        component="magnitude",
        offset=0.0,
        annotate_coords=True,
        ax=None,
        show=False,
        return_figure=False,
    ):
        """Plot electric field along the perimeter of a specified shape.

        Parameters
        ----------
        shape_index : int or str, optional
            Index (or label string) of the shape to sample along (default 0).
        ds : float, optional
            Step size in cm along the arc length (default 0.1).
        component : str, optional
            Field component to evaluate: ``"magnitude"`` (default),
            ``"normal"``, ``"tangential"``, ``"Ex"``, or ``"Ey"``.
        offset : float, optional
            Outward normal displacement in cm from the shape boundary
            (default 0.0).
        annotate_coords : bool, optional
            Whether to annotate corner coordinates and start/end points on
            the plot (default True).
        ax : matplotlib.axes.Axes, optional
            Matplotlib axis to draw into. If None, a new figure is created.
        show : bool, optional
            Whether to call ``plt.show()`` (default False).
        return_figure : bool, optional
            If True, returns ``(fig, ax)`` (default False).
        """
        data = self.sample_shape_field(
            shape_index=shape_index,
            ds=ds,
            component=component,
            offset=offset,
        )

        s = data["s"]
        E = data["E"]
        vertex_s = data["vertex_s"]
        vertex_coords = data.get("vertex_coords", [])
        shape = self._resolve_shape(shape_index)

        if ax is None:
            fig, ax = plt.subplots(figsize=(8, 5))
        else:
            fig = ax.figure

        label_prefix = shape.label if shape.label else f"Shape {shape_index}"
        ax.plot(s, E, linewidth=2, label=f"{label_prefix} ({component})")

        # Add vertical dashed lines for corner vertices of polygons/rectangles
        if shape.kind in ("polygon", "rectangle") and len(vertex_s) > 2:
            for i, vs in enumerate(vertex_s[1:-1], start=1):
                ax.axvline(
                    vs,
                    color="gray",
                    linestyle="--",
                    alpha=0.6,
                    label="Corner" if i == 1 else None,
                )

        if annotate_coords and vertex_coords:
            for k, vs in enumerate(vertex_s):
                if k < len(vertex_coords):
                    coord = vertex_coords[k]
                    E_k = float(np.interp(vs, s, E))
                    ax.plot(vs, E_k, "o", color="red", markersize=4, zorder=5)

                    coord_str = self._fmt_coord(coord[0], coord[1])
                    if k == 0:
                        ha = "left"
                        xytext = (4, 8)
                    elif k == len(vertex_s) - 1:
                        ha = "right"
                        xytext = (-4, 8)
                    else:
                        ha = "center"
                        xytext = (0, 8)

                    ax.annotate(
                        coord_str,
                        xy=(vs, E_k),
                        xytext=xytext,
                        textcoords="offset points",
                        ha=ha,
                        va="bottom",
                        fontsize=8,
                        bbox=dict(
                            boxstyle="round,pad=0.2",
                            fc="white",
                            alpha=0.8,
                            ec="gray",
                            lw=0.5,
                        ),
                        zorder=6,
                    )

            ymin, ymax = ax.get_ylim()
            yspan = ymax - ymin if ymax != ymin else 1.0
            ax.set_ylim(ymin, ymax + 0.12 * yspan)

        component_labels = {
            "magnitude": "|E| (V/cm)",
            "normal": "En (V/cm)",
            "tangential": "Et (V/cm)",
            "Ex": "Ex (V/cm)",
            "Ey": "Ey (V/cm)",
        }
        ylabel = component_labels.get(component, f"E ({component}) (V/cm)")

        ax.set_xlabel("Arc length s (cm)")
        ax.set_ylabel(ylabel)
        ax.set_title(f"Electric Field along {label_prefix} Perimeter")
        ax.grid(True, linestyle=":", alpha=0.6)
        ax.legend(loc="best")

        if show:
            plt.show()

        if return_figure:
            return fig, ax
        return None

    def show(
        self,
        mode=None,
        ax=None,
        show=False,
        return_figure=False,
        x_range=None,
        y_range=None,
        seeding_density=None,
    ):
        """Draw the geometry, potential contours, electric field, or both.

        Parameters
        ----------
        mode : str, optional
            ``"contour"`` draws equipotential lines, ``"color"`` draws a
            filled voltage map, and ``"field"`` draws electric-field lines.
            Append ``,both`` to a potential style to overlay the electric
            field, for example ``"color,both"`` or ``"contour,both"``.
            The legacy modes ``"solution"`` and ``"both"`` remain aliases
            for ``"contour"`` and ``"contour,both"``, respectively.
        seeding_density : list, optional
            Field-line seed density indexed by shape insertion order. Values
            are seeds/cm for polygons and rectangles, and seeds/radian for
            circles. ``None`` retains the default density; ``0`` suppresses
            seeds from that shape.
        """
        if mode is None:
            mode = "contour" if self._solution is not None else "shapes"

        mode_aliases = {
            "solution": "contour",
            "both": "contour,both",
        }
        mode = mode_aliases.get(mode, mode)
        valid_modes = {
            "shapes",
            "contour",
            "color",
            "field",
            "contour,both",
            "color,both",
        }
        if mode not in valid_modes:
            raise ValueError(
                "mode must be 'shapes', 'contour', 'color', 'field', "
                "'contour,both', or 'color,both'."
            )
        if mode != "shapes" and self._solution is None:
            raise RuntimeError(f"Call solve() before showing mode={mode!r}.")

        def parse_range(value, name, domain_limit):
            if value is None:
                return 0.0, domain_limit
            if not isinstance(value, (tuple, list)) or len(value) != 2:
                raise ValueError(f"{name} must be a (minimum, maximum) pair.")
            minimum, maximum = float(value[0]), float(value[1])
            if not np.isfinite(minimum) or not np.isfinite(maximum):
                raise ValueError(f"{name} values must be finite.")
            if minimum < 0.0 or maximum > domain_limit or minimum >= maximum:
                raise ValueError(
                    f"{name} must satisfy 0 <= minimum < maximum <= {domain_limit}."
                )
            return minimum, maximum

        x_min, x_max = parse_range(x_range, "x_range", self.width)
        y_min, y_max = parse_range(y_range, "y_range", self.height)

        draw_contours = mode in ("contour", "contour,both")
        draw_colors = mode in ("color", "color,both")
        draw_field = mode in ("field", "contour,both", "color,both")

        if self._solution is None:
            x, y, X, Y = self._make_grid()
        else:
            x, y, X, Y = self._x, self._y, self._X, self._Y
        if ax is None:
            fig, ax = plt.subplots(figsize=(11, 8.5))
        else:
            fig = ax.figure

        ax.set_aspect("equal", "box")
        ax.set_xlim(x_min, x_max)
        ax.set_ylim(y_min, y_max)
        ax.set_xlabel("x (cm)")
        ax.set_ylabel("y (cm)")

        if draw_colors:
            voltage_map = ax.pcolormesh(
                X,
                Y,
                self._solution,
                shading="auto",
                cmap="coolwarm",
                zorder=0,
            )

        if draw_contours:
            levels = np.linspace(np.min(self._solution), np.max(self._solution), 21)
            cs = ax.contour(X, Y, self._solution, levels=levels, linewidths=1.0)
            ax.clabel(cs, inline=True, fontsize=8, fmt="%.1f V")

        if draw_field:
            field_lines = self.field_lines(seeding_density=seeding_density)
            for field_line in field_lines:
                path = field_line.path
                ax.plot(
                    path[:, 0],
                    path[:, 1],
                    color="C0",
                    linewidth=1.0,
                    alpha=0.8,
                )

                # Use path tangents for a few sparse arrows showing the
                # direction of increasing integration along each field line.
                if len(path) >= 5:
                    last_index = len(path) - 1
                    arrow_indices = np.asarray(
                        [
                            round(0.05 * last_index),
                            round(0.50 * last_index),
                            round(0.95 * last_index),
                        ],
                        dtype=int,
                    )
                    arrow_indices = np.clip(arrow_indices, 1, last_index - 1)
                    arrow_points = path[arrow_indices]
                    arrow_vectors = path[arrow_indices + 1] - path[arrow_indices - 1]
                    ax.quiver(
                        arrow_points[:-1, 0],
                        arrow_points[:-1, 1],
                        arrow_vectors[:-1, 0],
                        arrow_vectors[:-1, 1],
                        color="C0",
                        angles="xy",
                        scale_units="xy",
                        scale=1.0,
                        width=0.0025,
                        headwidth=3.5,
                        headlength=4.5,
                        headaxislength=4.0,
                        pivot="mid",
                        zorder=4,
                    )
                    ax.quiver(
                        arrow_points[-1:, 0],
                        arrow_points[-1:, 1],
                        arrow_vectors[-1:, 0],
                        arrow_vectors[-1:, 1],
                        color="C0",
                        angles="xy",
                        scale_units="xy",
                        scale=1.0,
                        width=0.0025,
                        headwidth=3.5,
                        headlength=4.5,
                        headaxislength=4.0,
                        pivot="tail",
                        zorder=4,
                    )

        for shape in self.shapes:
            patch = shape.as_patch()
            if shape.is_conductor:
                patch.set_fill(True)
                patch.set_facecolor("white")
                patch.set_edgecolor("black")
                patch.set_linewidth(2.0)
                patch.set_alpha(1.0)
            patch.set_zorder(10)
            ax.add_patch(patch)


        if mode == "shapes":
            ax.set_title("Shape layout")
        elif mode in ("contour", "color"):
            ax.set_title("Potential map")
        elif mode == "field":
            ax.set_title("Electric field")
        else:
            ax.set_title("Potential and electric field")

        if show:
            plt.show()

        if return_figure:
            return fig, ax
        return None

    def _apply_outer_boundary(self, V):
        if self.boundary_mode == "neumann":
            V[0, :] = V[1, :]
            V[-1, :] = V[-2, :]
            V[:, 0] = V[:, 1]
            V[:, -1] = V[:, -2]
        elif self.boundary_mode == "dirichlet0":
            V[0, :] = 0.0
            V[-1, :] = 0.0
            V[:, 0] = 0.0
            V[:, -1] = 0.0
        elif self.boundary_mode == "open":
            V[0, :] = self.far_value
            V[-1, :] = self.far_value
            V[:, 0] = self.far_value
            V[:, -1] = self.far_value
        else:
            raise ValueError(f"Unknown boundary_mode: {self.boundary_mode}")

    def _warn_if_open_problem_cannot_decay(self):
        if self.boundary_mode != "open":
            return

        relative_potentials = np.asarray(
            [
                shape.potential - self.far_value
                for shape in self.shapes
                if shape.is_conductor
            ],
            dtype=np.float64,
        )
        if relative_potentials.size == 0:
            return

        tolerance = 1e-12
        all_nonnegative = np.all(relative_potentials >= -tolerance)
        all_nonpositive = np.all(relative_potentials <= tolerance)
        has_nonzero = np.any(np.abs(relative_potentials) > tolerance)
        if has_nonzero and (all_nonnegative or all_nonpositive):
            warnings.warn(
                "All conductor potentials are on the same side of far_value. "
                "For a strictly 2D exterior electrostatic problem, such a "
                "potential generally cannot decay to far_value at infinity. "
                "The finite stretched-domain solution will still be computed, "
                "but it should not be interpreted as an exact open boundary.",
                RuntimeWarning,
                stacklevel=2,
            )

    @staticmethod
    def _constant_stencil_coefficients(x, y):
        """Five-point Laplacian coefficients on a nonuniform Cartesian grid."""
        h_w = x[1:-1] - x[:-2]
        h_e = x[2:] - x[1:-1]
        h_s = y[1:-1] - y[:-2]
        h_n = y[2:] - y[1:-1]

        a_w = (2.0 / (h_w * (h_w + h_e)))[None, :]
        a_e = (2.0 / (h_e * (h_w + h_e)))[None, :]
        a_s = (2.0 / (h_s * (h_s + h_n)))[:, None]
        a_n = (2.0 / (h_n * (h_s + h_n)))[:, None]
        denominator = a_w + a_e + a_s + a_n
        return a_w, a_e, a_s, a_n, denominator

    @staticmethod
    def _dielectric_stencil_coefficients(x, y, eps):
        """Finite-volume coefficients for div(epsilon grad(V)) = 0."""
        h_w = x[1:-1] - x[:-2]
        h_e = x[2:] - x[1:-1]
        h_s = y[1:-1] - y[:-2]
        h_n = y[2:] - y[1:-1]
        cell_width = 0.5 * (h_w + h_e)
        cell_height = 0.5 * (h_s + h_n)

        eps_c = eps[1:-1, 1:-1]

        def harmonic_mean(a, b):
            return 2.0 * a * b / (a + b)

        eps_w = harmonic_mean(eps_c, eps[1:-1, :-2])
        eps_e = harmonic_mean(eps_c, eps[1:-1, 2:])
        eps_s = harmonic_mean(eps_c, eps[:-2, 1:-1])
        eps_n = harmonic_mean(eps_c, eps[2:, 1:-1])

        a_w = eps_w * cell_height[:, None] / h_w[None, :]
        a_e = eps_e * cell_height[:, None] / h_e[None, :]
        a_s = eps_s * cell_width[None, :] / h_s[:, None]
        a_n = eps_n * cell_width[None, :] / h_n[:, None]
        denominator = a_w + a_e + a_s + a_n
        return a_w, a_e, a_s, a_n, denominator

    def _run_sor(
        self,
        V,
        fixed,
        coefficients,
        omega=1.85,
        tol=1e-5,
        max_iter=20000,
    ):
        omega = float(omega)
        tol = float(tol)
        if not np.isfinite(omega) or not 0.0 < omega < 2.0:
            raise ValueError("omega must be finite and between 0 and 2.")
        if not np.isfinite(tol) or tol <= 0.0:
            raise ValueError("tol must be a positive, finite number.")
        if isinstance(max_iter, bool) or int(max_iter) != max_iter:
            raise ValueError("max_iter must be a positive integer.")
        max_iter = int(max_iter)
        if max_iter < 1:
            raise ValueError("max_iter must be a positive integer.")

        if not np.any(~fixed[1:-1, 1:-1]):
            raise RuntimeError("No free interior points to solve.")

        fixed_values = V.copy()
        free_int = ~fixed[1:-1, 1:-1]
        ii, jj = np.indices(free_int.shape)
        red = ((ii + jj) & 1) == 0
        black = ~red
        a_w, a_e, a_s, a_n, denominator = coefficients
        Vc = V[1:-1, 1:-1]

        converged = False
        for iteration in range(1, max_iter + 1):
            self._apply_outer_boundary(V)
            V[fixed] = fixed_values[fixed]

            max_update = 0.0
            for color in (red, black):
                mask = free_int & color
                if not mask.any():
                    continue

                target = (
                    a_w * V[1:-1, :-2]
                    + a_e * V[1:-1, 2:]
                    + a_s * V[:-2, 1:-1]
                    + a_n * V[2:, 1:-1]
                ) / denominator
                step = omega * (target - Vc)
                Vc[:] = Vc + step * mask
                max_update = max(
                    max_update, float(np.max(np.abs(step[mask])))
                )

            if not np.isfinite(max_update):
                raise RuntimeError(
                    "Solver diverged (NaN/inf). Reduce omega (try 1.6)."
                )
            if max_update < tol:
                converged = True
                break

        self._apply_outer_boundary(V)
        V[fixed] = fixed_values[fixed]
        self.iterations = iteration
        self.converged = converged
        self.max_update = max_update
        if not converged:
            warnings.warn(
                f"Potential solver did not converge within {max_iter} "
                f"iterations; last maximum update was {max_update:.3g} V.",
                RuntimeWarning,
                stacklevel=2,
            )
        return V

    def _solve_laplace(
        self, x, y, X, Y, omega=1.85, tol=1e-5, max_iter=20000
    ):
        initial_value = self.far_value if self.boundary_mode == "open" else 0.0
        V = np.full(
            (len(y), len(x)), initial_value, dtype=np.float64
        )
        fixed = np.zeros_like(V, dtype=bool)

        for shape in self.shapes:
            if shape.is_conductor:
                mask = self._shape_mask(shape, X, Y)
                fixed |= mask
                V[mask] = shape.potential

        coefficients = self._constant_stencil_coefficients(x, y)
        return self._run_sor(
            V,
            fixed,
            coefficients,
            omega=omega,
            tol=tol,
            max_iter=max_iter,
        )

    def _solve_with_variable_dielectric(
        self, x, y, X, Y, omega=1.85, tol=1e-5, max_iter=20000
    ):
        initial_value = self.far_value if self.boundary_mode == "open" else 0.0
        V = np.full(
            (len(y), len(x)), initial_value, dtype=np.float64
        )
        fixed = np.zeros_like(V, dtype=bool)
        eps = np.full_like(V, self.medium_epsilon_r, dtype=np.float64)

        for shape in self.shapes:
            mask = self._shape_mask(shape, X, Y)
            if shape.is_conductor:
                fixed |= mask
                V[mask] = shape.potential
            else:
                eps[mask] = float(shape.epsilon_r)

        coefficients = self._dielectric_stencil_coefficients(x, y, eps)
        return self._run_sor(
            V,
            fixed,
            coefficients,
            omega=omega,
            tol=tol,
            max_iter=max_iter,
        )

    def solve(self, omega=None, tol=1e-5, max_iter=20000, return_result=False):
        self._check_overlaps()
        self._warn_if_open_problem_cannot_decay()

        if omega is None:
            omega = 1.95 if self.boundary_mode == "open" else 1.85

        x, y, X, Y = self._make_grid()
        if self._has_variable_dielectric():
            V = self._solve_with_variable_dielectric(x, y, X, Y, omega=omega, tol=tol, max_iter=max_iter)
        else:
            V = self._solve_laplace(x, y, X, Y, omega=omega, tol=tol, max_iter=max_iter)

        self._solution = V
        self._x = x
        self._y = y
        self._X = X
        self._Y = Y
        if return_result:
            return V
        return None
