"""Statistics helpers for reductions on quantities."""
from __future__ import annotations

from typing import Any
import numpy as np

from .ConstantQuantity import ConstantQuantity
from .UnitAlgebra import ureg


class Statistics:
    """Reduction-style statistics for quantity-like inputs.

    Methods return ConstantQuantity results and optionally compute
    interval-based uncertainties when mode="iv".
    """

    @staticmethod
    def _get_arrays(obj: Any) -> tuple[np.ndarray, np.ndarray]:
        if hasattr(obj, "nval"):
            vals = np.asarray(obj.nval, dtype=float)
        else:
            vals = np.asarray(obj, dtype=float)

        if hasattr(obj, "nunc") and obj.nunc is not None:
            uncs = np.asarray(obj.nunc, dtype=float)
        else:
            uncs = np.zeros_like(vals, dtype=float)

        if vals.shape != uncs.shape:
            try:
                uncs = np.broadcast_to(uncs, vals.shape)
            except Exception as e:
                raise ValueError("Value and uncertainty shapes are not broadcastable") from e

        return vals, uncs

    @staticmethod
    def _get_unit(obj: Any):
        unit = getattr(obj, "unit", None)
        if unit in (None, ""):
            return None
        try:
            return ureg.Unit(unit)
        except Exception:
            return unit

    @staticmethod
    def _reduce(obj: Any, func, name: str, mode: str | None, unit_power: int = 1, **kwargs):
        vals, uncs = Statistics._get_arrays(obj)
        unit = Statistics._get_unit(obj)
        if unit is not None and unit_power != 1:
            try:
                unit = unit ** unit_power
            except Exception:
                unit = None

        if mode is None:
            center = func(vals, **kwargs)
            cq = ConstantQuantity(center, None, str(unit or ""), name)
            cq.nunc = None
            cq.tunc = None
            return cq
        
        if mode != "iv":
            raise ValueError("mode must be None or 'iv'")

        lo = np.min(vals - uncs, **kwargs)
        hi = np.max(vals + uncs, **kwargs)
        center = 0.5 * (lo + hi)
        half = 0.5 * (hi - lo)
        return ConstantQuantity(center, half, str(unit or ""), name)
    
    @staticmethod
    def result(obj: Any, name: str = "", **kwargs) -> ConstantQuantity:
        return Statistics._reduce(obj, np.sum, name, mode="iv", **kwargs)

    @staticmethod
    def sum(obj: Any, name: str = "", mode: str | None = None, **kwargs) -> ConstantQuantity:
        return Statistics._reduce(obj, np.sum, name, mode=mode, **kwargs)

    @staticmethod
    def mean(obj: Any, name: str = "", mode: str | None = None, **kwargs) -> ConstantQuantity:
        return Statistics._reduce(obj, np.mean, name, mode=mode, **kwargs)

    @staticmethod
    def median(obj: Any, name: str = "", mode: str | None = None, **kwargs) -> ConstantQuantity:
        return Statistics._reduce(obj, np.median, name, mode=mode, **kwargs)

    @staticmethod
    def min(obj: Any, name: str = "", mode: str | None = None, **kwargs) -> ConstantQuantity:
        return Statistics._reduce(obj, np.min, name, mode=mode, **kwargs)

    @staticmethod
    def max(obj: Any, name: str = "", mode: str | None = None, **kwargs) -> ConstantQuantity:
        return Statistics._reduce(obj, np.max, name, mode=mode, **kwargs)

    @staticmethod
    def range(obj: Any, name: str = "", mode: str | None = None, **kwargs) -> ConstantQuantity:
        return Statistics._reduce(obj, np.ptp, name, mode=mode, **kwargs)

    @staticmethod
    def std(obj: Any, name: str = "", mode: str | None = None, **kwargs) -> ConstantQuantity:
        return Statistics._reduce(obj, np.std, name, mode=mode, ddof=1,**kwargs)

    @staticmethod
    def var(obj: Any, name: str = "", mode: str | None = None, **kwargs) -> ConstantQuantity:
        return Statistics._reduce(obj, np.var, name, mode=mode, unit_power=2, **kwargs)
