"""Unit algebra evaluator using pint for `DerivedQuantity.unit`.

This module provides `UnitAlgebra` which computes the resulting unit
of a SymPy expression given a mapping of symbol->source objects that
expose a `unit` attribute (string). Numeric constants are treated as
dimensionless. The implementation handles basic arithmetic: addition
/subtraction (requires identical units), multiplication, division and
power (integer or numeric exponents). Common math functions expect
dimensionless inputs and return dimensionless (except `sqrt` which
returns the square root of the argument unit).

If `pint` is not installed the module raises ImportError.
"""
from __future__ import annotations

from typing import Dict
import sympy as sp
import warnings

from . import expr_registry

try:
    import pint
except Exception as e:
    raise ImportError("pint is required for UnitAlgebra; install with `pip install pint`") from e

ureg = pint.UnitRegistry()
AUTO_CONVERT_UNITS = True
# Prefer compact ASCII unit formatting (e.g., m^2) by default.
try:
    ureg.formatter.default_format = "~"
except Exception:
    try:
        ureg.default_format = "~"
    except Exception:
        pass

# Rewrite power formatting to caret for all unit outputs.
try:
    _orig_format_unit = ureg.formatter.format_unit

    def _format_unit_caret(unit, *args, **kwargs):
        text = _orig_format_unit(unit, *args, **kwargs)
        return text.replace(" ** ", "^").replace("**", "^")

    ureg.formatter.format_unit = _format_unit_caret
except Exception:
    pass


class UnitAlgebra:
    """Compute the pint unit for a SymPy expression.

    Args:
        expr: SymPy expression
        sources: mapping from sympy.Symbol (or name) to objects with
                 a `.unit` attribute (string); missing unit -> dimensionless
    """

    def __init__(self, expr: sp.Expr, sources: Dict[sp.Symbol, object]):
        if not isinstance(expr, sp.Expr):
            raise TypeError("expr must be a sympy.Expr")
        self.expr = expr
        self._force_base_units = False
        self._needs_base_units = False
        # normalize keys to sympy.Symbol
        self.sources: Dict[sp.Symbol, object] = {}
        for k, v in dict(sources).items():
            if isinstance(k, str):
                self.sources[sp.Symbol(k)] = v
            elif isinstance(k, sp.Symbol):
                self.sources[k] = v
            else:
                raise TypeError("sources keys must be symbol names (str) or sympy.Symbol")

    def evaluate(self):
        """Return a pint Unit representing the expression's unit."""
        self._needs_base_units = False
        self._force_base_units = False
        if AUTO_CONVERT_UNITS and self._needs_conversion(self.expr):
            self._needs_base_units = True
            self._force_base_units = True
        unit = self._unit_of(self.expr)
        return unit

    def requires_base_units(self) -> bool:
        return self._needs_base_units

    def _unit_of(self, expr: sp.Expr):
        # Numbers and common symbolic constants: dimensionless
        if expr.is_Number or expr is sp.pi or expr is sp.E:
            return ureg.dimensionless

        # Symbols: look up provided source unit (default dimensionless)
        if expr.is_Symbol:
            src = self.sources.get(expr, None)
            if src is None:
                # treat unknown symbols as dimensionless
                return ureg.dimensionless
            unit_str = getattr(src, "unit", "")
            if unit_str in (None, ""):
                return ureg.dimensionless
            try:
                unit = ureg.Unit(unit_str)
                if self._force_base_units:
                    return ureg.Quantity(1, unit).to_base_units().units
                return unit
            except Exception:
                # if parsing fails, warn and treat as dimensionless
                warnings.warn(f"Could not parse unit '{unit_str}' for symbol {expr}; treating as dimensionless", UserWarning)
                return ureg.dimensionless

        # Addition/Subtraction: require identical units for all non-dimensionless terms.
        # Mixing dimensionless and unit-carrying terms is invalid.
        if expr.is_Add:
            args = list(expr.args)
            if not args:
                return ureg.dimensionless
            units = [self._unit_of(a) for a in args]
            unitful = [u for u in units if not self._is_dimensionless(u)]
            if not unitful:
                return ureg.dimensionless
            if len(unitful) != len(units):
                raise ValueError("Cannot add/subtract dimensionless and unit-carrying terms")
            first_unit = unitful[0]
            for ua in unitful[1:]:
                if not self._units_equal(first_unit, ua):
                    if AUTO_CONVERT_UNITS and self._force_base_units and self._units_compatible(first_unit, ua):
                        continue
                    raise ValueError(f"Incompatible units for addition: {first_unit} vs {ua}")
            return first_unit

        # Multiplication/Division
        if expr.is_Mul:
            result = ureg.dimensionless
            for a in expr.args:
                ua = self._unit_of(a)
                result = result * ua
            return result

        # Power
        if expr.is_Pow:
            base, exp = expr.args
            ubase = self._unit_of(base)
            # require numeric exponent
            if exp.is_Number:
                exp_val = float(exp)
                try:
                    return ubase ** exp_val
                except Exception:
                    raise ValueError(f"Cannot raise unit {ubase} to power {exp_val}")
            else:
                raise ValueError("Non-numeric exponent; cannot compute unit")

        # Function calls: handle common unit-carrying functions
        if isinstance(expr, sp.Function) or expr.is_Function:
            fname = expr.func.__name__
            arg_units = [self._unit_of(a) for a in expr.args]
            return expr_registry.unit_rule(fname, arg_units, ureg)

        # Fallback
        raise NotImplementedError(f"Cannot compute unit for expression: {expr}")

    def _is_dimensionless(self, u):
        try:
            return u.dimensionality == ureg.dimensionless.dimensionality
        except Exception:
            return False

    def _units_equal(self, a, b):
        try:
            return a == b
        except Exception:
            try:
                return a.dimensionality == b.dimensionality
            except Exception:
                return False

    def _units_compatible(self, a, b):
        try:
            return a.dimensionality == b.dimensionality
        except Exception:
            return False

    def _needs_conversion(self, expr: sp.Expr) -> bool:
        if expr.is_Number or expr is sp.pi or expr is sp.E:
            return False

        if expr.is_Symbol:
            return False

        if expr.is_Add:
            args = list(expr.args)
            if not args:
                return False
            units = [self._unit_of(a) for a in args]
            unitful = [u for u in units if not self._is_dimensionless(u)]
            if not unitful:
                return False
            if len(unitful) != len(units):
                return False
            first_unit = unitful[0]
            for ua in unitful[1:]:
                if not self._units_equal(first_unit, ua) and self._units_compatible(first_unit, ua):
                    return True
            return any(self._needs_conversion(a) for a in args)

        if expr.is_Mul or expr.is_Pow or expr.is_Function:
            return any(self._needs_conversion(a) for a in expr.args)

        return False
