"""cpplabs - NumPy-backed bounded-quantity row prototype"""

import numpy as np
import matplotlib.pyplot as plt
import sympy as sp

# Prefer compact numeric printing for users importing the package interactively
np.set_printoptions(suppress=True)

from .MeasuredQuantity import MeasuredQuantity
from .DerivedQuantity import DerivedQuantity
from .UnitAlgebra import UnitAlgebra, ureg
from .IntervalArithmetic import IntervalArithmetic
from .Analyze import Analyze
from .Statistics import Statistics
from .ConstantQuantity import ConstantQuantity
from .Potential import Potential

# Short aliases for interactive use
MeasurementQuantity = MeasuredQuantity
Meas = MeasuredQuantity
Calc = DerivedQuantity
Const = ConstantQuantity
Sampling = Statistics
from .Plot import Plot
from .table_record import record_data_table, display_data_table
from .constants import *
__all__ = [
	"MeasuredQuantity",
	"MeasurementQuantity",
	"Meas",
	"DerivedQuantity",
	"Calc",
	"UnitAlgebra",
	"ureg",
	"IntervalArithmetic",
	"Analyze",
	"Statistics",
	"Sampling",
	"ConstantQuantity",
	"Const",
	"Potential",
	"record_data_table",
	"display_data_table",
	"pi",
	"E",
	"g",
	"c",
	"h",
	"hbar",
	"e",
	"k_B",
	"N_A",
	"R",
	"G",
	"epsilon0",
	"mu0",
	"electron_mass",
	"proton_mass",
	"Plot",
 	"export"
]

try:
	# register IPython magics if running in a notebook
	from IPython import get_ipython
	ip = get_ipython()
	if ip is not None:
		# import module which registers the %%record magic
		from . import ipython_magic  # noqa: F401
except Exception:
	pass


