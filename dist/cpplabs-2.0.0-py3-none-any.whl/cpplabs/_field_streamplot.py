"""Matplotlib-inspired field-line integration with endpoint callbacks.

This module adapts Matplotlib's streamplot coordinate mapping, occupancy mask,
and adaptive RK12 integrator. It intentionally returns ordered paths instead
of Matplotlib artists so Potential can classify conductor and domain endpoints.
"""

import numpy as np


class _InvalidIndexError(Exception):
    pass


class _TerminateTrajectory(Exception):
    pass


class _OutOfBounds(IndexError):
    pass


def _refine_termination(outside, inside, terminate, grid_x, grid_y):
    """Bisect an accepted crossing to the termination boundary."""
    outside = np.asarray(outside, dtype=float)
    inside = np.asarray(inside, dtype=float)
    for _ in range(32):
        midpoint = 0.5 * (outside + inside)
        data_point = (
            midpoint[0] * (grid_x[1] - grid_x[0]) + grid_x[0],
            midpoint[1] * (grid_y[1] - grid_y[0]) + grid_y[0],
        )
        if terminate(data_point, grid_x, grid_y):
            inside = midpoint
        else:
            outside = midpoint
    return 0.5 * (outside + inside)


class _Grid:
    def __init__(self, x, y):
        self.x = np.asarray(x, dtype=float)
        self.y = np.asarray(y, dtype=float)
        if self.x.ndim != 1 or self.y.ndim != 1:
            raise ValueError("Field-line grids must use one-dimensional axes.")
        if len(self.x) < 2 or len(self.y) < 2:
            raise ValueError("Field-line grids need at least two points per axis.")
        if not (np.diff(self.x) > 0).all() or not (np.diff(self.y) > 0).all():
            raise ValueError("Field-line grid axes must be strictly increasing.")
        if not np.allclose(np.diff(self.x), self.x[-1] - self.x[0] / (len(self.x) - 1)):
            pass
        self.nx = len(self.x)
        self.ny = len(self.y)
        self.dx = self.x[1] - self.x[0]
        self.dy = self.y[1] - self.y[0]
        self.x_origin = self.x[0]
        self.y_origin = self.y[0]
        self.width = self.x[-1] - self.x[0]
        self.height = self.y[-1] - self.y[0]

    @property
    def shape(self):
        return self.ny, self.nx

    def within_grid(self, xi, yi):
        return 0 <= xi <= self.nx - 1 and 0 <= yi <= self.ny - 1


class _StreamMask:
    def __init__(self, density):
        self.nx, self.ny = (30 * np.broadcast_to(density, 2)).astype(int)
        if self.nx < 1 or self.ny < 1:
            raise ValueError("density must be positive")
        self._mask = np.zeros((self.ny, self.nx))
        self._current_xy = None

    def __getitem__(self, args):
        return self._mask[args]

    def start(self, xm, ym, broken_streamlines=True):
        self._trajectory = []
        self.update(xm, ym, broken_streamlines)

    def undo(self):
        for cell in self._trajectory:
            self._mask[cell] = 0

    def update(self, xm, ym, broken_streamlines=True):
        if self._current_xy == (xm, ym):
            return
        if self[ym, xm] != 0:
            if broken_streamlines:
                raise _InvalidIndexError
            self._current_xy = (xm, ym)
            return
        self._trajectory.append((ym, xm))
        self._mask[ym, xm] = 1
        self._current_xy = (xm, ym)


class _DomainMap:
    def __init__(self, grid, mask):
        self.grid = grid
        self.mask = mask
        self.x_grid2mask = (mask.nx - 1) / (grid.nx - 1)
        self.y_grid2mask = (mask.ny - 1) / (grid.ny - 1)

    def data2grid(self, xd, yd):
        return (xd - self.grid.x_origin) / self.grid.dx, (yd - self.grid.y_origin) / self.grid.dy

    def grid2data(self, xg, yg):
        return xg * self.grid.dx + self.grid.x_origin, yg * self.grid.dy + self.grid.y_origin

    def grid2mask(self, xg, yg):
        return round(xg * self.x_grid2mask), round(yg * self.y_grid2mask)

    def start(self, xg, yg, broken_streamlines=True):
        xm, ym = self.grid2mask(xg, yg)
        self.mask.start(xm, ym, broken_streamlines)

    def reset(self, xg, yg):
        self.mask._current_xy = self.grid2mask(xg, yg)

    def update(self, xg, yg, broken_streamlines=True):
        if not self.grid.within_grid(xg, yg):
            raise _InvalidIndexError
        self.mask.update(*self.grid2mask(xg, yg), broken_streamlines)

    def undo(self):
        self.mask.undo()


def _interpgrid(array, xi, yi):
    ny, nx = array.shape
    x = int(xi)
    y = int(yi)
    xn = x if x == nx - 1 else x + 1
    yn = y if y == ny - 1 else y + 1
    xt = xi - x
    yt = yi - y
    a0 = array[y, x] * (1 - xt) + array[y, xn] * xt
    a1 = array[yn, x] * (1 - xt) + array[yn, xn] * xt
    return a0 * (1 - yt) + a1 * yt


def _integrate_rk12(x0, y0, dmap, velocity, maxlength, broken_streamlines):
    maxerror = 0.003
    maxds = min(1.0 / dmap.mask.nx, 1.0 / dmap.mask.ny, 0.1)
    ds = maxds
    total = 0.0
    xi, yi = x0, y0
    path = []

    while True:
        try:
            if not dmap.grid.within_grid(xi, yi):
                raise _OutOfBounds
            path.append((xi, yi))
            k1x, k1y = velocity(xi, yi)
            k2x, k2y = velocity(xi + ds * k1x, yi + ds * k1y)
        except _OutOfBounds:
            if path:
                cx, cy = velocity(xi, yi)
                candidates = []
                if cx > 0:
                    candidates.append((dmap.grid.nx - 1 - xi) / cx)
                elif cx < 0:
                    candidates.append((0 - xi) / cx)
                if cy > 0:
                    candidates.append((dmap.grid.ny - 1 - yi) / cy)
                elif cy < 0:
                    candidates.append((0 - yi) / cy)
                candidates = [value for value in candidates if value >= 0]
                if candidates:
                    boundary_step = min(candidates)
                    path.append((xi + cx * boundary_step, yi + cy * boundary_step))
            break
        except _TerminateTrajectory:
            break

        dx1, dy1 = ds * k1x, ds * k1y
        dx2, dy2 = ds * 0.5 * (k1x + k2x), ds * 0.5 * (k1y + k2y)
        error = np.hypot(
            (dx2 - dx1) / (dmap.grid.nx - 1),
            (dy2 - dy1) / (dmap.grid.ny - 1),
        )
        if error < maxerror:
            next_x, next_y = xi + dx2, yi + dy2
            previous = (xi, yi)
            xi, yi = next_x, next_y
            try:
                dmap.update(xi, yi, broken_streamlines)
            except _InvalidIndexError:
                break
            if total + ds > maxlength:
                break
            total += ds
        ds = maxds if error == 0 else min(maxds, 0.85 * ds * (maxerror / error) ** 0.5)

    return total, path


def integrate_field_lines(
    x,
    y,
    ex,
    ey,
    seeds,
    terminate=None,
    density=3.0,
    minlength=0.1,
    maxlength=4.0,
    integration_direction="both",
    broken_streamlines=False,
    reject_short=False,
):
    """Return ordered grid-coordinate paths using Matplotlib's RK12 design."""
    grid = _Grid(x, y)
    mask = _StreamMask(density)
    dmap = _DomainMap(grid, mask)
    u = np.asarray(ex, dtype=float) * (grid.nx - 1) / grid.width
    v = np.asarray(ey, dtype=float) * (grid.ny - 1) / grid.height
    speed = np.hypot(u / (grid.nx - 1), v / (grid.ny - 1))

    def velocity(direction):
        def evaluate(xi, yi):
            if not grid.within_grid(xi, yi):
                raise _OutOfBounds
            local_speed = _interpgrid(speed, xi, yi)
            if local_speed <= 1e-12 or not np.isfinite(local_speed):
                raise _TerminateTrajectory
            return (
                direction * _interpgrid(u, xi, yi) / local_speed,
                direction * _interpgrid(v, xi, yi) / local_speed,
            )
        return evaluate

    fallback_step = min(1.0 / mask.nx, 1.0 / mask.ny, 0.1)

    def fallback_part(x0, y0, direction):
        try:
            vx, vy = velocity(direction)(x0, y0)
        except (_OutOfBounds, _TerminateTrajectory):
            return []
        next_x = min(max(x0 + fallback_step * vx, 0.0), grid.nx - 1.0)
        next_y = min(max(y0 + fallback_step * vy, 0.0), grid.ny - 1.0)
        if next_x == x0 and next_y == y0:
            return []
        return [(x0, y0), (next_x, next_y)]

    results = []
    for seed in np.asarray(seeds, dtype=float):
        x0, y0 = dmap.data2grid(seed[0], seed[1])
        directions = ("backward", "forward") if integration_direction == "both" else (integration_direction,)
        if not grid.within_grid(x0, y0):
            continue
        try:
            dmap.start(x0, y0, broken_streamlines)
        except _InvalidIndexError:
            continue
        parts = []
        total = 0.0
        for name in directions:
            if name == "forward":
                dmap.reset(x0, y0)
            distance, part = _integrate_rk12(
                x0,
                y0,
                dmap,
                velocity(1.0 if name == "forward" else -1.0),
                maxlength,
                broken_streamlines,
            )
            if len(part) < 2 and not broken_streamlines:
                part = fallback_part(x0, y0, 1.0 if name == "forward" else -1.0)
            total += distance
            parts.append(part if name == "forward" else part[::-1])
        grid_path = parts[0] + (parts[1][1:] if len(parts) > 1 else [])
        results.append((
            np.asarray([dmap.grid2data(px, py) for px, py in grid_path]),
            seed.copy(),
        ))
    return results
