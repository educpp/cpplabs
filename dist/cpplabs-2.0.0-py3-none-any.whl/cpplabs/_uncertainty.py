"""Shared uncertainty-text parsing helpers."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_CEILING, localcontext
import re


_PERCENT_UNCERTAINTY_RE = re.compile(
    r"^(?P<percentage>(?:\d+(?:\.\d*)?|\.\d+))%(?P<counts>\d+)?$"
)
_PLAIN_DECIMAL_RE = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$")


def absolute_uncertainty_from_percent(
    value_text: str, uncertainty_text: str
) -> str | None:
    """Convert ``percentage%counts`` text to absolute uncertainty text."""
    uncertainty_text = str(uncertainty_text).strip()
    if "%" not in uncertainty_text:
        return None

    match = _PERCENT_UNCERTAINTY_RE.fullmatch(uncertainty_text)
    if match is None:
        raise ValueError(
            "Percent uncertainty must use '<percentage>%' or "
            "'<percentage>%<nonnegative integer counts>'."
        )

    value_text = str(value_text).strip()
    if not _PLAIN_DECIMAL_RE.fullmatch(value_text):
        raise ValueError(
            "Percent uncertainty requires the measured value to be a "
            "plain decimal string (scientific notation is not supported)."
        )

    try:
        value = Decimal(value_text)
        percentage = Decimal(match.group("percentage"))
        counts = Decimal(match.group("counts") or "0")
    except InvalidOperation as exc:
        raise ValueError("Could not parse percent uncertainty.") from exc

    if not value.is_finite() or not percentage.is_finite():
        raise ValueError("Value and percentage must be finite.")

    unsigned_value = value_text.lstrip("+-")
    decimal_places = (
        len(unsigned_value.split(".", 1)[1])
        if "." in unsigned_value
        else 0
    )
    resolution = Decimal(1).scaleb(-decimal_places)
    precision = max(
        28,
        len(value.as_tuple().digits)
        + len(percentage.as_tuple().digits)
        + len(counts.as_tuple().digits)
        + decimal_places
        + 10,
    )
    try:
        with localcontext() as context:
            context.prec = precision
            absolute = (
                abs(value) * percentage / Decimal(100)
                + counts * resolution
            )
            rounded = absolute.quantize(resolution, rounding=ROUND_CEILING)
    except InvalidOperation as exc:
        raise ValueError("Could not calculate percent uncertainty.") from exc
    return format(rounded, f".{decimal_places}f")
