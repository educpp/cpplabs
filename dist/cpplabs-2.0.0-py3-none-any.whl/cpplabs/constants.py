"""Physical constants exported as `ConstantQuantity` objects.

Values and standard uncertainties are taken from the CODATA 2022
recommendations (see the NIST table). The ASCII table of values is
available at:

https://physics.nist.gov/cuu/Constants/Table/allascii.txt

This module provides `ConstantQuantity` objects named like `g`, `c`, `h`,
etc., which expose `.nval`, `.nunc`, `.unit`, `.name` and `.to()` and are
suited to pass as symbolic sources into `DerivedQuantity` /
`IntervalArithmetic`.

Do not mutate the `ConstantQuantity` objects; treat them as read-only.
"""
from .ConstantQuantity import ConstantQuantity
from .UnitAlgebra import ureg


def _mk(name: str, val: float, unit: str, unc: float = 0.0) -> ConstantQuantity:
    """Create a `ConstantQuantity` for `name` with numeric `val`, unit and `unc`.

    This helper does not create pint `Quantity` aliases; callers should
    construct a pint Quantity from the `ConstantQuantity` when needed.
    """
    cq = ConstantQuantity(val, unc, unit, name)
    return cq


# Common SI constants (values from CODATA / exact definitions where applicable)
import math

# Values and standard uncertainties from CODATA 2022 (wall chart)
# Exact/defined constants have zero uncertainty.
pi = _mk("pi", math.pi, "", 0.0)
E = _mk("euler_number", math.e, "", 0.0)
g = _mk("standard_gravity", 9.80665, "m/s**2", 0.0)
c = _mk("speed_of_light", 299792458.0, "m/s", 0.0)
h = _mk("planck_constant", 6.62607015e-34, "J*s", 0.0)
# reduced Planck constant (derived from exact h)
hbar = _mk("reduced_planck", 6.62607015e-34 / (2.0 * math.pi), "J*s", 0.0)
e = _mk("elementary_charge", 1.602176634e-19, "C", 0.0)
k_B = _mk("boltzmann_constant", 1.380649e-23, "J/K", 0.0)
N_A = _mk("avogadro_constant", 6.02214076e23, "1/mol", 0.0)
R = _mk("molar_gas_constant", 8.31446261815324, "J/(mol*K)", 0.0)
# Newtonian gravitational constant with CODATA 2022 standard uncertainty
G = _mk("gravitational_constant", 6.67430e-11, "m**3/(kg*s**2)", 1.5e-15)
# Vacuum permittivity and permeability with reported uncertainties
epsilon0 = _mk("vacuum_permittivity", 8.8541878188e-12, "F/m", 1.4e-21)
mu0 = _mk("vacuum_permeability", 1.25663706127e-6, "N/A**2", 2.0e-16)
# Electron and proton masses with CODATA 2022 uncertainties
electron_mass = _mk("electron_mass", 9.1093837139e-31, "kg", 2.8e-40)
proton_mass = _mk("proton_mass", 1.67262192595e-27, "kg", 5.2e-37)


__all__ = [
    # constant objects
    "pi",
    "E",
    "g",
    "c",
    "h",
    "hbar",
    "e",
    "k_B",
    "N_A",
    "R",
    "G",
    "epsilon0",
    "mu0",
    "electron_mass",
    "proton_mass",
    # no pint aliases exported; construct pint Quantities from the
    # `ConstantQuantity` objects when needed
]
