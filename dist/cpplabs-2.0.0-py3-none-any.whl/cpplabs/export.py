"""Export executed Jupyter notebooks to HTML and PDF."""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence


@dataclass(frozen=True)
class ExportResult:
    """Paths produced by a notebook export."""

    notebook: Path
    html: Path
    pdf: Path


def export_notebook(
    notebook: str | Path,
    output_dir: str | Path = "build",
    *,
    name: str | None = None,
    execute: bool = False,
    timeout: int = 600,
    kernel_name: str | None = None,
    allow_chromium_download: bool = False,
) -> ExportResult:
    """Export a notebook to HTML and PDF.

    The notebook is not executed unless ``execute=True``. The source notebook
    is never modified.
    """
    notebook_path = Path(notebook).expanduser().resolve()
    if not notebook_path.is_file():
        raise FileNotFoundError(f"Notebook not found: {notebook_path}")

    try:
        import nbformat
    except ImportError as error:
        raise RuntimeError(
            "Notebook export requires nbformat. Install cpplabs with the export extra."
        ) from error

    try:
        notebook_node = nbformat.read(notebook_path, as_version=4)
    except Exception as error:
        raise ValueError(f"Could not read notebook {notebook_path}: {error}") from error

    if execute:
        try:
            from nbclient import NotebookClient

            client_options = {
                "timeout": timeout,
                "resources": {"metadata": {"path": str(notebook_path.parent)}},
            }
            if kernel_name is not None:
                client_options["kernel_name"] = kernel_name
            client = NotebookClient(notebook_node, **client_options)
            client.execute()
        except Exception as error:
            raise RuntimeError(f"Notebook execution failed for {notebook_path}: {error}") from error

    try:
        from nbconvert import HTMLExporter
        from nbconvert.exporters import WebPDFExporter
    except ImportError as error:
        raise RuntimeError(
            "Notebook export requires nbconvert. Install cpplabs with the export extra."
        ) from error

    output_path = Path(output_dir).expanduser().resolve()
    output_path.mkdir(parents=True, exist_ok=True)
    stem = name or notebook_path.stem
    html_path = output_path / f"{stem}.html"
    pdf_path = output_path / f"{stem}.pdf"

    html_exporter = HTMLExporter(template_name="lab")
    html_data, _ = html_exporter.from_notebook_node(notebook_node)
    html_path.write_text(html_data, encoding="utf-8")

    pdf_exporter = WebPDFExporter()
    pdf_exporter.allow_chromium_download = allow_chromium_download
    pdf_data, _ = pdf_exporter.from_notebook_node(notebook_node)
    pdf_path.write_bytes(pdf_data)

    return ExportResult(notebook_path, html_path, pdf_path)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="cpplabs-export",
        description="Export a Jupyter notebook to HTML and PDF.",
    )
    parser.add_argument("notebook", type=Path, help="Path to the notebook to export")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("build"),
        help="Directory for generated files (default: build)",
    )
    parser.add_argument("--name", help="Base name for generated HTML and PDF files")
    parser.add_argument(
        "--execute",
        action="store_true",
        help="Execute the notebook before exporting it",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=600,
        help="Execution timeout in seconds (default: 600)",
    )
    parser.add_argument("--kernel-name", help="Kernel to use with --execute")
    parser.add_argument(
        "--allow-chromium-download",
        action="store_true",
        help="Allow nbconvert to download Chromium if it is unavailable",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the ``cpplabs-export`` command-line interface."""
    args = _build_parser().parse_args(argv)
    try:
        result = export_notebook(
            args.notebook,
            args.output_dir,
            name=args.name,
            execute=args.execute,
            timeout=args.timeout,
            kernel_name=args.kernel_name,
            allow_chromium_download=args.allow_chromium_download,
        )
    except (FileNotFoundError, ValueError, RuntimeError) as error:
        print(f"cpplabs-export: error: {error}", file=sys.stderr)
        return 1

    print(f"Notebook: {result.notebook}")
    print(f"HTML: {result.html}")
    print(f"PDF: {result.pdf}")
    print(f"Download PDF: {result.pdf.as_uri()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
