"""Expression registry helpers for SymPy evaluation.

Provides function maps used by:
- SymPy lambdify numeric evaluation
- Interval arithmetic lambdify
- Unit propagation rules
"""
from __future__ import annotations

from typing import Any, Dict, Iterable
import math
import numpy as np
import sympy as sp


def get_sympify_locals() -> Dict[str, Any]:
    """Return name-to-function map for SymPy parsing.

    This is used by `sympify` so expressions like `sin(x)` resolve to
    SymPy functions rather than raw Python names.
    """
    return {
        "Abs": sp.Abs,
        "sqrt": sp.sqrt,
        "log": sp.log,
        "exp": sp.exp,
        "sin": sp.sin,
        "cos": sp.cos,
        "tan": sp.tan,
    }


def get_lambdify_modules() -> list:
    """Return module list used by `sympy.lambdify` for numeric evaluation."""
    return [
        {
            "Abs": np.abs,
        },
        "numpy",
        "sympy",
    ]


def get_interval_map(iv) -> Dict[str, Any]:
    """Return interval-function mapping for `mpmath.iv` evaluation.

    Includes strict-domain wrappers for `asin`, `acos`, and `atan` that
    raise on out-of-range inputs to avoid silent invalid intervals.
    """
    def _iv_bounds(z):
        try:
            return z.a, z.b
        except Exception:
            return z, z

    def _iv_asin(z):
        lo, hi = _iv_bounds(z)
        lo_f = float(lo)
        hi_f = float(hi)
        if lo_f < -1.0 or hi_f > 1.0:
            raise ValueError("asin interval outside [-1, 1]")
        return iv.mpf([math.asin(lo_f), math.asin(hi_f)])

    def _iv_acos(z):
        lo, hi = _iv_bounds(z)
        lo_f = float(lo)
        hi_f = float(hi)
        if lo_f < -1.0 or hi_f > 1.0:
            raise ValueError("acos interval outside [-1, 1]")
        return iv.mpf([math.acos(hi_f), math.acos(lo_f)])

    def _iv_atan(z):
        lo, hi = _iv_bounds(z)
        return iv.mpf([math.atan(float(lo)), math.atan(float(hi))])

    def _build_iv_map(names: Iterable[str]) -> Dict[str, Any]:
        mapping: Dict[str, Any] = {}
        for name in names:
            func = getattr(iv, name, None)
            if func is not None:
                mapping[name] = func
        return mapping

    iv_funcs = _build_iv_map(
        [
            "sqrt",
            "log",
            "exp",
            "sin",
            "cos",
            "tan",
            "sinh",
            "cosh",
            "tanh",
        ]
    )
    iv_funcs["asin"] = _iv_asin
    iv_funcs["acos"] = _iv_acos
    iv_funcs["atan"] = _iv_atan
    iv_funcs["Abs"] = getattr(iv, "fabs", None) or getattr(iv, "abs", None) or abs
    iv_funcs["iv"] = iv
    return iv_funcs


def unit_rule(fname: str, units: Iterable[Any], ureg) -> Any:
    """Return output unit for a function given input units.

    Trig and exponential/log functions require dimensionless inputs.
    Inverse trig functions return radians.
    """
    units = list(units)
    if fname == "sqrt":
        return units[0] ** 0.5
    if fname == "Abs":
        return units[0]
    if fname in ("sin", "cos", "tan", "log", "exp"):
        for u in units:
            if not _is_dimensionless(u, ureg):
                raise ValueError(f"Function {fname} expects dimensionless argument, got {u}")
        return ureg.dimensionless
    if fname in ("asin", "acos", "atan"):
        for u in units:
            if not _is_dimensionless(u, ureg):
                raise ValueError(f"Function {fname} expects dimensionless argument, got {u}")
        return ureg.radian
    raise ValueError(f"Unknown unit rule for function '{fname}'")


def _is_dimensionless(u, ureg) -> bool:
    """Return True when the unit has dimensionless dimensionality."""
    try:
        return u.dimensionality == ureg.dimensionless.dimensionality
    except Exception:
        return False


def _units_equal(a, b) -> bool:
    """Safe unit equality check used by unit algebra helpers."""
    try:
        return a == b
    except Exception:
        try:
            return a.dimensionality == b.dimensionality
        except Exception:
            return False
