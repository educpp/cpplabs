"""Plain-text formatting utilities for cpplabs quantities.

Minimal, dependency-free routines to format single quantities and
render simple ASCII tables. Numeric values are formatted using a fixed
decimal precision with a minimum significant-figure check, while
presentation strings (`tval`/`tunc`) are preserved when provided.
"""
from __future__ import annotations

from typing import Any, Iterable, List, Tuple
import math
import numpy as np


DEFAULT_DECIMALS = 6
MIN_SIGFIGS = 3


def _count_sigfigs(text: str) -> int:
    stripped = text.strip().lower()
    if "e" in stripped:
        mantissa, _ = stripped.split("e", 1)
    else:
        mantissa = stripped

    mantissa = mantissa.lstrip("+-")
    if "." in mantissa:
        mantissa = mantissa.replace(".", "", 1)

    mantissa = mantissa.lstrip("0")
    digits = "".join(ch for ch in mantissa if ch.isdigit())
    return len(digits)


def _pad_sigfigs(text: str, min_sigfigs: int) -> str:
    if min_sigfigs <= 0:
        return text

    stripped = text.strip().lower()
    if "e" in stripped:
        mantissa, exponent = stripped.split("e", 1)
        exp_suffix = f"e{exponent}"
    else:
        mantissa = stripped
        exp_suffix = ""

    sign = ""
    if mantissa.startswith(('+', '-')):
        sign = mantissa[0]
        mantissa = mantissa[1:]

    sigs = _count_sigfigs(mantissa)
    if sigs >= min_sigfigs:
        return f"{sign}{mantissa}{exp_suffix}"

    if "." not in mantissa:
        mantissa = f"{mantissa}."

    needed = min_sigfigs - sigs
    mantissa = f"{mantissa}{'0' * needed}"
    return f"{sign}{mantissa}{exp_suffix}"


def _format_number(value: Any, decimals: int | None = DEFAULT_DECIMALS, min_sigfigs: int = MIN_SIGFIGS) -> str:
    try:
        num = float(value)
    except Exception:
        return str(value)

    if math.isnan(num) or math.isinf(num):
        return str(value)

    if decimals is None:
        fixed = str(num)
    else:
        fixed = f"{num:.{decimals}f}"

    if num == 0:
        return fixed

    if min_sigfigs and _count_sigfigs(fixed) < min_sigfigs:
        sig = f"{num:.{min_sigfigs}g}"
        return _pad_sigfigs(sig, min_sigfigs)

    return fixed


def _safe_get_unit(obj: Any) -> str:
    u = getattr(obj, "unit", None)
    if u is None:
        return ""
    try:
        # Prefer compact pint formatting if available (like 'cm').
        try:
            from .UnitAlgebra import ureg

            # If `u` is already a pint Unit/Quantity-like, use it directly
            if hasattr(u, "units"):
                return format(u, "~")
            # Otherwise attempt to parse via registry
            try:
                pu = ureg.Unit(u)
                return format(pu, "~")
            except Exception:
                return str(u)
        except Exception:
            return str(u)
    except Exception:
        return str(u)


def _scalar_str_from_obj(
    obj: Any,
    index: int | None = None,
    decimals: int | None = DEFAULT_DECIMALS,
    min_sigfigs: int = MIN_SIGFIGS,
) -> Tuple[str, str]:
    """Return (value_str, unc_str) for a scalar-like quantity.

    If the object exposes `tval`/`tunc` (string presentations) use
    those when available; otherwise fall back to numeric `nval`/`nunc`.
    No rounding is performed.
    """
    # Prefer presentation strings if present. A present string, including an
    # empty string, is already formatted text and must not be numerically
    # reformatted.
    tval = getattr(obj, "tval", None)
    tunc = getattr(obj, "tunc", None)

    if tval is not None:
        try:
            if index is None:
                v = tval.ravel()[0]
            else:
                v = tval.ravel()[index]
        except Exception:
            v = ""
        val_str = str(v)
    else:
        val_str = None

    if tunc is not None:
        try:
            if index is None:
                u = tunc.ravel()[0]
            else:
                u = tunc.ravel()[index]
        except Exception:
            u = ""
        unc_str = str(u)
    else:
        unc_str = None

    if val_str is not None or unc_str is not None:
        nval = getattr(obj, "nval", None)
        nunc = getattr(obj, "nunc", None)
        if val_str is None and nval is not None:
            val_arr = np.atleast_1d(np.asarray(nval))
            val = val_arr.reshape(-1)[0 if index is None else index]
            val_str = _format_number(val, decimals, min_sigfigs)
        if unc_str is None and nunc is not None:
            unc_arr = np.atleast_1d(np.asarray(nunc))
            unc = unc_arr.reshape(-1)[0 if index is None else index]
            unc_str = _format_number(unc, decimals, min_sigfigs)
        return val_str or "", unc_str

    # Fallback to numeric values
    nval = getattr(obj, "nval", None)
    nunc = getattr(obj, "nunc", None)
    if nval is None:
        # last resort: str(obj)
        return str(obj), None

    arr = np.atleast_1d(np.asarray(nval))
    if index is None:
        try:
            val = arr.reshape(-1)[0]
        except Exception:
            val = arr
    else:
        val = arr.reshape(-1)[index]
    val_str = _format_number(val, decimals, min_sigfigs) if np.ndim(val) == 0 else str(val)

    if nunc is None:
        unc_str = None
    else:
        uarr = np.atleast_1d(np.asarray(nunc))
        try:
            if index is None:
                uval = uarr.reshape(-1)[0]
            else:
                uval = uarr.reshape(-1)[index]
            unc_str = _format_number(uval, decimals, min_sigfigs)
        except Exception:
            unc_str = None

    return val_str, unc_str


def format_quantity(
    obj: Any,
    parenthesis: bool = False,
    show_unit: bool = True,
    show_name: bool = False,
    decimals: int | None = DEFAULT_DECIMALS,
    min_sigfigs: int = MIN_SIGFIGS,
    index: int | None = None,
) -> str:
    """Format a single quantity as plain text.

    - If the object exposes `tval`/`tunc`, those strings are used unchanged,
        including empty strings.
    - Otherwise `nval`/`nunc` are converted to floats and formatted with
        fixed decimals and a minimum significant-figure rule.
    - `parenthesis` is accepted for API compatibility but currently
        does not change numeric formatting.
    """
    # Support passing raw tuples (name, val, unc, unit)
    name = ""
    if isinstance(obj, (list, tuple)) and len(obj) >= 3:
        name = str(obj[0]) if len(obj) > 0 else ""
        _, val, unc = obj[:3]
        unit = obj[3] if len(obj) > 3 else ""
        val_str = _format_number(val, decimals, min_sigfigs)
        unc_str = _format_number(unc, decimals, min_sigfigs) if unc is not None else None
        out = val_str
        if unc_str is not None:
            out = f"{out} ± {unc_str}"
        if show_unit and unit:
            out = f"{out} {unit}"
        if show_name and name:
            out = f"{name}: {out}"
        return out

    if show_name:
        name = str(getattr(obj, "name", "") or "")

    val_str, unc_str = _scalar_str_from_obj(obj, index=index, decimals=decimals, min_sigfigs=min_sigfigs)
    out = val_str
    if unc_str is not None:
        out = f"{out} ± {unc_str}"
    if show_unit:
        unit = _safe_get_unit(obj)
        if unit:
            out = f"{out} {unit}"
    if show_name and name:
        out = f"{name}: {out}"
    return out


def render_table_text(qs: Iterable[Any], columns: Tuple[str, ...] = ("name", "value", "unc", "unit"), fmt_opts: dict | None = None, header: bool = True) -> str:
    """Render a simple aligned ASCII table for an iterable of quantities.

    Each entry in `qs` may be a quantity-like object or a tuple/list
    matching (name, value, unc, unit). For `MeasuredQuantity` objects
    with multiple rows, each row is rendered as a separate table row.
    """
    fmt_opts = dict(fmt_opts or {})

    rows: List[dict] = []
    for item in qs:
        # tuple/list row
        if isinstance(item, (list, tuple)) and len(item) >= 3:
            name = str(item[0]) if len(item) > 0 else ""
            val = item[1]
            unc = item[2]
            unit = item[3] if len(item) > 3 else ""
            value_str = format_quantity((name, val, unc, unit), **fmt_opts)
            rows.append({"name": name, "value": value_str, "unc": str(unc) if unc is not None else "", "unit": unit})
            continue

        # Objects exposing array-like numeric values should render one
        # table row per element. This covers `MeasuredQuantity` (which
        # exposes `.dim`) as well as `DerivedQuantity`/`ConstantQuantity`
        # which may expose `.nval` arrays without a `dim` attribute.
        if hasattr(item, "nval") and hasattr(item, "nunc"):
            try:
                arr = np.atleast_1d(np.asarray(getattr(item, "nval")))
            except Exception:
                arr = None
            # prefer explicit dim when present, otherwise use array length
            dim = int(getattr(item, "dim", arr.size if arr is not None else 0))
            if dim > 1:
                name = getattr(item, "name", "")
                for i in range(dim):
                    vstr, ustr = _scalar_str_from_obj(
                        item,
                        index=i,
                        decimals=fmt_opts.get("decimals", DEFAULT_DECIMALS),
                        min_sigfigs=fmt_opts.get("min_sigfigs", MIN_SIGFIGS),
                    )
                    unit = _safe_get_unit(item)
                    value_str = vstr
                    if ustr is not None:
                        value_str = f"{vstr} ± {ustr}"
                    rows.append({"name": f"{name}[{i}]" if name else f"[{i}]", "value": value_str, "unc": ustr or "", "unit": unit})
                continue

        # Single scalar-like quantity
        name = getattr(item, "name", "")
        vstr, ustr = _scalar_str_from_obj(
            item,
            decimals=fmt_opts.get("decimals", DEFAULT_DECIMALS),
            min_sigfigs=fmt_opts.get("min_sigfigs", MIN_SIGFIGS),
        )
        unit = _safe_get_unit(item)
        value_str = vstr
        if ustr is not None:
            value_str = f"{vstr} ± {ustr}"
        rows.append({"name": name, "value": value_str, "unc": ustr or "", "unit": unit})

    # Build table lines
    col_names = list(columns)
    # If the formatted value string already includes the uncertainty (±),
    # there's no need to show it again in a separate `unc` column —
    # remove the `unc` column for a cleaner output.
    if "unc" in col_names and any(("±" in r.get("value", "")) for r in rows):
        col_names.remove("unc")
    # compute widths
    widths = {c: max(len(c), max((len(r.get(c, "")) for r in rows), default=0)) for c in col_names}

    lines: List[str] = []
    if header:
        hdr = "  ".join(c.ljust(widths[c]) for c in col_names)
        sep = "  ".join("-" * widths[c] for c in col_names)
        lines.append(hdr)
        lines.append(sep)

    for r in rows:
        line = "  ".join((r.get(c, "").ljust(widths[c]) if c == "name" else r.get(c, "").rjust(widths[c])) for c in col_names)
        lines.append(line)

    return "\n".join(lines)
