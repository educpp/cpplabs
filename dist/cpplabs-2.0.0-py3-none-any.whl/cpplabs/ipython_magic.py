from typing import List
import numpy as np
import re
from IPython.core.magic import register_cell_magic
from IPython import get_ipython
# If not running inside IPython, make `register_cell_magic` a no-op
_ip = get_ipython()
if _ip is None:
    def register_cell_magic(func):
        return func
import ast

from . import expr_registry


def _handle_record(names: List[str], rows: List[List[str]], g: dict) -> None:
    """Runtime helper: apply rows to named quantities.

    names: list of q variable names
    rows: list of rows; each row is a list of string entries (one per q)
    g: globals dict where q objects live
    """
    # Ensure all names exist and have add_data_point
    for nm in names:
        if nm not in g:
            raise RuntimeError(f"Quantity {nm!r} not found in the current notebook namespace")
        obj = g[nm]
        if not hasattr(obj, "add_data_point"):
            raise RuntimeError(f"Object {nm!r} has no add_data_point method")

    # Erase previous rows on the target quantities so the cell's rows
    # replace (not append to) any prior data.
    for nm in names:
        obj = g[nm]
        obj.tval = np.asarray([], dtype=str)
        obj.tunc = np.asarray([], dtype=str)
        obj.nval = np.asarray([], dtype=float)
        obj.nunc = np.asarray([], dtype=float)
        obj.dim = 0

    # No per-cell uncertainty seeding here; delegate missing/empty uncertainty
    # behavior to `MeasuredQuantity.add_data_point` which enforces first-row rules.

    # For each row, parse semicolon-separated items already prepared, then call add_data_point
    for row_idx, row_items in enumerate(rows):
        if len(row_items) != len(names):
            raise RuntimeError(f"Row {row_idx+1} has {len(row_items)} items but expected {len(names)}")
        for nm, item in zip(names, row_items):
            item = item.strip()
            if not item:
                raise RuntimeError(f"Empty entry for {nm!r} in row {row_idx+1}")
            parts = [p.strip() for p in item.split(",")]
            if len(parts) == 0:
                raise RuntimeError(f"Could not parse entry {item!r} for {nm!r}")
            val = parts[0]
            raw_unc = parts[1] if len(parts) > 1 else None
            if raw_unc is not None and raw_unc == "":
                raw_unc = None
            # Delegate missing/empty-unc behavior to add_data_point (inherit or raise).
            g[nm].add_data_point(val, raw_unc)


def _handle_add(names: List[str], rows: List[List[str]], g: dict) -> None:
    """Runtime helper: append rows to named quantities without erasing.

    When an incoming uncertainty is empty, inherit the first uncertainty
    already present on the target quantity (if any); otherwise fall back
    to the first non-empty uncertainty seen in this cell, or "0".
    """
    # Ensure all names exist and have add_data_point
    for nm in names:
        if nm not in g:
            raise RuntimeError(f"Quantity {nm!r} not found in the current notebook namespace")
        obj = g[nm]
        if not hasattr(obj, "add_data_point"):
            raise RuntimeError(f"Object {nm!r} has no add_data_point method")

    # No seeding here; leave missing/empty-unc handling to add_data_point itself.

    # For each row, parse semicolon-separated items already prepared, then call add_data_point
    for row_idx, row_items in enumerate(rows):
        if len(row_items) != len(names):
            raise RuntimeError(f"Row {row_idx+1} has {len(row_items)} items but expected {len(names)}")
        for nm, item in zip(names, row_items):
            item = item.strip()
            if not item:
                raise RuntimeError(f"Empty entry for {nm!r} in row {row_idx+1}")
            parts = [p.strip() for p in item.split(",")]
            if len(parts) == 0:
                raise RuntimeError(f"Could not parse entry {item!r} for {nm!r}")
            val = parts[0]
            raw_unc = parts[1] if len(parts) > 1 else None
            if raw_unc is not None and raw_unc == "":
                raw_unc = None
            g[nm].add_data_point(val, raw_unc)


@register_cell_magic
def record(line, cell):
    """Cell magic to record rows into one or more `MeasuredQuantity` objects.

    Usage:
    %%record q1, q2, q3
    29.5, 0.200; 29.5, 0.200; 29.5, 0.200
    33.7, 0.300; 33.7, 0.300; 33.7, 0.300
    end

    Comma separates value/uncertainty; semicolon separates q-objects. Empty
    or missing uncertainty entries inherit the first uncertainty already
    present on the quantity. If the quantity has no prior rows, a missing
    uncertainty raises a ``ValueError``. Uncertainty fields may use ``5%``
    for percentage uncertainty or ``5%2`` for percentage plus two display
    counts. All inputs are treated as strings.
    """
    names = [n.strip() for n in line.split(",") if n.strip()]
    if not names:
        raise RuntimeError("No target quantities specified for %%record")

    # get notebook globals
    ip = get_ipython()
    if ip is None:
        raise RuntimeError("%%record must be used inside an IPython/Jupyter session")
    g = ip.user_ns

    # parse cell body: ignore lines that are just 'end' (case-insensitive)
    lines = [ln for ln in cell.splitlines() if ln.strip() and ln.strip().lower() != "end"]
    rows = []
    for ln in lines:
        # split by semicolon into q entries
        items = [it.strip() for it in ln.split(";")]
        # remove empty trailing items caused by trailing semicolons
        if items and items[-1] == "":
            items = items[:-1]
        rows.append(items)

    # validate rows have same number of items as names
    for idx, items in enumerate(rows):
        if len(items) != len(names):
            raise RuntimeError(f"Row {idx+1} has {len(items)} entries but expected {len(names)}")

    # call helper
    _handle_record(names, rows, g)

    # No console output here; leave presentation to the notebook UI
    # and consumers of the recorded quantities.


@register_cell_magic
def add(line, cell):
    """Cell magic to append rows into one or more `MeasuredQuantity` objects.

    Behaves like `%%record` except it does not clear existing rows on the
    target quantities; new rows are appended via `add_data_point`. Percentage
    uncertainty fields use the same ``5%`` or ``5%2`` string syntax.
    """
    names = [n.strip() for n in line.split(",") if n.strip()]
    if not names:
        raise RuntimeError("No target quantities specified for %%add")

    # get notebook globals
    ip = get_ipython()
    if ip is None:
        raise RuntimeError("%%add must be used inside an IPython/Jupyter session")
    g = ip.user_ns

    # parse cell body: ignore lines that are just 'end' (case-insensitive)
    lines = [ln for ln in cell.splitlines() if ln.strip() and ln.strip().lower() != "end"]
    rows = []
    for ln in lines:
        items = [it.strip() for it in ln.split(";")]
        if items and items[-1] == "":
            items = items[:-1]
        rows.append(items)

    # validate rows have same number of items as names
    for idx, items in enumerate(rows):
        if len(items) != len(names):
            raise RuntimeError(f"Row {idx+1} has {len(items)} entries but expected {len(names)}")

    # call helper that appends
    _handle_add(names, rows, g)

    # No console output here; leave presentation to the notebook UI
    # and consumers of the appended quantities.


# Lightweight AST transform: rewrite DerivedQuantity(<expr>, name)
# into DerivedQuantity(sp.sympify('<expr>'), sources={...}, name)
#
# Additionally, when running in IPython/Jupyter the transformer will
# conservatively inject `xvar`/`yvar` keyword arguments into calls of
# `Plot.data(...)` and `Plot.data_and_model(...)` when the first two
# positional arguments are simple names. This enables notebook users
# to write `fig, ax = Plot.data(x, F)` and receive axis labels like
# ``Distance, $x$ [cm]`` (the Plot module still honors explicit
# `xlabel`/`ylabel` or provided `xvar`/`yvar`). The AST injection is
# applied only to simple name arguments to avoid surprising rewrites.
def _DQTransformerFactory(source_text: str | None = None):
    """Build the AST transformer used in IPython/Jupyter sessions.

    This rewrites simple `DerivedQuantity(...)` calls to inject source
    mappings from free names, and optionally injects `xvar`/`yvar` or
    `center_vars` into Plot helpers so axis labels are more readable.
    """
    class _DQTransformer(ast.NodeTransformer):
        _SYMBOL_CONSTRUCTORS = {
            "Meas",
            "MeasuredQuantity",
            "MeasurementQuantity",
            "Const",
            "ConstantQuantity",
            "Calc",
            "DerivedQuantity",
        }

        def visit_Assign(self, node: ast.Assign):
            """Attach direct assignment targets as quantity symbols."""
            if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
                return self.generic_visit(node)

            target = node.targets[0]
            if not isinstance(node.value, ast.Call):
                return self.generic_visit(node)
            if not isinstance(node.value.func, ast.Name):
                return self.generic_visit(node)
            if node.value.func.id not in self._SYMBOL_CONSTRUCTORS:
                return self.generic_visit(node)
            if any(keyword.arg == "symbol" for keyword in node.value.keywords):
                return self.generic_visit(node)

            transformed_value = self.visit(node.value)
            assignment = ast.copy_location(
                ast.Assign(targets=[target], value=transformed_value),
                node,
            )
            symbol_assignment = ast.copy_location(
                ast.Assign(
                    targets=[ast.Attribute(value=ast.Name(id=target.id, ctx=ast.Load()), attr="symbol", ctx=ast.Store())],
                    value=ast.Constant(value=target.id),
                ),
                node,
            )
            return [assignment, symbol_assignment]

        @staticmethod
        def _quote_numeric_constants(node: ast.AST) -> ast.AST:
            class _QuoteNumeric(ast.NodeTransformer):
                @staticmethod
                def _literal_text(n: ast.AST) -> str:
                    if source_text is not None:
                        text = ast.get_source_segment(source_text, n)
                        if text is not None:
                            return text.strip()
                    try:
                        return ast.unparse(n)
                    except Exception:
                        if isinstance(n, ast.Constant):
                            return str(n.value)
                        raise

                def visit_UnaryOp(self, n: ast.UnaryOp):
                    # A sign is a separate AST node. Quote the complete signed
                    # literal so ``-1.20`` does not become invalid ``-'1.2'``.
                    if (
                        isinstance(n.op, (ast.UAdd, ast.USub))
                        and isinstance(n.operand, ast.Constant)
                        and not isinstance(n.operand.value, bool)
                        and isinstance(n.operand.value, (int, float))
                    ):
                        text = self._literal_text(n)
                        return ast.copy_location(ast.Constant(value=text), n)
                    return self.generic_visit(n)

                def visit_Constant(self, n: ast.Constant):
                    if isinstance(n.value, bool):
                        return n
                    if isinstance(n.value, (int, float)):
                        text = self._literal_text(n)
                        return ast.copy_location(ast.Constant(value=text), n)
                    return n

            return _QuoteNumeric().visit(node)

        @staticmethod
        def _is_record_data_table_call(func: ast.AST) -> bool:
            if isinstance(func, ast.Name):
                return func.id == "record_data_table"
            if isinstance(func, ast.Attribute):
                return func.attr == "record_data_table"
            return False

        def _rewrite_record_data_table_rows(self, node: ast.Call):
            if not self._is_record_data_table_call(node.func):
                return None

            new_keywords = []
            found_rows = False
            for kw in node.keywords:
                if kw.arg == "rows" and kw.value is not None:
                    found_rows = True
                    rewritten = self._quote_numeric_constants(kw.value)
                    new_keywords.append(ast.keyword(arg=kw.arg, value=rewritten))
                else:
                    new_keywords.append(kw)

            if not found_rows:
                return None

            return ast.copy_location(
                ast.Call(func=node.func, args=node.args, keywords=new_keywords),
                node,
            )

        def visit_Call(self, node: ast.Call):
            rewritten_rows = self._rewrite_record_data_table_rows(node)
            if rewritten_rows is not None:
                return self.generic_visit(rewritten_rows)

            if isinstance(node.func, ast.Attribute):
                base = node.func.value
                if isinstance(base, ast.Name) and base.id == "Plot" and node.func.attr in ("data", "data_and_model", "compare"):
                    existing = {kw.arg for kw in node.keywords if kw.arg}
                    new_keywords = list(node.keywords)

                    if node.func.attr in ("data", "data_and_model"):
                        if "xvar" not in existing and len(node.args) >= 1 and isinstance(node.args[0], ast.Name):
                            x_name = node.args[0].id
                            new_keywords.append(ast.keyword(arg="xvar", value=ast.Constant(value=f"${x_name}$")))
                        if "yvar" not in existing and len(node.args) >= 2 and isinstance(node.args[1], ast.Name):
                            y_name = node.args[1].id
                            new_keywords.append(ast.keyword(arg="yvar", value=ast.Constant(value=f"${y_name}$")))

                    # For Plot.compare, inject a `center_vars` list matching the positional args
                    if node.func.attr == "compare" and "center_vars" not in existing:
                        elts = []
                        for a in node.args:
                            # simple name: use it
                            if isinstance(a, ast.Name):
                                elts.append(ast.Constant(value=f"${a.id}$"))
                                continue
                            # attribute call like `k_eq.to('N/cm')` -> use base name `k_eq`
                            if isinstance(a, ast.Call) and isinstance(a.func, ast.Attribute):
                                base = a.func.value
                                if isinstance(base, ast.Name):
                                    elts.append(ast.Constant(value=f"${base.id}$"))
                                    continue
                            # attribute access like `k_eq.attr` -> use base name
                            if isinstance(a, ast.Attribute) and isinstance(a.value, ast.Name):
                                elts.append(ast.Constant(value=f"${a.value.id}$"))
                                continue
                            # fallback: empty label
                            elts.append(ast.Constant(value=""))
                        new_keywords.append(ast.keyword(arg="center_vars", value=ast.List(elts=elts, ctx=ast.Load())))

                    if new_keywords != node.keywords:
                        new_node = ast.copy_location(
                            ast.Call(func=node.func, args=node.args, keywords=new_keywords),
                            node,
                        )
                        return self.generic_visit(new_node)

            if isinstance(node.func, ast.Name) and node.func.id == "DerivedQuantity":
                if node.args:
                    first = node.args[0]
                    # If the first argument is already a SymPy call like
                    # sp.Max(...), do not rewrite it. This allows the Python
                    # side (MeasuredQuantity.__sympy__ and DerivedQuantity)
                    # to handle general SymPy expressions without AST
                    # interference.
                    if isinstance(first, ast.Call) and isinstance(first.func, ast.Attribute):
                        base = first.func.value
                        if isinstance(base, ast.Name) and base.id in ("sp", "sympy"):
                            return self.generic_visit(node)
                    # If the first argument is a bare name (e.g., an existing
                    # SymPy expression stored in a variable), leave it intact
                    # so Python-side handling can resolve it without rewriting.
                    if isinstance(first, ast.Name):
                        return self.generic_visit(node)
                    if isinstance(first, (ast.Constant, ast.Str)):
                        # First argument is a string literal; keep it but
                        # attempt to parse its contents to find free names
                        # so we can build a `sources` mapping.
                        expr_text = None
                        if isinstance(first, ast.Constant) and isinstance(first.value, str):
                            expr_text = first.value
                        elif isinstance(first, ast.Str):
                            expr_text = first.s
                        names = []
                        if expr_text is not None:
                            # Normalize common prefixes like `sympy.` or `sp.` so
                            # users can write `sympy.pi` or `sp.pi` and we
                            # still recognize `pi` as a constant rather than
                            # treating `sympy`/`sp` as a source name.
                            expr_text = re.sub(r"\b(?:sympy|sp)\.", "", expr_text)
                            try:
                                # parse the expression text and collect names
                                expr_ast = ast.parse(expr_text, mode="eval")
                                names = sorted({n.id for n in ast.walk(expr_ast) if isinstance(n, ast.Name)})
                            except Exception:
                                names = []

                        # Filter out common mathematical constants and known
                        # function names so they are not treated as sources.
                        math_consts = {"pi", "e", "E"}
                        func_names = set(expr_registry.get_sympify_locals().keys())
                        names = [n for n in names if n not in math_consts and n not in ("sympy", "sp") and n not in func_names]

                        keys = [ast.Constant(value=n) for n in names]
                        values = [ast.Name(id=n, ctx=ast.Load()) for n in names]
                        sources_dict = ast.Dict(keys=keys, values=values)
                        sources_kw = ast.keyword(arg="sources", value=sources_dict)

                        has_sources = any(k.arg == "sources" for k in node.keywords)
                        pos_sources = False

                        new_args = [first]
                        new_keywords = list(node.keywords)
                        if len(node.args) > 1:
                            second = node.args[1]
                            if isinstance(second, (ast.Constant, ast.Str)):
                                name_kw = ast.keyword(arg="name", value=second)
                                new_keywords.append(name_kw)
                            else:
                                if isinstance(second, ast.Dict):
                                    pos_sources = True
                                new_args.append(second)
                        if len(node.args) > 2:
                            third = node.args[2]
                            if isinstance(third, (ast.Constant, ast.Str)):
                                name_kw = ast.keyword(arg="name", value=third)
                                new_keywords.append(name_kw)
                            else:
                                new_args.append(third)
                        if not has_sources and names and not pos_sources:
                            new_keywords.append(sources_kw)

                        new_node = ast.copy_location(ast.Call(func=node.func, args=new_args, keywords=new_keywords), node)
                        return new_node
                    else:
                        try:
                            expr_text = ast.unparse(first)
                        except Exception:
                            return self.generic_visit(node)

                        # Remove explicit `sympy.` / `sp.` prefixes so names
                        # extracted refer to bare symbols (e.g., `pi`). Then
                        # parse that cleaned expression to collect identifiers.
                        expr_text = re.sub(r"\b(?:sympy|sp)\.", "", expr_text)
                        try:
                            expr_ast = ast.parse(expr_text, mode="eval")
                            names = sorted({n.id for n in ast.walk(expr_ast) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)})
                        except Exception:
                            names = []

                        math_consts = {"pi", "e", "E"}
                        func_names = set(expr_registry.get_sympify_locals().keys())
                        names = [n for n in names if n not in math_consts and n not in ("sympy", "sp") and n not in func_names]

                        sym_call = ast.Call(
                            func=ast.Attribute(value=ast.Name(id="sp", ctx=ast.Load()), attr="sympify", ctx=ast.Load()),
                            args=[ast.Constant(value=expr_text)],
                            keywords=[],
                        )

                        keys = [ast.Constant(value=n) for n in names]
                        values = [ast.Name(id=n, ctx=ast.Load()) for n in names]
                        sources_dict = ast.Dict(keys=keys, values=values)
                        sources_kw = ast.keyword(arg="sources", value=sources_dict)

                        has_sources = any(k.arg == "sources" for k in node.keywords)
                        pos_sources = False

                        # Preserve any explicit name positional arg by converting
                        # it to a keyword to avoid colliding with the `sources`
                        # parameter expected as the second positional argument
                        new_args = [sym_call]
                        new_keywords = list(node.keywords)
                        if len(node.args) > 1:
                            second = node.args[1]
                            if isinstance(second, (ast.Constant, ast.Str)):
                                # treat as name keyword
                                name_kw = ast.keyword(arg="name", value=second)
                                new_keywords.append(name_kw)
                            else:
                                if isinstance(second, ast.Dict):
                                    pos_sources = True
                                # keep non-literal second arg as positional
                                new_args.append(second)
                        if len(node.args) > 2:
                            third = node.args[2]
                            if isinstance(third, (ast.Constant, ast.Str)):
                                name_kw = ast.keyword(arg="name", value=third)
                                new_keywords.append(name_kw)
                            else:
                                new_args.append(third)
                        if not has_sources and not pos_sources:
                            new_keywords.append(sources_kw)

                        new_node = ast.copy_location(ast.Call(func=node.func, args=new_args, keywords=new_keywords), node)
                        return new_node
            return self.generic_visit(node)

    return _DQTransformer()


def _transform_derivedquantity_calls(source: str) -> str:
    # IPython/VS Code may pass a list of source lines (or inject a
    # debugpy preamble). Normalize to a single string and strip the
    # common debugpy preamble used by the VS Code debugger so the
    # AST transform sees the user's code.
    if isinstance(source, list):
        source = "".join(source)

    # strip a common debugpy preamble (two-line injection)
    lines = source.splitlines()
    if len(lines) >= 2 and lines[0].strip().startswith("import debugpy") and "debugpy.debug_this_thread" in lines[1]:
        source = "\n".join(lines[2:])

    try:
        tree = ast.parse(source)
    except Exception:
        return source

    new_tree = _DQTransformerFactory(source).visit(tree)
    ast.fix_missing_locations(new_tree)
    try:
        transformed = ast.unparse(new_tree)
    except Exception:
        return source

    # If the transformed code uses `sp` but the original cell did not import
    # sympy, inject a local import so the transformed cell runs cleanly.
    if "sp." in transformed and "import sympy" not in source and "from sympy" not in source:
        transformed = "import sympy as sp\n" + transformed
    return transformed


# AST-node transformer compatible with IPython's input_transformer_manager
def _transform_derivedquantity_ast(tree: ast.AST) -> ast.AST:
    try:
        new_tree = _DQTransformerFactory().visit(tree)
        ast.fix_missing_locations(new_tree)
        return new_tree
    except Exception:
        return tree


def _register_ipython_transformers(ip) -> None:
    """Register the source transformer, with a modern AST fallback."""
    post_transformers = getattr(ip, "input_transformers_post", None)
    if post_transformers is not None and hasattr(post_transformers, "append"):
        if _transform_derivedquantity_calls not in post_transformers:
            post_transformers.append(_transform_derivedquantity_calls)
        return

    # AST nodes no longer retain the spelling of numeric literals, so this is
    # only a fallback for environments without source-level transformers.
    ast_transformers = getattr(ip, "ast_transformers", None)
    if ast_transformers is not None and hasattr(ast_transformers, "append"):
        ast_transformers.append(_DQTransformerFactory())


# Register the transformer with IPython if available (best-effort).
try:
    ip = get_ipython()
    if ip is not None:
        _register_ipython_transformers(ip)
except Exception:
    pass
