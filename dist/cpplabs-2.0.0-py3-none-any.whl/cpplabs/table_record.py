"""Table-style recording helpers for MeasuredQuantity objects.

This module provides a helper API to load table rows into multiple
quantities at once while keeping row parsing and validation centralized.
"""
from __future__ import annotations

from typing import Any, Iterable
import numpy as np

from .formatting import _safe_get_unit, _format_number, DEFAULT_DECIMALS


def _clear_quantity_rows(q: Any) -> None:
    q.tval = np.asarray([], dtype=str)
    q.tunc = np.asarray([], dtype=str)
    q.nval = np.asarray([], dtype=float)
    q.nunc = np.asarray([], dtype=float)
    q.dim = 0


def record_data_table(*quantities: Any, rows: Iterable[Iterable[Any]]) -> None:
    """Record table rows into multiple quantities (clear-and-replace).

    Usage
    -----
    record_data_table(
        t,
        I_meas,
        rows=[
            ("0.0", "1%", "16.2", "0.2"),
            ("5.0", "1%2", "15.7", "0.2"),
        ],
    )

    Each quantity contributes two row columns in order:
    `(value, uncertainty)`.

    Quoted uncertainty fields may use ``"<percentage>%"`` or
    ``"<percentage>%<counts>"``. Percentage entries require the paired value
    to be a plain decimal string and must be supplied for each data point.

    The function clears existing rows on all provided quantities before
    loading the new table rows.
    """
    if not quantities:
        raise ValueError("record_data_table requires at least one target quantity")
    if rows is None:
        raise ValueError("record_data_table requires a non-None rows iterable")

    q_list = list(quantities)
    n_q = len(q_list)
    expected_cols = 2 * n_q

    for idx, q in enumerate(q_list):
        if not hasattr(q, "add_data_point"):
            raise TypeError(
                f"Target at index {idx} has no add_data_point method"
            )

    for q in q_list:
        _clear_quantity_rows(q)

    for row_idx, row in enumerate(rows):
        row_vals = list(row)
        if len(row_vals) != expected_cols:
            raise ValueError(
                f"Row {row_idx + 1} has {len(row_vals)} values; expected {expected_cols} "
                f"({n_q} quantities x value/uncertainty pairs)"
            )

        for i, q in enumerate(q_list):
            val = row_vals[2 * i]
            unc = row_vals[2 * i + 1]
            q.add_data_point(val, unc)


def _row_count(q: Any) -> int:
    if hasattr(q, "dim"):
        return int(getattr(q, "dim"))
    if hasattr(q, "nval"):
        try:
            return int(np.atleast_1d(np.asarray(getattr(q, "nval"))).size)
        except Exception:
            return 0
    return 0


def _cell_value_unc(q: Any, idx: int) -> str:
    # Prefer presentation strings to preserve user-entered precision.
    if hasattr(q, "tval") and getattr(q, "tval") is not None:
        try:
            v = str(np.asarray(getattr(q, "tval")).ravel()[idx])
        except Exception:
            v = str(
                _format_number(
                    np.atleast_1d(np.asarray(getattr(q, "nval"), dtype=float)).ravel()[idx],
                    decimals=DEFAULT_DECIMALS,
                )
            )
    else:
        v = str(
            _format_number(
                np.atleast_1d(np.asarray(getattr(q, "nval"), dtype=float)).ravel()[idx],
                decimals=DEFAULT_DECIMALS,
            )
        )

    u_obj = getattr(q, "tunc", None)
    if u_obj is not None:
        try:
            u = str(np.asarray(u_obj).ravel()[idx])
        except Exception:
            u = None
    else:
        u = None

    if u is None:
        nunc = getattr(q, "nunc", None)
        if nunc is not None:
            try:
                u = str(
                    _format_number(
                        np.atleast_1d(np.asarray(nunc, dtype=float)).ravel()[idx],
                        decimals=DEFAULT_DECIMALS,
                    )
                )
            except Exception:
                u = None

    if u is None:
        return v
    return f"{v} +/- {u}"


def _ascii_table(headers: list[str], rows: list[list[str]]) -> str:
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))

    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    header_line = "| " + " | ".join(headers[i].ljust(widths[i]) for i in range(len(headers))) + " |"

    lines = [border, header_line, border]
    for row in rows:
        lines.append("| " + " | ".join(row[i].ljust(widths[i]) for i in range(len(headers))) + " |")
    lines.append(border)
    return "\n".join(lines)


def _resolve_symbol_from_ipython_namespace(q: Any) -> str:
    """Resolve a quantity symbol from the active IPython user namespace.

    This mirrors notebook AST/runtime conventions where variable names in
    the user namespace act as symbol bindings.
    """
    try:
        from IPython import get_ipython
    except Exception:
        return ""

    try:
        ip = get_ipython()
        if ip is None:
            return ""
        user_ns = getattr(ip, "user_ns", None)
        if not isinstance(user_ns, dict):
            return ""

        matches: list[str] = []
        for key, value in user_ns.items():
            if not isinstance(key, str) or not key or key.startswith("_"):
                continue
            if value is q:
                matches.append(key)

        if not matches:
            return ""

        # Deterministic alias selection for tests and repeatable output.
        return sorted(matches)[0].strip()
    except Exception:
        return ""


def _resolve_quantity_symbol(q: Any) -> str:
    # Primary path: active notebook namespace binding.
    symbol = _resolve_symbol_from_ipython_namespace(q)
    if symbol:
        return symbol

    # Fallback path: explicit object attributes.
    for attr in ("symbol", "sym"):
        raw = getattr(q, attr, None)
        if raw is not None and str(raw).strip():
            return str(raw).strip()
    return ""


def _quantity_header(q: Any) -> str:
    name = str(getattr(q, "name", "") or "quantity")

    symbol = _resolve_quantity_symbol(q)

    base = name
    if symbol and symbol != name:
        base = f"{name}, {symbol}"

    unit = _safe_get_unit(q)
    return f"{base} [{unit}]" if unit else base


def display_data_table(*quantities: Any) -> None:
    """Print an ASCII table for one or more quantity objects.

    Each quantity is displayed as one column with cells formatted as
    `value +/- uncertainty` for each row.
    """
    if not quantities:
        raise ValueError("display_data_table requires at least one target quantity")

    q_list = list(quantities)
    for idx, q in enumerate(q_list):
        if not hasattr(q, "nval"):
            raise TypeError(f"Target at index {idx} has no nval data")

    counts = [_row_count(q) for q in q_list]
    if any(c <= 0 for c in counts):
        raise ValueError("display_data_table requires non-empty quantities")
    if len(set(counts)) != 1:
        raise ValueError("All quantities passed to display_data_table must have the same row count")

    headers: list[str] = [_quantity_header(q) for q in q_list]

    rows: list[list[str]] = []
    nrows = counts[0]
    for i in range(nrows):
        rows.append([_cell_value_unc(q, i) for q in q_list])

    print(_ascii_table(headers, rows))
